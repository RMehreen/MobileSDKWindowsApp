﻿// C# Send SMS example using COM Interop with Citrix Mobility SDK
//
// Uses Citrix Mobility SDK to start a SMS
//
// Copyright (c) 2012 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using CitrixMobility;

namespace sendsms
{
    public partial class Form1 : Form
    {
        // <summary>
        // Initialise SMS id (unique to this application).
        // </summary>
        private int SMSId = 0x22654321;

        // <summary>
        // Phone number to send SMS to.
        // </summary>
        private string phoneNumber = string.Empty;

        // <summary>
        // SMS message text.
        // </summary>
        private string smsMessage = string.Empty;

        // <summary>
        // Instance of CitrixMobile.
        // </summary>
        private CitrixMobile cmp = null;

        // <summary>
        // ICA session connected state.
        // </summary>
        private bool icaSessionConnected = false;

        // <summary>
        // Check CMP return code for success.
        // </summary>
        public static bool CMP_SUCCESS(int rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (int)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        // <summary>
        // Dispatch action to UI thread if necessary.
        // </summary>
        // <param name="action">The action.</param>
        private void UiDispatch(Action action)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(action);
            }
            else
            {
                action();
            }
        }

        // <summary>
        // Report CMP status.
        // </summary>
        // <param name="text">Status text.</param>
        // <param name="rc">CMP return code.</param>
        private void ReportStatus(string text, int rc)
        {
            // Only report status if something went wrong.
            if (!CMP_SUCCESS(rc))
            {
                string msg = string.Format("{0}, CMPResult: 0x{1:X}", text, rc);

                // Write to trace output.
                Helpers.Trace(msg);
                // Update status text.
                UiDispatch(() => this.status.Text = msg);
            }
        }

        public Form1()
        {
            InitializeComponent();

            // Initialises CMP framework.
            InitialiseCmp();
        }

        /// <summary>
        /// Initialise CMP framework.
        /// </summary>
        private void InitialiseCmp()
        {
            int rc = (int)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Helpers.Trace("Creating CitrixMobile object");
                // Create an instance of CitrixMobile object.
                cmp = new CitrixMobile();

                Helpers.Trace("Register for ICA session state changed events");
                // Register for ICA session events.
                cmp.SessionStateChanged += new ICMPEvents_SessionStateChangedEventHandler(cmp_SessionStateChanged);

                Helpers.Trace("Calling OpenSession");
                // Open CMP session.
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    icaSessionConnected = true;

                    Helpers.Trace("Register for SMS started events");
        //! [eventsubscription]
        // Register for SMS events.
        cmp.SMSStarted += new ICMPEvents_SMSStartedEventHandler(cmp_SMSStarted);
        //! [eventsubscription]
                }
                else
                {
                    ReportStatus("OpenSession failed", rc);
                }
            }
            catch (System.Exception ex)
            {
                Helpers.Trace(ex.Message);
                Helpers.Trace(ex.StackTrace);
            }
        }

        // <summary>
        // Tear down CMP connection when closed.
        // </summary>
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (null != cmp)
            {
                // Close CMP session.
                cmp.CloseSession();
                cmp = null;
            }
        }

        // <summary>
        // Session state change handler.
        // </summary>
        // <remarks>Update the ICA session state upon connect/disconnect.</remarks>
        // <param name="SessState">Session state</param>
        void cmp_SessionStateChanged(CMP_SESSION_STATE SessState)
        {
            switch (SessState)
            {
                case CMP_SESSION_STATE.CMP_SESSION_STATE_CONNECTED:
                    icaSessionConnected = true;
                    break;
                case CMP_SESSION_STATE.CMP_SESSION_STATE_DISCONNECTED:
                    icaSessionConnected = false;
                    break;
                default:
                    break;
            }
        }

        //! [eventhandler]
        // <summary>
        // SMS Started handler.
        // </summary>
        // <param name="rc">Return code.</param>
        // <param name="smsId">SMS identifier.</param>
        private void cmp_SMSStarted(Int32 rc, Int32 smsId)
        {
            // Only proceed if it is one of ours.
            if (smsId == SMSId)
            {
                Helpers.Trace("SMS started. rc:0x{0:X} SMSId:0x{1:X}", rc, SMSId);

                // Indicate that SMS was started.
                UiDispatch(() => this.status.Text = string.Format("SMS to {0} was started.", phoneNumber));
            }
        }
        //! [eventhandler]

        //! [sendsms]
        // <summary>
        // Send SMS message.
        // </summary>
        // <param name="phoneNumber">Phone number to send message to.</param>
        // <param name="smsId">The application specific unique send SMS ID.</param>
        // <param name="smsText">The content of the SMS message.</param>
        // <returns></returns>
        private int SendSMS(string phoneNumber, int smsId, string smsText)
        {
            // Initiate the send SMS functionality of the connected device.
            int rc = cmp.SendSMS(phoneNumber, SMSId, smsText);

            return rc;
        }
        //! [sendsms]
        
        // <summary>
        // Send button event handler.
        // </summary>
        private void sendButton_Click(object sender, EventArgs e)
        {
            if ((null != cmp) && icaSessionConnected)
            {
                phoneNumber = numberBox.Text.Trim();
                smsMessage = smsTextBox.Text.Trim();

                if (!string.IsNullOrEmpty(phoneNumber))
                {
                    if (!string.IsNullOrEmpty(smsMessage))
                    {
                        Helpers.Trace("Phone number retrieved");
                        UiDispatch(() => this.status.Text = string.Format("Initiating phone call to {0}...", phoneNumber));

                        // Initiate the phone call process on the connected device.
                        int rc = SendSMS(phoneNumber, SMSId, smsMessage);

                        if (CMP_SUCCESS(rc))
                        {
                            Helpers.Trace("SMS message Sent");
                        }
                        else
                        {
                            ReportStatus("SendSMS failed", rc);
                            Helpers.Trace("SendSMS failed rc={0:X}", rc);
                        }
                    }
                    else
                    {
                        // SMS text message is required.
                        UiDispatch(() => this.status.Text = string.Format("Message text must be specified."));
                    }
                }
                else
                {
                    // Phone number is required.
                    UiDispatch(() => this.status.Text = string.Format("Phone number must be specified."));
                }
            }
        }
    }
}
