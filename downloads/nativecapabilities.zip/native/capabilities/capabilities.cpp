/*
    Capabilities example:

    Uses Citrix Mobility Pack SDK to list all the capabilities

    Copyright (c) Citrix Systems
*/

#include <stdio.h>
#include <windows.h>

#include <cmp.h>


/*
 *  Allowed capability types
 */
typedef enum CAP_TYPE
{
    CAP_TYPE_BOOL,
    CAP_TYPE_UINT16,
    CAP_TYPE_INT32,
    CAP_TYPE_UINT32
} CAP_TYPE, *PCAP_TYPE;

/*
 * Storage record for capability value
 */
typedef struct CAP_RECORD
{
    CMP_CAP_ID          capId;
    UINT16              capKeyId;
    LPCSTR              capKeyName;
    UINT16              capType;
    UINT32              capValue;           // can contain any of the values (biggest size)
} CAP_RECORD, *PCAP_RECORD;

/*
 * Macros to help with building the records for capabilities
 */
#define CAP_ENTRY(capId, capKeyId, capType) { capId, capKeyId, #capKeyId, capType, 0}
#define CAP_ENTRY_END() { (CMP_CAP_ID)0, 0, NULL, 0, 0}

/*
 * List of all currently known capabilities.
 * Pattern is CapabilityId, CapabilityKeyId, CapabilityType.  Macro expands these values
 * to generate a CapabilityKeyId string name.  Capability record stores the 
 * resulting value in capValue when the capabilities are read.
 */
CAP_RECORD capDict[] =
{
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_ENABLE,                   CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_KYBD,                     CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_PHYSICAL_KYBD,            CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_TRACKBALL,                CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_MOUSE,                    CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_STD_KYBD,                 CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_NUMPAD_KYBD,              CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_PHONEPAD_KYBD,            CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_URL_KYBD,                 CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_EMAIL_KYBD,               CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_PHONE_NAME_KYBD,          CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_NUMBERS_PUNC_KYBD,        CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_DECIMAL_POINT_KYBD,       CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_HIDE,                     CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_AUTO_CORRECT,             CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_AUTO_CAPITALIZATION,      CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_AUTO_CAPITAL_WORD,        CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_AUTO_CAPITAL_SENTENCE,    CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_AUTO_CAPITAL_LETTERS,     CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_RETURN_KEY_DEFAULT,       CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_RETURN_KEY_GO,            CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_RETURN_KEY_GOOGLE,        CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_RETURN_KEY_JOIN,          CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_RETURN_KEY_NEXT,          CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_RETURN_KEY_ROUTE,         CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_RETURN_KEY_SEARCH,        CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_RETURN_KEY_SEND,          CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_RETURN_KEY_DONE,          CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_INPUT,          CAP_INPUT_RETURN_KEY,               CAP_TYPE_BOOL),

    CAP_ENTRY(CAPID_ORIENTATION,    CAP_ORIENTATION_ENABLE,             CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_ORIENTATION,    CAP_ORIENTATION_DEVICE,             CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_ORIENTATION,    CAP_ORIENTATION_APPLICATION,        CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_ORIENTATION,    CAP_ORIENTATION_PORTRAIT,           CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_ORIENTATION,    CAP_ORIENTATION_PORTRAIT_DOWN,      CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_ORIENTATION,    CAP_ORIENTATION_LANDSCAPE_LEFT,     CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_ORIENTATION,    CAP_ORIENTATION_LANDSCAPE_RIGHT,    CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_ORIENTATION,    CAP_ORIENTATION_LOCK_UNLOCK,        CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_ORIENTATION,    CAP_ORIENTATION_FOLLOW_SENSOR,      CAP_TYPE_BOOL),

    CAP_ENTRY(CAPID_DISPLAY_INFO,   CAP_DISPLAY_ENABLE,                 CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_DISPLAY_INFO,   CAP_DISPLAY_RESOLUTION_FLAG,        CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_DISPLAY_INFO,   CAP_DISPLAY_COLOR_FLAG,             CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_DISPLAY_INFO,   CAP_DISPLAY_PHYSICAL_FLAG,          CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_DISPLAY_INFO,   CAP_DISPLAY_PPI_FLAG,               CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_DISPLAY_INFO,   CAP_DISPLAY_PPI_X_Y_FLAG,           CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_DISPLAY_INFO,   CAP_DISPLAY_ORIENTATION_FLAG,       CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_DISPLAY_INFO,   CAP_DISPLAY_METRICS,                CAP_TYPE_UINT16),
    CAP_ENTRY(CAPID_DISPLAY_INFO,   CAP_DISPLAY_WIDTH,                  CAP_TYPE_UINT32),
    CAP_ENTRY(CAPID_DISPLAY_INFO,   CAP_DISPLAY_HEIGHT,                 CAP_TYPE_UINT32),
    CAP_ENTRY(CAPID_DISPLAY_INFO,   CAP_DISPLAY_X_MILLI_INCHES,         CAP_TYPE_UINT32),
    CAP_ENTRY(CAPID_DISPLAY_INFO,   CAP_DISPLAY_Y_MILLI_INCHES,         CAP_TYPE_UINT32),
    CAP_ENTRY(CAPID_DISPLAY_INFO,   CAP_DISPLAY_PIXELS_PER_INCH,        CAP_TYPE_UINT32),
    CAP_ENTRY(CAPID_DISPLAY_INFO,   CAP_DISPLAY_X_PIXELS_PER_INCH,      CAP_TYPE_UINT32),
    CAP_ENTRY(CAPID_DISPLAY_INFO,   CAP_DISPLAY_Y_PIXELS_PER_INCH,      CAP_TYPE_UINT32),
    CAP_ENTRY(CAPID_DISPLAY_INFO,   CAP_DISPLAY_INITIAL_ORIENTATION,    CAP_TYPE_UINT16),
    CAP_ENTRY(CAPID_DISPLAY_INFO,   CAP_DISPLAY_COLOR_DEPTH,            CAP_TYPE_UINT16),

    CAP_ENTRY(CAPID_SCROLL_MODES,       CAP_SCROLLMODES_ENABLE,             CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_SCROLL_MODES,       CAP_SCROLLMODES_MOUSEWHEEL_FLAG,    CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_SCROLL_MODES,       CAP_SCROLLMODES_DRAG_FLAG,          CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_SCROLL_MODES,       CAP_SCROLLMODES_PAN_FLAG,           CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_SCROLL_MODES,       CAP_SCROLLMODES_DEFAULT_MODE,       CAP_TYPE_UINT16),

    CAP_ENTRY(CAPID_BUTTON_SET_TARGET,  CAP_BUTTON_ENABLE,                  CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_BUTTON_SET_TARGET,  CAP_BUTTON_BACK,                    CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_BUTTON_SET_TARGET,  CAP_BUTTON_SEARCH,                  CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_BUTTON_SET_TARGET,  CAP_BUTTON_HOME,                    CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_BUTTON_SET_TARGET,  CAP_BUTTON_MENU,                    CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_BUTTON_SET_TARGET,  CAP_BUTTON_MASK,                    CAP_TYPE_UINT16),

    CAP_ENTRY(CAPID_TAKE_PICTURE,       CAP_TAKE_PICTURE_ENABLE,            CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_TAKE_PICTURE,       CAP_TAKE_PICTURE_JPEG,              CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_TAKE_PICTURE,       CAP_TAKE_PICTURE_PNG,               CAP_TYPE_BOOL),

    CAP_ENTRY(CAPID_DEVICE_INFO,            CAP_DEVICE_ENABLE,              CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_DEVICE_INFO,            CAP_DEVICE_OS,                  CAP_TYPE_UINT16),
    CAP_ENTRY(CAPID_DEVICE_INFO,            CAP_DEVICE_OS_VER_HIGH,         CAP_TYPE_UINT16),
    CAP_ENTRY(CAPID_DEVICE_INFO,            CAP_DEVICE_OS_VER_LOW,          CAP_TYPE_UINT16),
    CAP_ENTRY(CAPID_DEVICE_INFO,            CAP_DEVICE_OS_VER_MINOR,        CAP_TYPE_UINT16),
    CAP_ENTRY(CAPID_DEVICE_INFO,            CAP_DEVICE_OS_VER_BUILD,        CAP_TYPE_UINT16),
    CAP_ENTRY(CAPID_DEVICE_INFO,            CAP_DEVICE_TYPE,                CAP_TYPE_UINT16),

    CAP_ENTRY(CAPID_VIEWPORT,               CAP_VIEWPORT_ENABLE,            CAP_TYPE_BOOL),

    CAP_ENTRY(CAPID_DYNAMIC_DISPLAY,        CAP_DYNAMIC_DISPLAY_ENABLE,     CAP_TYPE_BOOL),

    CAP_ENTRY(CAPID_PICKER_CONTROL,         CAP_PICKER_CONTROL_ENABLE,      CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_PICKER_CONTROL,         CAP_PICKER_CONTROL_TITLE_FLAG,  CAP_TYPE_BOOL),

    CAP_ENTRY(CAPID_PHONE_CALL,             CAP_PHONE_CALL_ENABLE,          CAP_TYPE_BOOL),

    CAP_ENTRY(CAPID_SMS,                    CAP_SMS_ENABLE,                 CAP_TYPE_BOOL),

    CAP_ENTRY(CAPID_NOTIFICATION,           CAP_NOTIFICATION_ENABLE,        CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_NOTIFICATION,           CAP_NOTIFICATION_LIGHT,         CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_NOTIFICATION,           CAP_NOTIFICATION_VIBRATE,       CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_NOTIFICATION,           CAP_NOTIFICATION_AUDIO,         CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_NOTIFICATION,           CAP_NOTIFICATION_TEXT,          CAP_TYPE_BOOL),

    CAP_ENTRY(CAPID_RECEIVER_CONTROLS,      CAP_RECEIVER_CONTROLS_ENABLE,   CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_RECEIVER_CONTROLS,      CAP_RECEIVER_CONTROLS_DISABLE,  CAP_TYPE_BOOL),

    CAP_ENTRY(CAPID_EVENT_FILTER,           CAP_EVENT_FILTER_ENABLE,        CAP_TYPE_BOOL),
    CAP_ENTRY(CAPID_EVENT_FILTER,           CAP_EVENT_FILTER_SUPPORT,       CAP_TYPE_BOOL),

    CAP_ENTRY_END()
};


/*
 * Function protocols for worker functions
 */
CMPRESULT GetCapRecordValue(HANDLE hCMP, PCAP_RECORD pCur);
void ReportCapRecordValue(CMPRESULT rc, PCAP_RECORD pCur);
void ReportStatus(LPCSTR text, CMPRESULT rc);
void ReportStatusBool(LPCSTR text, CMPRESULT rc, BOOL value);
void ReportStatusUInt16(LPCSTR text, CMPRESULT rc, UINT16 value);
void ReportStatusInt32(LPCSTR text, CMPRESULT rc, INT32 value);
void ReportStatusUInt32(LPCSTR text, CMPRESULT rc, UINT32 value);

/*
 * main entry point for simple phone call program
 */
int __cdecl main(int argc, char **argv)
{
    CMPRESULT rc;
    HANDLE hCMP = NULL;

    // Initialize for STA (Single Thread Apartment) in COM
    rc = CMPInitialize(FALSE);

    ReportStatus("CMPInitialize", rc);

    // Open a handle to the mobile device
    rc = CMPOpen(&hCMP);

    ReportStatus("CMPOpen", rc);

    if(CMP_SUCCESS(rc))
    {
        // Open the link between the two sides (Citrix XenApp and Receiver)
        rc = CMPOpenSession(hCMP);

        ReportStatus("CMPOpenSession", rc);

        if(CMP_SUCCESS(rc))
        {
            PCAP_RECORD pCur = capDict;

            // Loop through all the capability identifiers and get the current values
            // Immediately report the values to the console
            while(pCur->capId != (CMP_CAP_ID)0)
            {
                rc = GetCapRecordValue(hCMP, pCur);

                ReportCapRecordValue(rc, pCur);

                pCur++;
            }

            // Wait for 10 seconds before exiting.  This is needed if the 
            // application is published and would normally exit right
            // away.  Without the sleep, the user will not see the
            // results.
            printf("\nWaiting for ten seconds before exiting\n");
            Sleep(10000);            

            // close our connection
            CMPCloseSession(hCMP);
        }

        // release our handle
        CMPClose(hCMP);
    }

    // uninitialize COM
    CMPUninitialize();

}

//! [GetCapRecordValue]
/*
    Get the capability value for the given capability record.
    Use the correct API based on type of capability.

    Parameters:

    hCMP      Handle to CMP object
    pCur      Pointer to Capability record
*/
CMPRESULT GetCapRecordValue(HANDLE hCMP, PCAP_RECORD pCur)
{
    CMPRESULT rc = CMP_NO_ERROR;

    switch(pCur->capType)
    {
        case CAP_TYPE_BOOL:
            rc = CMPGetCapabilityBool(hCMP, pCur->capId, pCur->capKeyId, (PBOOL)&pCur->capValue);
            break;

        case CAP_TYPE_UINT16:
            rc = CMPGetCapabilityUInt16(hCMP, pCur->capId, pCur->capKeyId, (PUINT16)&pCur->capValue);
            break;

        case CAP_TYPE_INT32:
            rc = CMPGetCapabilityInt32(hCMP, pCur->capId, pCur->capKeyId, (PINT32)&pCur->capValue);
            break;

        case CAP_TYPE_UINT32:
            rc = CMPGetCapabilityUInt32(hCMP, pCur->capId, pCur->capKeyId, (PUINT32)&pCur->capValue);
            break;

        default:
            break;
    }

    return(rc);
}
//! [GetCapRecordValue]

/*
    Get the capability value for the given capability record.
    Use the correct API based on type of capability.

    Parameters:

    rc        Status code from CMP
    pCur      Pointer to Capability record
*/
void ReportCapRecordValue(CMPRESULT rc, PCAP_RECORD pCur)
{
    switch(pCur->capType)
    {
        case CAP_TYPE_BOOL:
            ReportStatusBool(pCur->capKeyName, rc, (BOOL)pCur->capValue);
            break;

        case CAP_TYPE_UINT16:
            ReportStatusUInt16(pCur->capKeyName, rc, (UINT16)pCur->capValue);
            break;

        case CAP_TYPE_INT32:
            ReportStatusInt32(pCur->capKeyName, rc, (INT32)pCur->capValue);
            break;

        case CAP_TYPE_UINT32:
            ReportStatusUInt32(pCur->capKeyName, rc, (UINT32)pCur->capValue);
            break;

        default:
            break;
    }
}

/*
    Reports errors to console if they happen. 
    Only report errors and not successful calls.

    Parameters:

    text      Text message to include in error message
    rc        Error code reported from CMP
*/
void ReportStatus(LPCSTR text, CMPRESULT rc)
{
    // only print if something went wrong
    if(CMP_FAILURE(rc))
    {
        printf("%s CMPResult(%08X)\n", text, rc);
    }

    return;
}

/*
    Reports boolean capability values.
    Also reports errors if present.

    Parameters:

    text      Text message to include with boolean value
    rc        Status code reported from CMP
    value     Boolean value to report

*/
void ReportStatusBool(LPCSTR text, CMPRESULT rc, BOOL value)
{
    printf("%s", text);

    if(CMP_FAILURE(rc))
    {
        printf(" CMPResult(%08X)\n", rc);
    }
    else
    {
        printf("(%s)\n", value > 0 ? "ON" : "OFF");
    }
    
    return;
}

/*
    Reports UINT16 capability values.
    Also reports errors if present.

    Parameters:

    text      Text message to include with value
    rc        Status code reported from CMP
    value     Value to report

*/
void ReportStatusUInt16(LPCSTR text, CMPRESULT rc, UINT16 value)
{
    printf("%s", text);

    if(CMP_FAILURE(rc))
    {
        printf(" CMPResult(%08X)\n", rc);
    }
    else
    {
        printf("(%u)\n", value);
    }
    
    return;
}

/*
    Reports INT32 capability values.
    Also reports errors if present.

    Parameters:

    text      Text message to include with value
    rc        Status code reported from CMP
    value     Value to report

*/
void ReportStatusInt32(LPCSTR text, CMPRESULT rc, INT32 value)
{
    printf("%s", text);

    if(CMP_FAILURE(rc))
    {
        printf(" CMPResult(%08X)\n", rc);
    }
    else
    {
        printf("(%d)\n", value);
    }
    
    return;
}

/*
    Reports UINT32 capability values.
    Also reports errors if present.

    Parameters:

    text      Text message to include with value
    rc        Status code reported from CMP
    value     Value to report

*/
void ReportStatusUInt32(LPCSTR text, CMPRESULT rc, UINT32 value)
{
    printf("%s", text);

    if(CMP_FAILURE(rc))
    {
        printf(" CMPResult(%08X)\n", rc);
    }
    else
    {
        printf("(%u)\n", value);
    }
    
    return;
}
