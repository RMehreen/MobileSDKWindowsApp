﻿// C# Orientation example using with Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to display and change orientation
//
// Copyright (c) 2013 Citrix Systems
//
using System;
using System.Collections.Generic;
using System.Linq;
using CitrixMobility;
using System.Threading;

using CMPRESULT = System.Int32;

namespace supportedorientations
{
    static class Program
    {
        static CitrixMobile cmp;
        static AutoResetEvent orientationEvent = new AutoResetEvent(false);

        [STAThread]
        static void Main()
        {
            //initialise result to "No Error"
            CMPRESULT rc = (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Console.WriteLine("Creating CitrixMobile object");

                // Creates the CitrixMobile Object which contains all the CMP interfaces. e.g. IButton, ICamera
                cmp = new CitrixMobile();

                Console.WriteLine("Calling OpenSession");

                // Opens a connection to the remote mobile device
                // It is good practice to close the operation when no longer needed 
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    CMP_SUPPORTED_ORIENTATIONS supportedOrientations;

                    Console.WriteLine("Hooking SupportedOrientations changed event");

                    // register for SupportedOrientations changed event
                    RegisterForEvent();

                    Console.WriteLine("\nCMP Getting supported orientations");

                    //! [getsupportedorientations]
                    // Gets the current supported orientations of the device
                    rc = cmp.GetSupportedOrientations(out supportedOrientations);
                    //! [getsupportedorientations]

                    if (CMP_SUCCESS(rc))
                    {
                        // If successful, prints information of the current supported orientations of the device
                        Console.WriteLine("GetSupportedOrientations {0}\n", supportedOrientations.ToString());
                    }

                    Console.WriteLine("\nSetting supported orientations to Landscape Only.");
                    //! [setsupportedorientations]
                    // Sets the supported orientations to Landscape Only
                    rc = cmp.SetSupportedOrientations(CMP_SUPPORTED_ORIENTATIONS.CMP_SO_LANDSCAPE);
                    //! [setsupportedorientations]

                    // Gets the current supported orientations of the device
                    rc = cmp.GetSupportedOrientations(out supportedOrientations);

                    Console.WriteLine("Verifying SupportedOrientations changed to Landscape");

                    if (CMP_SUCCESS(rc))
                    {
                        // If successful, prints information of the current orientation of the device
                        Console.WriteLine("GetSupportedOrientations {0}\n", supportedOrientations.ToString());
                    }

                    // Waits for the mobile client to complete first supported orientations change event.
                    // (Android may take up to 30 seconds)
                    Console.WriteLine("Waiting for client to update orientations...");
                    orientationEvent.WaitOne(60000);
                    orientationEvent.Reset();

                    Console.WriteLine("\nSuccess! Rotate the device to test that the orientation is locked to LANDSCAPE.\n");
                    // Let events come in over the next 30 seconds
                    WaitForCMPEvents(30); 

                    // Unlock the orientation
                    rc = cmp.SetSupportedOrientations(CMP_SUPPORTED_ORIENTATIONS.CMP_SO_ALL); 
                    Console.WriteLine("\nSupported Orientations reset to default.\n");

                    WaitForCMPEvents(15);
                }
                else
                {
                    Console.WriteLine("OpenSession failed rc={0:X}", rc);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }
        /// <summary>
        /// Check CMP return code for success.
        /// </summary>
        static bool CMP_SUCCESS(CMPRESULT rc)
        {
            // Need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR);
        }       

        //
        // A "wait" method which allows events to occur
        //
        static void WaitForCMPEvents(int seconds)
        {
            for (int i = 0; i < seconds; i++)
            {
                Thread.Sleep(1000);
            }
        }

        //! [eventhandler]
        // <summary>
        // SupportedOrientationsChanged event handler
        // </summary>
        // <param name="rc">Return code.</param>
        // <param name="supportedOrientations">The supported orientations.</param>
        private static void cmp_SupportedOrientationsChanged(CMPRESULT rc, CMP_SUPPORTED_ORIENTATIONS supportedOrientations)
        {
            if (CMP_SUCCESS(rc))
            {
                // If successful, prints information of the current supported orientations of the device
                Console.WriteLine("\nSupportedOrientationsChanged event {0}\n", supportedOrientations.ToString());
                orientationEvent.Set();
            }
        }
        //! [eventhandler]

        /// <summary>
        /// Register for SupportedOrientations changed event
        /// </summary>
        static void RegisterForEvent()
        {
            //! [eventsubscription]
            // Subscribe to SupportedOrientations changed event.
            cmp.SupportedOrientationsChanged += new ICMPEvents_SupportedOrientationsChangedEventHandler(cmp_SupportedOrientationsChanged);
            //! [eventsubscription]
        }
    }
}
