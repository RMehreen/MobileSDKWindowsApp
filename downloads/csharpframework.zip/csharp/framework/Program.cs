﻿// C# Take picture example using COM Interop with Citrix Mobility SDK
//
// Sample Framework
//
// Copyright (c) 2012 Citrix Systems
//
//! [csharpframework]
using System;
using System.Collections.Generic;
using System.Linq;
using CitrixMobility;   //add reference: Interop.CitrixMobility.dll 
using System.Collections;
using System.Threading;
using System.IO;

using CMPRESULT = System.Int32;

namespace Sample
{
    static class Program
    {
        static CitrixMobile cmp;

        //
        // Main entry point for sample program.
        //      
        [STAThread]
        static void Main()
        {
            CMPRESULT rc = (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Console.WriteLine("Creating CitrixMobile object");

                // Part 1:
                // =======
                // Open a handle to the mobile device.
                cmp = new CitrixMobile();

                Console.WriteLine("Calling OpenSession");
                
                // Part 2:
                // =======
                // Establish a CMP session.
                // Opens a connection to the remote mobile device
                // It is good practice to close the operation when no longer needed 
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    Console.WriteLine("Hooking sample event");
                    
                    // Part 3:
                    // =======
                    // Register event callback corresponding to the ICMPEvent call below.

                    //cmp.ICMPEvent_SampleEventHandler += new ICMPEvent_SampleEventHandler(cmp_SampleEventHandler);
                    
                    // Call the CMP framework API. In this example, the result of the API is provided
                    // in the event callback which was registered above (cmp_SampleEventHandler).

                    //rc = cmp.StartSample();
                }
                else
                {
                    Console.WriteLine("OpenSession failed rc={0:X}", rc);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }

        //
        // <summary>
        // Check CMP return code for success.
        // </summary>
        //
        static bool CMP_SUCCESS(CMPRESULT rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR);
        }        
        
        // Part 4: Implement the event handler for cmp_SampleEventHandler.
        // ===============================================================
        // <summary>
        // Sample event handler.
        // </summary>
        //
        static void cmp_SampleEventHandler()
        {
            // Do stuff...
            //... 
        }
                

    }
}
//! [csharpframework]