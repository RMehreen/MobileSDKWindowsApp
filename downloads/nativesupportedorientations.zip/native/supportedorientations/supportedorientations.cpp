// C++ Set and Get Supported Orientation example using Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to set and get possible orientation states.
//
// Copyright (c) 2013 Citrix Systems
//

#include <stdio.h>
#include <windows.h>

#include <cmp.h>

// Local functions
void        ReportStatus(LPCSTR text, CMPRESULT rc);
void        WaitForCMPEvents(int seconds);
CMPRESULT   RegisterForEvent(HANDLE hCMP);
CMPRESULT   GetSupportedOrientations(HANDLE hCMP, CMP_SUPPORTED_ORIENTATIONS *supportedOrientations);
CMPRESULT   SetSupportedOrientations(HANDLE hCMP, CMP_SUPPORTED_ORIENTATIONS supportedOrientations);

// local variables
HANDLE      hOrientationEvent = NULL;

//
// main entry point
//
int __cdecl main(int argc, char **argv)
{
    CMPRESULT rc;
    HANDLE hCMP = NULL;

    // create an event that is not manual reset with initial state set to non-signaled
    hOrientationEvent = CreateEvent(NULL, FALSE, FALSE, NULL);

    // initialize for STA (Single Thread Apartment) in COM
    rc = CMPInitialize(FALSE);

    ReportStatus("CMPInitialize", rc);

    // Open a handle to the mobile device
    rc = CMPOpen(&hCMP);

    ReportStatus("CMPOpen", rc);

    if(CMP_SUCCESS(rc))
    {
        // open the link between the two sides
        rc = CMPOpenSession(hCMP);

        ReportStatus("CMPOpenSession", rc);

        if(CMP_SUCCESS(rc))
        {
            CMP_SUPPORTED_ORIENTATIONS supportedOrientations;

            // register for SupportedOrientationsChanged event
            rc = RegisterForEvent(hCMP);

            printf("Getting current supported orientations.\n");
            // get the supported orientation
            rc = GetSupportedOrientations(hCMP, &supportedOrientations);
            if(CMP_SUCCESS(rc))
            {
                printf("GetSupportedOrientations (0x%x)\n", supportedOrientations);
            }

            printf("\nSetting supported orientations to Landscape Only.\n");
            // set the supported orientation to Landscape Only
            rc = SetSupportedOrientations(hCMP, CMP_SO_LANDSCAPE);

            printf("\nVerifying supported orientations change.\n");
            // Now get the new supported orientation
            rc = GetSupportedOrientations(hCMP, &supportedOrientations);
            if(CMP_SUCCESS(rc))
            {
                printf("\nGetSupportedOrientations (0x%x)\n", supportedOrientations);
            }

            // Waits for the mobile client to complete first supported orientations change event.
            // (Android may take up to 30 seconds)
            printf("\nWaiting for client to update orientations...\n");
            WaitForSingleObject(hOrientationEvent, 60000);

            printf("\nSuccess! Rotate the device to test that the orientation is locked to LANDSCAPE.\n");
            WaitForCMPEvents(30);

            // Set the supported orientations back to all supported
            rc = SetSupportedOrientations(hCMP, CMP_SO_ALL);

            printf("\nSupported Orientations reset to default.\n");
            WaitForCMPEvents(15);

            // close our connection
            CMPCloseSession(hCMP);
        }

        // release our handle
        CMPClose(hCMP);
    }

    // uninitialize COM
    CMPUninitialize();

}

/// <summary>
/// Check CMP return code for success and report errors if they happen.
/// </summary>
void ReportStatus(LPCSTR text, CMPRESULT rc)
{
    // only print if something went wrong
    if(CMP_FAILURE(rc))
    {
        printf("%s CMPResult(%08X)\n", text, rc);
    }

    return;
}

//
// A "wait" method which allows events to occur
//
void WaitForCMPEvents(int seconds)
{
    for(int i=0; i<seconds; i++)
    {
        Sleep(1000);
    }
}

//! [eventhandler]
// <summary>
// SupportedOrientationsChanged event handler.
// </summary>
// <param name="hCMP">CMP handler.</param>
// <param name="rc">Return code.</param>
// <param name="supportedOrientation">Supported orientation.</param>
void CMPAPI SupportedOrientationsChanged(
    HANDLE hCMP, 
    CMPRESULT rc, 
    CMP_SUPPORTED_ORIENTATIONS supportedOrientation)
{
    printf("SupportedOrientationsChanged event supportedOrientation(0x%x)\n", supportedOrientation);
    SetEvent(hOrientationEvent);
}

//! [eventhandler]

// <summary>
// Register for the supported orientation changed event.
// </summary>
CMPRESULT RegisterForEvent(HANDLE hCMP)
{
    CMPRESULT rc;

    //! [eventsubscription]
    // Subscribe to SupportedOrientationsChanged event.
    rc = CMPRegisterForEvent(hCMP, CMP_EVENT_SUPPORTED_ORIENTATIONS_CHANGED, (CMP_EVENT_CALLBACK)SupportedOrientationsChanged); 
    //! [eventsubscription]

    ReportStatus("CMPRegisterForEvent CMP_EVENT_SUPPORTED_ORIENTATIONS_CHANGED", rc);

    return(rc);
}

// <summary>
// Get the current supported orientations.
// </summary>
CMPRESULT GetSupportedOrientations(HANDLE hCMP, CMP_SUPPORTED_ORIENTATIONS *supportedOrientations)
{
    CMPRESULT rc;

    //! [getsupportedorientations]
    // Gets the supported orientations.
    rc = CMPGetSupportedOrientations(hCMP, supportedOrientations);
    //! [getsupportedorientations]

    ReportStatus("CMPGetSupportedOrientations", rc);

    return(rc);
}

// <summary>
// Set the supported orientations.
// </summary>
CMPRESULT SetSupportedOrientations(HANDLE hCMP, CMP_SUPPORTED_ORIENTATIONS supportedOrientations)
{
    CMPRESULT rc;

    //! [setsupportedorientations]
    // Sets the supported orientations of the app.
    rc = CMPSetSupportedOrientations(hCMP, supportedOrientations);
    //! [setsupportedorientations]

    ReportStatus("CMPSetSupportedOrientations", rc);

    return(rc);
}
