//
// C++ Framework example using Citrix Mobility Pack SDK
//
// Copyright (c) 2012 Citrix Systems
//
//! [nativeframework]


// Important note: This will not build without changing the type of event handler and
// the actual API is called.  This is just a template for a simple program to show
// the basic structure.

#include <stdio.h>
#include <windows.h>

#include <cmp.h>

// local functions
void CMPAPI SampleEventHandler(HANDLE hCMP, CMPRESULT rc, CMP_UNIQUE_ID uniqueId);
void ReportStatus(LPCSTR text, CMPRESULT rc);
void WaitForCMPEvents(int seconds);

//
// Main entry point for sample program.
//
int __cdecl main(int argc, char **argv)
{
    CMPRESULT rc;
    HANDLE hCMP = NULL;

    // Initialize for STA (Single Thread Apartment) in COM.
    rc = CMPInitialize(FALSE);

    ReportStatus("CMPInitialize", rc);

    // Part 1:
    // =======
    // Open a handle to the mobile device.
    rc = CMPOpen(&hCMP);
    ReportStatus("CMPOpen", rc);

    if(CMP_SUCCESS(rc))
    {
        // Part 2:
        // =======
        // Establish a CMP session.
        rc = CMPOpenSession(hCMP);
        ReportStatus("CMPOpenSession", rc);

        if(CMP_SUCCESS(rc))
        {
            // Part 3:
            // =======
            // Register event callback corresponding to the CMPSampleAPI call below.
            // Change the EventId to a real value instead of SAMPLE_EVENT.

            // rc = CMPRegisterForEvent(hCMP, SAMPLE_EVENT, (CMP_EVENT_CALLBACK)SampleEventHandler); 

            ReportStatus("CMPRegisterForEvent SAMPLE_EVENT", rc);

            // Call the CMP framework API. In this example, the result of the API is provided
            // in the event callback which was registered above (SampleEventHandler).
            // Change CMPSampleAPI to a real call into the API (like CMPStartCall)

            // rc = CMPSampleAPI(hCMP, ...);

            ReportStatus("CMPSampleAPI ", rc);

            // Wait for events to come through over the next 30 seconds.
            // If this was a Windows application and with a message loop, generally there is no need to do this.
            WaitForCMPEvents(30);

            // Part 5:
            // =======
            // Close the CMP session.
            CMPCloseSession(hCMP);
        }

        // Part 6:
        // =======
        // Release the handle to the mobile device.
        CMPClose(hCMP);
    }

    // Uninitialize COM.
    CMPUninitialize();
}

//
// <summary>
// Check CMP return code for success and report errors if they happen.
// </summary>
//
void ReportStatus(LPCSTR text, CMPRESULT rc)
{
    // Only print if something went wrong.
    if(CMP_FAILURE(rc))
    {
        printf("%s CMPResult(%08X)\n", text, rc);
    }

    return;
}

// Part 4: Implement the event handler for CMPSampleAPI.
// =====================================================
// <summary>
// Sample event handler.
// </summary>
//
void CMPAPI SampleEventHandler(HANDLE hCMP, CMPRESULT rc, CMP_UNIQUE_ID uniqueId)
{
    // Do stuff...
    // ...
}

//! [nativeframework]

// <summary>
// A "wait" spin loop to give the events a chance to happen
// </summary>
void WaitForCMPEvents(int seconds)
{
    for(int i=0; i<seconds; i++)
    {
        Sleep(1000);
    }
}
