﻿// C# Take picture example using Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to take a picture and transfer it to server.
//
// Copyright (c) 2013 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.Linq;
using CitrixMobility;
using System.Collections;
using System.Threading;
using System.IO;

namespace capturepicture
{
    static class Program
    {
        struct PICTURE_DATA
        {
            public Int32 pictureResult;
            public long pictureId;
            public CMP_IMAGE_FORMAT pictureFormat;
            public int pictureSize;
            public string filename;

            public PICTURE_DATA(Int32 result, long id, CMP_IMAGE_FORMAT format, int size, string name)
            {
                pictureResult = result;
                pictureId = id;
                pictureFormat = format;
                pictureSize = size;
                filename = name;
            }
        };

        // pictureId is initialized during the call to CapturePicture
        static long pictureId = 0;

        static CitrixMobile cmp;
        static PICTURE_DATA pictureData;
        static AutoResetEvent captureProcessed = new AutoResetEvent(false);

        [MTAThread]
        static void Main()
        {
            // Picture event data
            pictureData = new PICTURE_DATA((Int32)CMP_ERROR_ID.CMP_NO_ERROR, 0, (CMP_IMAGE_FORMAT)0, 0, null);

            Int32 rc = (Int32)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Console.WriteLine("Creating CitrixMobile object");

                // Creates the CitrixMobile Object which contains all the CMP interfaces. e.g. IButton, ICamera
                cmp = new CitrixMobile();

                Console.WriteLine("Calling OpenSession");

                // Opens a connection to the remote mobile device
                // It is good practice to close the operation when no longer needed 
                // rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {

                    // register for picture captured event
                    RegisterForEvent();

                    // take a picture
                    rc = CapturePicture();

                    if (CMP_SUCCESS(rc))
                    {
                        // Block and wait for the picture taken event to arrive and processed.
                        // The wait will timeout in 60 seconds.
                        // The picture is processed in the event handler and captureProcessed 
                        // is signalled once complete.
                        captureProcessed.WaitOne(60000);
                    }
                    else
                    {
                        // report an error with capture
                        ReportError(rc);
                    }

                    Thread.Sleep(10000);
                }
                else
                {
                    Console.WriteLine("OpenSession failed rc={0:X}", rc);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }

        /// <summary>
        /// Check CMP return code for success.
        /// </summary>
        static bool CMP_SUCCESS(Int32 rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (Int32)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        //! [eventhandler]
        // <summary>
        // PictureCaptured event handler.
        // </summary>
        // <param name="result">Picture result.</param>
        // <param name="pictureId">Picture identifier.</param>
        // <param name="pictureFormat">Picture format.</param>
        // <param name="pictureSize">Picture size.</param>
        // <param name="filename">Picture filename.</param>
        static void cmp_PictureCaptured(int result, long eventPictureId, string pictureMetadata, string filename, string thumbnail, int pictureSize, 
                                        CMP_CAPTURE_QUALITY Quality, CMP_CAPTURE_CAMERA CameraSelection, CMP_IMAGE_FORMAT encoding, 
                                        int DesiredWidth, int DesiredHeight, CMP_THUMBNAIL_TYPE ThumbnailType, short ThumbnailWidth, short ThumbnailHeight)
        {

            Console.WriteLine("PictureCaptured event\n");
            
            // only process picture if it is one of ours
            if (pictureId == eventPictureId)
            {
                if (CMP_SUCCESS(result))
                {
                    // Copy the relevant data and then signal the event
                    pictureData.pictureResult = result;
                    pictureData.pictureId = pictureId;
                    pictureData.pictureFormat = encoding;
                    pictureData.pictureSize = pictureSize;
                    pictureData.filename = filename;

                    Console.WriteLine("Picture result({0:X}) id({1:X}) format({2}) size({3}) filename({4})\n",
                                   result, pictureId, encoding, pictureSize, filename);

                    //Save the capture to the local temporary directory (keeping the same file name and extension).
                    string newLocation = System.IO.Path.GetTempPath() + System.IO.Path.GetFileName(filename);

                    Console.WriteLine("CMPGetFilename mobileFilename({0}) newLocation({1})", filename, newLocation);

                    Console.WriteLine("Copying file..\n");

                    File.Copy(filename, newLocation, true);

                    Console.WriteLine("Copy succeeded\n");

                    Console.WriteLine("Opening file in default application...\n");

                    System.Diagnostics.Process.Start(newLocation);
                }
                captureProcessed.Set();
            }
        }
        //! [eventhandler]

        // <summary>
        // Register for picture taken event
        // </summary>
        static void RegisterForEvent()
        {
            Console.WriteLine("Hooking picture taken event");

            //! [eventsubscription]
            // Subscribed PictureTaken event.
            cmp.PictureCaptured += new ICMPEvents_PictureCapturedEventHandler(cmp_PictureCaptured);
            //! [eventsubscription]
        }

        // <summary>
        // Request a picture to be taken
        // </summary>
        static Int32 CapturePicture()
        {
            Int32 rc;

            // Request a picture to be taken.
            Console.WriteLine("Request a picture to be captured");

            //! [capturepicture]
            // Request a JPEG picture to be taken.
            CMP_CAPTURE_PICTURE_OPTIONS options = new CMP_CAPTURE_PICTURE_OPTIONS();

            options.Quality         = CMP_CAPTURE_QUALITY.CMP_CAPTURE_QUALITY_LOW;
            options.CameraSelection = CMP_CAPTURE_CAMERA.CMP_CAPTURE_CAMERA_DEFAULT;
            options.Encoding        = CMP_IMAGE_FORMAT.CMP_IMAGE_FORMAT_JPEG;
            options.DesiredHeight   = 0;
            options.DesiredWidth    = 0;
            options.ThumbnailType   = CMP_THUMBNAIL_TYPE.CMP_THUMBNAIL_NONE;
            options.ThumbnailHeight = 0;
            options.ThumbnailWidth  = 0;

            rc = cmp.CapturePicture(ref options, out pictureId);
            //! [capturepicture]

            Console.WriteLine("Capture picture request sent");

            return (rc);
        }

        // <summary>
        // Report an error with relation to TakePicture
        // </summary>
        static void ReportError(Int32 rc)
        {
            CMP_ERROR_ID err = (CMP_ERROR_ID)rc;

            Console.WriteLine("Error {0:X} with CapturePicture", rc);

            switch (err)
            {
                case CMP_ERROR_ID.CMP_ERROR_CLIENT_DRIVE_UNAVAILABLE:
                    Console.WriteLine("Client Drive unavailable. Check session options on Receiver.");
                    break;
                case CMP_ERROR_ID.CMP_ERROR_CAPABILITY_NOT_SUPPORTED:
                    Console.WriteLine("This device does not support picture capture.");
                    break;
                default:
                    break;
            }
        }

    }
}
