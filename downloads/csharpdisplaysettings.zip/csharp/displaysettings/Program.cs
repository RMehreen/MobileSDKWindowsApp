﻿//
// C# Display Settings example using Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to reveal display settings
// Retrieves information on the device's display settings after a change 
// in the settings is detected (through a change orientation) and prints them out on the console window.
//
// Copyright (c) 2012 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.Linq;
using CitrixMobility;
using System.Runtime.InteropServices;
using System.Threading;

using CMPRESULT = System.Int32;

namespace displaysettings
{
    class Program
    {
        static CitrixMobile cmp;

        [STAThread]
        static void Main()
        {
            // Initialise result to "No Error"
            CMPRESULT rc = (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Console.WriteLine("Creating CitrixMobile object");

                // Creates the CitrixMobile Object which contains all the CMP interfaces. e.g. IButton, ICamera
                cmp = new CitrixMobile();

                Console.WriteLine("Calling OpenSession");

                // Opens a connection to the remote mobile device
                // It is good practice to close the operation when no longer needed 
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    // Creating the object "CMP Display Settings"
                    CMP_DISPLAY_SETTINGS displaySettings = new CMP_DISPLAY_SETTINGS();
                    
                    Console.WriteLine("Hooking display settings changed event");

                    // register for the display settings event
                    RegisterForEvent();

                    // get the current display settings
                    rc = GetDisplaySettings(ref displaySettings);

                    if (CMP_SUCCESS(rc))
                    {
                        // Prints information of the current display settings of the device
                        ReportDisplaySettings(displaySettings);
                    }

                    Console.WriteLine("\nRotate the device to test the display settings change event\n");

                    // Let events come in over the next 30 seconds
                    // If this was a Windows program and we had a message loop, we would not need to do this
                    WaitForCMPEvents();
                }
                else
                {
                    Console.WriteLine("OpenSession failed rc={0:X}", rc);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }

        /// <summary>
        /// Prints the new display settings on the console window when a change occurs.
        /// </summary>
        /// <param name="displaySettings">CMP Display settings.</param>
        static void ReportDisplaySettings(CMP_DISPLAY_SETTINGS displaySettings)
        {
            Console.WriteLine("Metrics flags({0:X})\n", displaySettings.MetricsFlags);
            Console.WriteLine("Pixel width({0:X}) height({1:X})\n", displaySettings.PixelWidth, displaySettings.PixelHeight);
            Console.WriteLine("Color depth({0:X})\n", displaySettings.ColorDepth);
            Console.WriteLine("PPI X({0:X}) Y({1:X})\n", displaySettings.HorizontalPixelsPerInch, displaySettings.VerticalPixelsPerInch);
            Console.WriteLine("Orientation({0:X})\n", displaySettings.DeviceOrientation);
            Console.WriteLine("Physical width({0:X}) height({1:X}) MilliInches\n", displaySettings.WidthMilliInches, displaySettings.HeightMilliInches);
            Console.WriteLine("Display settings structure length({0:X})\n", displaySettings.Length);
        }

        /// <summary>
        /// Register for the display settings changed event
        /// </summary>
        static CMPRESULT RegisterForEvent()
        {
            CMPRESULT rc = (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR;

            //! [eventsubscription]
            // Subscribed to DisplaySettings event.
            cmp.DisplaySettingsChanged += new ICMPEvents_DisplaySettingsChangedEventHandler(cmp_DisplaySettingsChanged);
            //! [eventsubscription]

            return (rc);
        }

        /// <summary>
        /// Get the display settings
        /// </summary>
        /// <param name="displaySettings">Display settings.</param>
        static CMPRESULT GetDisplaySettings(ref CMP_DISPLAY_SETTINGS displaySettings)
        {
            CMPRESULT rc;

            Console.WriteLine("initialize the length of display settings");

            // Best practice to initialize the length of the structure.
            displaySettings.Length = (short)Marshal.SizeOf(displaySettings);

            Console.WriteLine("Get display settings");

            //! [getdisplaysettings]
            // Gets the current display settings of the device.
            // and stores it into the variable "displaySettings" of type CMP_DISPLAY_SETTINGS.
            rc = cmp.GetDisplaySettings(out displaySettings);
            //! [getdisplaysettings]

            return (rc);
        }

        //! [eventhandler]
        // <summary>
        // Display Settings event handler.
        // </summary>
        // <param name="metricsFlags">Metrix flags.</param>
        // <param name="pixelWidth">Pixel width.</param>
        // <param name="pixelHeight">Pixel height.</param>
        // <param name="colorDepth">Colour depth.</param>
        // <param name="XPixelsPerInch">X-axis pixels per inch.</param>
        // <param name="YPixelsPerInch">Y-axis pixels per inch.</param>
        // <param name="DeviceOrientation">Device Orientation</param>
        // <param name="WidthMilliInches">Width milli-inches</param>
        // <param name="HeightMilliInches">Heigth milli-inches</param>
        // <param name="normalizedDPI">Normalised dots per inch</param>
        static void cmp_DisplaySettingsChanged(
            short metricsFlags,
            int pixelWidth,
            int pixelHeight,
            short colorDepth,
            int XPixelsPerInch,
            int YPixelsPerInch,
            CMP_ORIENTATION_POSITION DeviceOrientation,
            int WidthMilliInches,
            int HeightMilliInches,
            int normalizedDPI)
        {
            Console.WriteLine(
                "DisplaySettingsChanged MetricsFlags({0:X})" +
                "pixelWidth({1:X}) pixelHeight({2:X})\n colorDepth({3:X}) " +
                "xPixelsPerInch({4:X}) yPixelsPerInch({5:X})\n orientation({6:X}) " +
                "widthMilliInches({7:X}) heightMilliInches({8:X})\n normalizedDPI({9:X})\n",
                metricsFlags, pixelWidth, pixelHeight,
                colorDepth, XPixelsPerInch, YPixelsPerInch,
                DeviceOrientation, WidthMilliInches,
                HeightMilliInches, normalizedDPI);
        }
        //! [eventhandler]

        /// <summary>
        /// Check CMP return code for success.
        /// </summary>
        static bool CMP_SUCCESS(CMPRESULT rc)
        {
            // Need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        /// <summary>
        /// Wait for thirty seconds for any events to come in 
        /// </summary>
        static void WaitForCMPEvents()
        {
            for (int i = 0; i < 30; i++)
            {
                Thread.Sleep(1000);
            }
        }

    }
}
