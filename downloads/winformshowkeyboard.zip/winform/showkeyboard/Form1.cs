﻿// C# Show keyboard example using COM Interop with Citrix Mobility SDK
//
// Uses Citrix Mobility SDK to show a display keyboard
//
// Copyright (c) 2012 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using CitrixMobility;

namespace showkeyboard
{
    public partial class Form1 : Form
    {
        // <summary>
        // Instance of CitrixMobile.
        // </summary>
        private CitrixMobile cmp = null;

        // <summary>
        // ICA session connected state.
        // </summary>
        private bool icaSessionConnected = false;

        // <summary>
        // Check CMP return code for success.
        // </summary>
        public static bool CMP_SUCCESS(int rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (int)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        // <summary>
        // Dispatch action to UI thread if necessary.
        // </summary>
        // <param name="action">The action.</param>
        private void UiDispatch(Action action)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(action);
            }
            else
            {
                action();
            }
        }

        // <summary>
        // Report CMP status.
        // </summary>
        // <param name="text">Status text.</param>
        // <param name="rc">CMP return code.</param>
        private void ReportStatus(string text, int rc)
        {
            // Only report status if something went wrong.
            if (!CMP_SUCCESS(rc))
            {
                string msg = string.Format("{0}, CMPResult: 0x{1:X}", text, rc);

                // Write to trace output.
                Helpers.Trace(msg);
                // Update status text.
                UiDispatch(() => this.status.Text = msg);
            }
        }

        public Form1()
        {
            InitializeComponent();

            // Initialises CMP framework.
            InitialiseCmp();
        }

        // <summary>
        // Initialise CMP framework.
        // </summary>
        private void InitialiseCmp()
        {
            int rc = (int)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Helpers.Trace("Creating CitrixMobile object");
                // Create an instance of CitrixMobile object.
                cmp = new CitrixMobile();

                Helpers.Trace("Register for ICA session state changed events");
                // Register for ICA session events.
                cmp.SessionStateChanged += new ICMPEvents_SessionStateChangedEventHandler(cmp_SessionStateChanged);

                Helpers.Trace("Calling OpenSession");
                // Open CMP session.
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    icaSessionConnected = true;

                    Helpers.Trace("Register for keyboard state changed events");
        //! [eventsubscription]
        // Register for keyboard events.
        cmp.KeyboardStateChanged += new ICMPEvents_KeyboardStateChangedEventHandler(cmp_KeyboardStateChanged);
        //! [eventsubscription]
                }
                else
                {
                    ReportStatus("OpenSession failed", rc);
                }
            }
            catch (System.Exception ex)
            {
                Helpers.Trace(ex.Message);
                Helpers.Trace(ex.StackTrace);
            }
        }

        // <summary>
        // Tear down CMP connection when closed.
        // </summary>
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (null != cmp)
            {
                // Close CMP session.
                cmp.CloseSession();
                cmp = null;
            }
        }

        // <summary>
        // Session state change handler.
        // </summary>
        // <remarks>Update the ICA session state upon connect/disconnect.</remarks>
        // <param name="SessState">Session state</param>
        void cmp_SessionStateChanged(CMP_SESSION_STATE SessState)
        {
            switch (SessState)
            {
                case CMP_SESSION_STATE.CMP_SESSION_STATE_CONNECTED:
                    icaSessionConnected = true;
                    break;
                case CMP_SESSION_STATE.CMP_SESSION_STATE_DISCONNECTED:
                    icaSessionConnected = false;
                    break;
                default:
                    break;
            }
        }

        //! [eventhandler]
        // <summary>
        /// Keyboard state changed handler.
        // </summary>
        // <param name="rc">Return code.</param>
        // <param name="KybdType">Type of keyboard that is displayed.</param>
        // <param name="KybdFlags">Flags associated with keyboard.</param>
        // <param name="KybdAutoCaps">Auto capitalization mode selected.</param>
        // <param name="KybdReturnKey">Return key text selected.</param>
        void cmp_KeyboardStateChanged(
            int rc,
            CMP_KEYBOARD_TYPE KybdType,
            short KybdFlags,
            CMP_KEYBOARD_AUTOCAPS KybdAutoCaps,
            CMP_KEYBOARD_RETURNKEY KybdReturnKey)
        {
            Helpers.Trace("rc:{0:X}, KybdType:{1:X}, KybdFlags:{2:X}, KybdAutoCaps:{3:X}, KybdReturnKey:{4:X}",
                rc, KybdType, KybdFlags, KybdAutoCaps, KybdReturnKey);
        }
        //! [eventhandler]

        // <summary>
        // Handler for TextBox gaining input focus.
        // </summary>
        private void textBox2_Enter(object sender, EventArgs e)
        {
            try
            {
                // Only handle input focus if the ICA session is connected.
                if ((null != cmp) && icaSessionConnected)
                {
        //! [showkeyboard]
        CMP_KEYBOARD_STATE kybdState = new CMP_KEYBOARD_STATE();
                    
        // Request to show the standard keyboard.
        kybdState.KybdType = CMP_KEYBOARD_TYPE.CMP_KYBD_TYPE_STANDARD;

        // Request that auto-capitalize support to be enabled where applicable.
        kybdState.KybdFlags = (short)CMP_KEYBOARD_FLAGS.CMP_KYBD_FLAG_AUTO_CAPITAL;

        // Show keyboard when we gain input focus.
        int rc = cmp.ShowKeyboard(ref kybdState);
        //! [showkeyboard]

                    if (CMP_SUCCESS(rc))
                    {
                        Helpers.Trace("ShowKeyboard success");
                    }
                    else
                    {
                        ReportStatus("ShowKeyboard failed", rc);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Helpers.Trace(ex.Message);
                Helpers.Trace(ex.StackTrace);
            }
        }

        // <summary>
        // Handler for TextBox losing input focus.
        // </summary>
        // <param name="sender">Not used.</param>
        // <param name="e">Not used.</param>
        private void textBox2_Leave(object sender, EventArgs e)
        {
            try
            {
                // Only handle input focus if the ICA session is connected.
                if ((null != cmp) && icaSessionConnected)
                {
        //! [hidekeyboard]
        // Hide the keyboard when we lose focus.
        int rc = cmp.HideKeyboard();
        //! [hidekeyboard]

                    if (CMP_SUCCESS(rc))
                    {
                        Helpers.Trace("HideKeyboard success");
                    }
                    else
                    {
                        ReportStatus("HideKeyboard failed", rc);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Helpers.Trace(ex.Message);
                Helpers.Trace(ex.StackTrace);
            }
        }
    }
}
