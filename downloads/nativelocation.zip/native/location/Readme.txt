Samples for C/C++ applications making use of location APIs can be found on MSDN at 
http://msdn.microsoft.com/en-us/library/dd317747(v=VS.85).aspx

Also look at the samples provided with the Microsoft Windows SDK v7.1, under 
Samples\winui\Location
