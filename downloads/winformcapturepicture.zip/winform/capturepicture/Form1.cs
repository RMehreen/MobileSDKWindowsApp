﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

using CitrixMobility;
using CMPRESULT = System.Int32;
using CMP_UNIQUE_LONG_ID = System.Int64;

namespace capturepicture
{
    public partial class Form1 : Form
    {
        // <summary>
        // Instance of CitrixMobile.
        // </summary>
        private CitrixMobile cmp = null;

        // <summary>
        // Picture capture ID.
        // </summary>
        private CMP_UNIQUE_LONG_ID captureId;

        // <summary>
        // Picture capture options.
        // </summary>
        private CMP_CAPTURE_PICTURE_OPTIONS options;

        // <summary>
        // ICA session connected state.
        // </summary>
        private bool icaSessionConnected = false;

        // <summary>
        // Indicates whether capture processing is in progress.
        // </summary>
        private bool processingCapture = false;

        // <summary>
        // Lock object.
        // </summary>
        private object stateLock = new object();

        // <summary>
        // Check CMP return code for success.
        // </summary>
        public static bool CMP_SUCCESS(int rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (int)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        // <summary>
        // Dispatch action to UI thread if necessary.
        // </summary>
        // <param name="action">The action.</param>
        private void UiDispatch(Action action)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(action);
            }
            else
            {
                action();
            }
        }

        // <summary>
        // Report CMP status.
        // </summary>
        // <param name="text">Status text.</param>
        // <param name="rc">CMP return code.</param>
        private void ReportStatus(string text, int rc)
        {
            // Only report status if something went wrong.
            if (!CMP_SUCCESS(rc))
            {
                string msg = string.Format("{0}, CMPResult: 0x{1:X}", text, rc);

                // Write to trace output.
                Helpers.Trace(msg);
                // Update status text.
                UpdateStatus(msg);
            }
        }

        public Form1()
        {
            InitializeComponent();

            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;

            // Initialises CMP framework.
            InitialiseCmp();
        }

        // <summary>
        // Initialise CMP framework.
        // </summary>
        private void InitialiseCmp()
        {
            int rc = (int)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Helpers.Trace("Creating CitrixMobile object");
                // Create an instance of CitrixMobile object.
                cmp = new CitrixMobile();

                Helpers.Trace("Register for ICA session state changed events");
                // Register for ICA session events.
                cmp.SessionStateChanged += new ICMPEvents_SessionStateChangedEventHandler(cmp_SessionStateChanged);

                Helpers.Trace("Calling OpenSession");
                // Open CMP session.
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    icaSessionConnected = true;

                    Helpers.Trace("Register for PictureCaptured event");
                    //! [eventsubscription]
                    // Register for PictureCaptured event.
                    cmp.PictureCaptured += new ICMPEvents_PictureCapturedEventHandler(cmp_PictureCaptured);
                    cmp.PictureCaptured += new ICMPEvents_PictureCapturedEventHandler(cmp_PictureCaptured);
                    //! [eventsubscription]
                }
                else
                {
                    string msg = string.Format("OpenSession failed rc={0:X}", rc);
                    UpdateStatus(msg);
                    Helpers.Trace(msg);
                }
            }
            catch (System.Exception ex)
            {
                UpdateStatus(ex.Message);
                Helpers.Trace(ex.Message);
                Helpers.Trace(ex.StackTrace);
            }
        }

        //! [eventhandler]
        // <summary>
        // PictureCaptured event handler.
        // </summary>
        // <param name="rc">Capture result.</param>
        // <param name="uniqueId">Capture identifier.</param>
        // <param name="pictureMetadata">Capture metadata filename.</param>
        // <param name="filename">Capture filename.</param>
        // <param name="thumbnail">Thumbnail filename.</param>
        // <param name="PictureSize">Capture size.</param>
        // <param name="Quality">Capture quality.</param>
        // <param name="CameraSelection">Camera selected.</param>
        // <param name="Encoding">Capture encoding.</param>
        // <param name="DesiredWidth">Capture width.</param>
        // <param name="DesiredHeight">Capture height.</param>
        // <param name="DurationLimit">Capture duration limit.</param>
        // <param name="ThumbnailType">Thumbnail type.</param>
        // <param name="ThumbnailWidth"Capture width.</param>
        // <param name="ThumbnailHeight">Capture height.</param>
        void cmp_PictureCaptured(CMPRESULT rc, CMP_UNIQUE_LONG_ID uniqueId, string pictureMetadata, string filename, string thumbnail, 
            CMPRESULT PictureSize, CMP_CAPTURE_QUALITY Quality, CMP_CAPTURE_CAMERA CameraSelection, CMP_IMAGE_FORMAT Encoding, CMPRESULT DesiredWidth, 
            CMPRESULT DesiredHeight, CMP_THUMBNAIL_TYPE ThumbnailType, short ThumbnailWidth, short ThumbnailHeight)
        {
            // only process capture if it is one of ours
            if (uniqueId == captureId)
            {
                if (CMP_SUCCESS(rc))
                {
                    lock (stateLock)
                    {
                        processingCapture = true;
                    }

                    UpdateStatus(string.Format("Capture received: {0}", filename));

                    //Save the capture to the local temporary directory (keeping the same file name and extension).
                    string newLocation = System.IO.Path.GetTempPath() + System.IO.Path.GetFileName(filename);

                    UpdateStatus(string.Format("Saving capture to: {0}", newLocation));

                    File.Copy(filename, newLocation, true);

                    // Display the capture. Note that this is invoked in the UI thread.
                    ShowPicture(newLocation);
                    UpdateStatus(string.Format("Capture saved: {0}", newLocation));

                    lock (stateLock)
                    {
                        processingCapture = false;
                    }
                }
            }
        }
        //! [eventhandler]

        // <summary>
        // Tear down CMP connection when closed.
        // </summary>
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (null != cmp)
            {
                // Close CMP session.
                cmp.CloseSession();
                cmp = null;
            }
        }

        // <summary>
        // Session state change handler.
        // </summary>
        // <remarks>Update the ICA session state upon connect/disconnect.</remarks>
        // <param name="SessState">Session state</param>
        void cmp_SessionStateChanged(CMP_SESSION_STATE SessState)
        {
            switch (SessState)
            {
                case CMP_SESSION_STATE.CMP_SESSION_STATE_CONNECTED:
                    icaSessionConnected = true;
                    break;
                case CMP_SESSION_STATE.CMP_SESSION_STATE_DISCONNECTED:
                    icaSessionConnected = false;
                    break;
                default:
                    break;
            }
        }

        // <summary>
        // Display the specified status text.
        // </summary>
        // <param name="statusText">Status text.</param>
        private void UpdateStatus(string statusText)
        {
            UiDispatch(() => status.Text = statusText);
        }

        // <summary>
        // Display the specified image.
        // </summary>
        // <param name="pathToPicture">Path to the picture.</param>
        private void ShowPicture(string pathToPicture)
        {
            UiDispatch(() => pictureBox1.Load(pathToPicture));
        }

        private delegate void InvokeDelegate(string pathToPicture);

        // <summary>
        // Label click handler.
        // </summary>
        // <remarks>Initiate picture capture on the device when the label is clicked.</remarks>
        // <param name="sender"></param>
        // <param name="e"></param>
        private void label1_Click(object sender, EventArgs e)
        {
            if ((null != cmp) && icaSessionConnected && !processingCapture)
            {
                try
                {
                    UpdateStatus("Sending request to capture picture");
                    Helpers.Trace("Sending request to capture picture");

                    //! [capturepicture]
                    // Request a picture capture.
                    int rc = cmp.CapturePicture(ref options, out captureId);
                    //! [capturepicture]

                    if (CMP_SUCCESS(rc))
                    {
                        UpdateStatus("Capture picture request sent successfully");
                        Helpers.Trace("Capture picture request sent successfully");
                    }
                    else
                    {
                        ReportError(rc);
                    }
                }
                catch (Exception ex)
                {
                    UpdateStatus(ex.Message);
                    Helpers.Trace(ex.Message);
                    Helpers.Trace(ex.StackTrace);
                }
            }
        }

        // <summary>
        // Report an error with relation to PictureCapture
        // </summary>
        private void ReportError(CMPRESULT rc)
        {
            CMP_ERROR_ID err = (CMP_ERROR_ID)rc;

            string msg = string.Format("Error {0:X} with CapturePicture\n", rc);

            switch (err)
            {
                case CMP_ERROR_ID.CMP_ERROR_CLIENT_DRIVE_UNAVAILABLE:
                    msg += "Client Drive unavailable. Check session options on Receiver.";
                    break;
                case CMP_ERROR_ID.CMP_ERROR_CAPABILITY_NOT_SUPPORTED:
                    msg += "This device does not support picture capture.";
                    break;
                default:
                    break;
            }

            UpdateStatus(msg);
            Helpers.Trace(msg);
        }
    }
}
