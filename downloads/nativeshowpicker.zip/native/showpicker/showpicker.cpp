// C++ Show picker example using Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to show a picker control
//
// Copyright (c) 2012 Citrix Systems
//

#include <stdio.h>
#include <windows.h>

#include <cmp.h>


// unique number should not be a constant but it is here for an example
#define UNIQUE_PICKER_ID      0x20122112

// PICKER_COLORS uses a short cut to populating a multiple string.  The \0 can be dangerous when it comes
// to displaying numbers since \0 is really \000 and can be other numbers that start with \0 like \021.  So,
// if you use this trick, be sure to specify the full \000 if you decide to include numbers.
// Also note that this is really a UTF-8 string so it is possible to specify any UNICODE character.
// For Windows programmers, it could be easier just to use the CMPShowPickerUTF16 and use wide character strings.
#define PICKER_COLORS       "Red\0Blue\0Green\0White\0"
#define PICKER_COLOR_COUNT  4
#define PICKER_TITLE        "Pick a color"
#define PICKER_DEFAULT      0                               // defaults to the first thing (Red)

// Local functions
UTF8_STRING GetListItem(UTF8_STRING list, INT16 index);
void        ReportStatus(LPCSTR text, CMPRESULT rc);
void        WaitForCMPEvents(int seconds);
CMPRESULT   RegisterForEvent(HANDLE hCMP);
CMPRESULT   ShowPicker(HANDLE hCMP, CMP_UNIQUE_ID controlId, CMP_DISPLAY_RECT* rect, UINT32 selectedIndex,
                       UINT32 listItemsCount, UTF8_STRING listItems, UTF8_STRING title);

//
// main entry point for simple phone call program
//
int __cdecl main(int argc, char **argv)
{
    CMPRESULT rc;
    HANDLE hCMP = NULL;

    // initialize for STA (Single Thread Apartment) in COM
    rc = CMPInitialize(FALSE);

    ReportStatus("CMPInitialize", rc);

    // Open a handle to the mobile device
    rc = CMPOpen(&hCMP);

    ReportStatus("CMPOpen", rc);

    if(CMP_SUCCESS(rc))
    {
        // open the link between the two sides
        rc = CMPOpenSession(hCMP);

        ReportStatus("CMPOpenSession", rc);

        if(CMP_SUCCESS(rc))
        {
            rc = RegisterForEvent(hCMP);

            if(CMP_SUCCESS(rc))
            {
                CMP_DISPLAY_RECT rect;

                // Not using the rectangle here but could be used to indicate what part of the screen to show with the picker control.
                // Typically this would be a list control.
                memset(&rect, 0, sizeof(rect));

                rc = ShowPicker(hCMP, UNIQUE_PICKER_ID, &rect, PICKER_DEFAULT, PICKER_COLOR_COUNT, PICKER_COLORS, PICKER_TITLE);

                if(CMP_SUCCESS(rc))
                {
                    // let events come in over the next 30 seconds
                    // if this was a Windows program and we had a message loop, we would not need to do this
                    WaitForCMPEvents(30);
                }
            }

            // close our connection
            CMPCloseSession(hCMP);
        }

        // release our handle
        CMPClose(hCMP);
    }

    // uninitialize COM
    CMPUninitialize();

}

// return a pointer to the item we are interested
UTF8_STRING GetListItem(UTF8_STRING list, INT16 index)
{
    UTF8_STRING item = NULL;

    if(list != NULL)
    {
        UTF8_STRING curritem = list;
        INT16 i = 0;

        while(curritem != NULL && *curritem != '\0')
        {
            if(index == i)
            {
                item = curritem;
                break;
            }

            curritem += strlen(curritem) + 1;
            i++;
        }
    }

    return(item);
}

//! [eventhandler]
// <summary>
// PickerControlStateChanged event handler.
// </summary>
// <param name="hCMP">CMP handler.</param>
// <param name="pickerId">Picker identifier.</param>
// <param name="pickerStateFlags">Picker state flags.</param>
// <param name="rc">Return code.</param>
// <param name="selectedIndex">Selected index.</param>
void CMPAPI PickerControlStateChanged(
	HANDLE hCMP, 
	CMP_UNIQUE_ID 
	pickerId, 
	INT16 pickerStateFlags,
	CMPRESULT rc, INT16 selectedIndex)
{
    printf("PickerControlStateChanged hCMP(%p) PickerId(%X) "
		"Flags(0x%X) rc(0x%X) Index(%u)\n", 
		hCMP, pickerId, pickerStateFlags, rc, selectedIndex);
    
    // Only proceed if the picker is one of ours.
    if(pickerId == UNIQUE_PICKER_ID)
    {
        if(pickerStateFlags & CMP_PICKER_CONTROL_STATE_VISIBLE)
        {
            printf("Picker is visible\n");
        }

        if(pickerStateFlags & CMP_PICKER_CONTROL_STATE_SELECTED)
        {
            printf("Picker item has been selected.  Index(%u) Item(%s) \n", 
			    selectedIndex, GetListItem(PICKER_COLORS, selectedIndex));
        }

        if(pickerStateFlags & CMP_PICKER_CONTROL_STATE_ABORTED)
        {
            printf("Picker control was aborted\n");
        }
    }
}
//! [eventhandler]

/// <summary>
/// Check CMP return code for success and report errors if they happen.
/// </summary>
void ReportStatus(LPCSTR text, CMPRESULT rc)
{
    // only print if something went wrong
    if(CMP_FAILURE(rc))
    {
        printf("%s CMPResult(%08X)\n", text, rc);
    }

    return;
}

/// <summary>
/// Register to Picker control state changed event
/// </summary>
CMPRESULT RegisterForEvent(HANDLE hCMP)
{
    CMPRESULT rc;

    //! [eventsubscription]                    
    // Subscribed PickerControlStateChanged event.
    rc = CMPRegisterForEvent(hCMP, CMP_EVENT_PICKER_CONTROL_STATE_CHANGED, (CMP_EVENT_CALLBACK)PickerControlStateChanged); 
    //! [eventsubscription]

    ReportStatus("CMPRegisterForEvent CMP_EVENT_PICKER_CONTROL_STATE_CHANGED", rc);

    return(rc);
}

// <summary>
// A "wait" spin loop to give the events a chance to happen
// </summary>
void WaitForCMPEvents(int seconds)
{
    for(int i=0; i<seconds; i++)
    {
        Sleep(1000);
    }
}


// <summary>
// Show the picker control
// </summary>
CMPRESULT ShowPicker(HANDLE hCMP, CMP_UNIQUE_ID controlId, CMP_DISPLAY_RECT* rect, UINT32 selectedIndex,
                     UINT32 listItemsCount, UTF8_STRING listItems, UTF8_STRING title)
{
    CMPRESULT rc;

    //! [showpicker]
    // Show the picker with the list and the title.
    // The event returns what the user eventually picks
    rc = CMPShowPicker(hCMP, controlId, rect, selectedIndex, listItemsCount, listItems, title);
    //! [showpicker]

    ReportStatus("CMPShowPicker", rc);

    return(rc);
}
