﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CitrixMobility;

namespace displaysettings
{
    public partial class FormViewport : ScaleForm
    {
        public FormViewport(CMPApp cmpapp, ScaleForm parent) : base(cmpapp, parent)
        {
            InitializeComponent();

            // capture data about the current layout
            CaptureInitialLayout();

            ScaleLayout();

            RefreshData();

            ScaleMode = parent.ScaleMode;
        }


        // <summary>
        // Update the viewport origin data on the form
        // </summary>
        // <param name="origin">Viewport origin</param>
        void ForumUpdateViewportOrigin(ref CMP_DISPLAY_POINT origin)
        {
            string originText = String.Format("({0},{1})", origin.Left, origin.Top);

            UiDispatch(() => this.viewportOrigin.Text = originText);
        }

        void FormErrorViewportOrigin()
        {
            UiDispatch(() => this.viewportOrigin.Text = errorStr);
        }

        // <summary>
        // Update the viewport data on the form
        // </summary>
        void FormUpdateViewport(short viewportFlags, short zoomFactor, ref CMP_DISPLAY_RECT clientViewport, ref CMP_DISPLAY_RECT serverViewport)
        {
            string clientViewportText = String.Format("({0},{1},{2},{3})", clientViewport.Left, clientViewport.Top, clientViewport.Right, clientViewport.Bottom);
            string serverViewportText = String.Format("({0},{1},{2},{3})", serverViewport.Left, serverViewport.Top, serverViewport.Right, serverViewport.Bottom);

            UiDispatch(() =>
            {
                this.viewportFlags.Text = viewportFlags.ToString("X");
                this.zoomFactor.Text = zoomFactor.ToString();
                this.clientViewport.Text = clientViewportText;
                this.serverViewport.Text = serverViewportText;
            });
        }

        // <summary>
        // If the GetViewport had an error, report values as error
        // </summary>
        void FormErrorViewport()
        {
            UiDispatch(() =>
            {
                this.viewportFlags.Text = errorStr;
                this.zoomFactor.Text = errorStr;
                this.clientViewport.Text = errorStr;
                this.serverViewport.Text = errorStr;
            });
        }


        // <summary>
        // Refresh the CMP related data on the form
        // </summary>
        void RefreshData()
        {
            Int32 rc = (Int32)CMP_ERROR_ID.CMP_NO_ERROR;

            {
                short viewportFlags = 0;
                short zoomFactor = 0;
                CMP_DISPLAY_POINT origin = new CMP_DISPLAY_POINT();
                CMP_DISPLAY_RECT clientViewport = new CMP_DISPLAY_RECT();
                CMP_DISPLAY_RECT serverViewport = new CMP_DISPLAY_RECT();

                rc = cmp.GetViewportOrigin(ref origin);

                if (CMPApp.CMP_SUCCESS(rc))
                {
                    ForumUpdateViewportOrigin(ref origin);
                }
                else
                {
                    FormErrorViewportOrigin();
                    ReportStatus("GetViewportOrigin", rc);
                }

                rc = cmp.GetViewport(ref viewportFlags, ref zoomFactor, ref clientViewport, ref serverViewport);

                if (CMPApp.CMP_SUCCESS(rc))
                {
                    FormUpdateViewport(viewportFlags, zoomFactor, ref clientViewport, ref serverViewport);
                }
                else
                {
                    FormErrorViewport();
                    ReportStatus("GetViewport", rc);
                }
            }
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            parentForm.Show();
            Hide();
        }

        private void Form2_Shown(object sender, EventArgs e)
        {
            Maximize();
        }


    }
}
