﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CitrixMobility;

namespace displaysettings
{
    public partial class FormScrollMode : ScaleForm
    {
        public FormScrollMode(CMPApp cmpapp, ScaleForm parent) : base(cmpapp, parent)
        {
            InitializeComponent();

            // capture data about the current layout
            CaptureInitialLayout();

            ScaleLayout();

            RefreshData();

            ScaleMode = parent.ScaleMode;

        }

        // <summary>
        // Update the scroll mode data on the form
        // </summary>
        // <param name="scrollMode">Current scroll mode</param>
        void FormUpdateScrollMode(CMP_SCROLL_MODE scrollMode)
        {
            UiDispatch(() => this.scrollMode.Text = scrollMode.ToString());
        }

        void FormErrorScrollMode()
        {
            UiDispatch(() => this.scrollMode.Text = errorStr);
        }

        // <summary>
        // Refresh the CMP related data on the form
        // </summary>
        void RefreshData()
        {
            Int32 rc = (Int32)CMP_ERROR_ID.CMP_NO_ERROR;

            {
                CMP_SCROLL_MODE scrollMode = CMP_SCROLL_MODE.CMP_SCROLLMODE_PAN;

                rc = cmp.GetScrollMode(ref scrollMode);

                if (CMPApp.CMP_SUCCESS(rc))
                {
                    FormUpdateScrollMode(scrollMode);
                }
                else
                {
                    FormErrorScrollMode();
                    ReportStatus("GetScrollMode", rc);
                }
            }
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            parentForm.Show();
            Hide();
        }

        private void FormScrollMode_Shown(object sender, EventArgs e)
        {
            Maximize();
        }

    }

}
