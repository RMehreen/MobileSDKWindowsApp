﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using CitrixMobility;

namespace displaysettings
{

    public struct ControlLocationSize
    {
        public Point location;
        public Size size;
        public Font font;
        public Control control;
    }

    public enum ScaleMode
    {
        Scale_OneX,
        Scale_TwoX,
        Scale_DPI,
        Scale_Fit
    }

    public struct ScaleFactor
    {
        public float scaleX;
        public float scaleY;

        public ScaleFactor(float scX, float scY)
        {
            scaleX = scX;
            scaleY = scY;
        }

        public ScaleFactor(float scXY)
        {
            scaleX = scaleY = scXY;
        }
    }

    public class ScaleForm : Form
    {
        private ScaleFactor scaleFactor = new ScaleFactor(1.0F, 1.0F);
        private ScaleFactor dpiscaleFactor = new ScaleFactor(1.0F, 1.0F);

        private Dictionary<Control, ControlLocationSize> InitialPositions;

        private Graphics graphics;

        private ScaleMode scaleMode = ScaleMode.Scale_OneX;

        public static string errorStr = "Error";

        // <summary>
        // Instance of CMPApp.
        // </summary>
        protected CMPApp cmp;

        protected ScaleForm parentForm;

        public ScaleForm()
        {
        }

        public ScaleForm(CMPApp cmpapp, ScaleForm parent)
        {
            cmp = cmpapp;
            parentForm = parent;
        }

        // <summary>
        // Dispatch action to UI thread if necessary.
        // </summary>
        // <param name="action">The action.</param>
        public void UiDispatch(Action action)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(action);
            }
            else
            {
                action();
            }
        }

        // <summary>
        // Report CMP status.
        // </summary>
        // <param name="text">Status text.</param>
        // <param name="rc">CMP return code.</param>
        public void ReportStatus(string text, Int32 rc)
        {
            // Only report status if something went wrong.
            if (!CMPApp.CMP_SUCCESS(rc))
            {
                string msg = string.Format("{0}, CMPResult: 0x{1:X}", text, rc);

                // Write to trace output.
                Helpers.Trace(msg);

                // Update status text.
                MessageBox.Show(msg);
            }
        }

        // <summary>
        // Save away all the initial locations and sizes of the controls
        // </summary>
        public void CaptureInitialLayout()
        {
            ControlLocationSize locSize = new ControlLocationSize();

            graphics = CreateGraphics();

            InitialPositions = new Dictionary<Control, ControlLocationSize>();

            foreach (Control control in this.Controls)
            {
                // we preserve the location, size, and font since they could change in the future based
                // on scaling changes
                locSize.location = control.Location;
                locSize.size = control.Size;
                locSize.font = control.Font;

                locSize.control = control;

                InitialPositions[control] = locSize;
            }
        }

        public ScaleMode ScaleMode
        {
            get
            {
                return (scaleMode);
            }
            set
            {
                Scale(value);
            }
        }

        public void SetScaleFactor(Int32 XPpi, Int32 YPpi)
        {
            ScaleFactor scFactor = new ScaleFactor(XPpi / graphics.DpiX, YPpi / graphics.DpiY);

            scaleFactor = dpiscaleFactor = scFactor;
        }

        Rectangle CalculateControlRect()
        {
            Rectangle ControlSpace = new Rectangle();

            foreach (ControlLocationSize locSize in InitialPositions.Values)
            {
                if (!IsLabelControl(locSize.control))
                {
                    // build a rectangle that contains all rectangles
                    ControlSpace = Rectangle.Union(ControlSpace, new Rectangle(locSize.location, locSize.size));
                }
                else
                {
                    Size textSize;
                    Rectangle textRect;

                    // calculate how much the current text in the label would take for size
                    textSize = CalculateTextSize(locSize, locSize.control.Text);
                    textRect = new Rectangle(locSize.location, textSize);

                    ControlSpace = Rectangle.Union(ControlSpace, textRect);
                }

            }

            return (ControlSpace);
        }

        bool IsLabelControl(Control control)
        {
            bool labelControl = false;
            Type objectType = control.GetType();

            if (objectType == typeof(Label))
            {
                labelControl = true;
            }

            return (labelControl);
        }

        // <summary>
        // Calculate how big the text string will be with the specified font
        // </summary>
        private Size CalculateTextSize(ControlLocationSize controlInfo, string text)
        {
            Size textSize = new Size();
            SizeF size = graphics.MeasureString(text, controlInfo.font);

            textSize.Width = (Int32)Math.Ceiling(size.Width);
            textSize.Height = (Int32)Math.Ceiling(size.Height);

            return (textSize);
        }

        // <summary>
        // Adjust the size and location of controls based on the multiplier
        // </summary>
        private void AdjustControls(ScaleFactor scaleFactor)
        {
            SuspendLayout();

            foreach (Control control in this.Controls)
            {
                Point location = InitialPositions[control].location;
                Size size = InitialPositions[control].size;

                Point newLocation = GetAdjustedLocation(location, scaleFactor);
                Size newSize = GetAdjustedSize(size, scaleFactor);

                // use the new location and size
                control.Location = newLocation;
                control.Size = newSize;

                if (control.GetType() == typeof(Label))
                {
                    // resize the font size
                    control.Font = new Font(control.Font.FontFamily, GetAdjustedFontSize(InitialPositions[control].font.Size, scaleFactor));
                }
                else if (control.GetType() == typeof(Button))
                {
                    // resize the font size
                    control.Font = new Font(control.Font.FontFamily, GetAdjustedFontSize(InitialPositions[control].font.Size, scaleFactor));
                }

            }

            ResumeLayout(false);
            PerformLayout();

        }

        // <summary>
        // Calculate the new location based on multiplier
        // </summary>
        private Point GetAdjustedLocation(Point location, ScaleFactor scFactor)
        {
            Point newLocation = new Point();

            newLocation.X = (int)Math.Round(location.X * scFactor.scaleX);
            newLocation.Y = (int)Math.Round(location.Y * scFactor.scaleY);

            return (newLocation);
        }

        // <summary>
        // Calculate the new size based on multiplier
        // </summary>
        private Size GetAdjustedSize(Size size, ScaleFactor scFactor)
        {
            Size newSize = new Size();

            newSize.Width = (int)Math.Ceiling(size.Width * scFactor.scaleX);
            newSize.Height = (int)Math.Ceiling(size.Height * scFactor.scaleY);

            return (newSize);
        }

        // <summary>
        // Calculate the new font size based on multiplier
        // </summary>
        private float GetAdjustedFontSize(float fontSize, ScaleFactor scFactor)
        {
            float newSize;

            // combine x and y multipliers to figure based on normalized value
            float mult = (float)Math.Sqrt(scFactor.scaleX * scFactor.scaleY);

            newSize = fontSize * mult;

            return (newSize);
        }

        // <summary>
        // Calculate the new cursor location based on multiplier
        // </summary>
        private void AdjustCursorLocation(ScaleFactor scFactor)
        {
            Point newPosition = new Point();
            Point currPosition;

            currPosition = Cursor.Position;

            // calculate the new position based on current multipliers
            newPosition.X = (int)Math.Round(currPosition.X * (scFactor.scaleX / scaleFactor.scaleX));
            newPosition.Y = (int)Math.Round(currPosition.Y * (scFactor.scaleY / scaleFactor.scaleY));

            Cursor.Position = newPosition;

            return;
        }

        // <summary>
        // Scale all the controls based on multipliers
        // </summary>
        public void Scale(ScaleMode scale)
        {
            ScaleFactor scFactor;

            scFactor = GetScaleFactor(scale);

            AdjustControls(scFactor);

            AdjustCursorLocation(scFactor);

            scaleFactor = scFactor;
            scaleMode = scale;
        }

        public void Scale()
        {
            Scale(ScaleMode);
        }

        // <summary>
        // Determine the scale factor for the given scale mode
        // </summary>
        public ScaleFactor GetScaleFactor(ScaleMode scale)
        {
            ScaleFactor scFactor;

            switch (scale)
            {
                case ScaleMode.Scale_OneX:
                    scFactor = new ScaleFactor(1.0F);
                    break;

                case ScaleMode.Scale_TwoX:
                    scFactor = new ScaleFactor(2.0F);
                    break;

                case ScaleMode.Scale_DPI:
                    scFactor = dpiscaleFactor;
                    break;

                case ScaleMode.Scale_Fit:
                    scFactor = GetFitScaleFactor();
                    break;

                default:
                    scFactor = new ScaleFactor(1.0F);
                    break;
            }

            return (scFactor);
        }

        // <summary>
        // Fit the controls into the space that we have
        // </summary>
        private ScaleFactor GetFitScaleFactor()
        {
            Point workArea = new Point();
            float xMult, yMult, mult;
            Rectangle ControlRect;

            //calculate the multiplier we would need to fit
            ControlRect = CalculateControlRect();

            // get the work area size
            workArea = GetWorkArea();

            // next, get the bottom right corner of the control rectangle
            Point controlBR = new Point(ControlRect.Right, ControlRect.Bottom);

            xMult = (float)workArea.X / (float)controlBR.X;
            yMult = (float)workArea.Y / (float)controlBR.Y;

            // the values have to be the same to scale properly
            // we cannot scale bigger in one direction than another
            if (xMult > yMult)
                mult = yMult;
            else
                mult = xMult;

            return (new ScaleFactor(mult));
        }

        // <summary>
        // Get the primary display work area
        // </summary>
        // <param name="xy">Width (X) and Height (Y) of display work area</param>
        public Point GetWorkArea()
        {
            Rectangle displayRect;
            Point xy = new Point();

            displayRect = Screen.PrimaryScreen.WorkingArea;

            xy.X = displayRect.Width;
            xy.Y = displayRect.Height;

            return (xy);
        }

        // <summary>
        // Get the primary display work area
        // </summary>
        // <param name="xy">Width (X) and Height (Y) of display work area</param>
        public string GetWorkAreaString()
        {
            Point xy;
            string screenSize;

            xy = GetWorkArea();

            screenSize = xy.X.ToString() + " x " + xy.Y.ToString();

            return (screenSize);
        }

        public void Maximize()
        {
            if (WindowState == FormWindowState.Maximized)
            {
                WindowState = FormWindowState.Normal;
            }

            WindowState = FormWindowState.Maximized;
        }


        public void ScaleLayout()
        {
            // adjust our controls on the form based on our DPI settings
            if ((cmp != null) && cmp.IsInitialized())
            {
                CMP_DISPLAY_SETTINGS dispSettings = new CMP_DISPLAY_SETTINGS();

                Int32 rc = cmp.GetDisplaySettings(ref dispSettings);

                if (CMPApp.CMP_SUCCESS(rc))
                {
                    SetScaleFactor(dispSettings.HorizontalPixelsPerInch, dispSettings.VerticalPixelsPerInch);

                    Scale(ScaleMode.Scale_DPI);
                }
                else
                {
                    Scale(ScaleMode.Scale_OneX);
                }
            }
            else
            {
                // initialize the multipliers to 1 if CMP not available
                Scale(ScaleMode.Scale_OneX);
            }

        }

    }
}
