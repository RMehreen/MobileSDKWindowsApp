﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CitrixMobility;
using System.Runtime.InteropServices;

namespace displaysettings
{
    public partial class FormDisplaySettings : ScaleForm
    {
        private int displaySettingsEvents = 0;

        public FormDisplaySettings(CMPApp cmpapp, ScaleForm parent) : base(cmpapp, parent)
        {
            RegisterForDisplaySettingsEvent();

            InitializeComponent();

            // capture data about the current layout
            CaptureInitialLayout();

            ScaleLayout();

            RefreshData();

            ScaleMode = parent.ScaleMode;
        }

        //! [eventhandler]
        // <summary>
        // Display Settings event handler.
        // </summary>
        public void DisplaySettingsChanged(CMP_DISPLAY_SETTINGS settings)
        {
            // keep track of how many display settings changed events we processed
            displaySettingsEvents++;

            RefreshData();

            UiDispatch(() =>
            {
                this.metricsFlags.Text = settings.MetricsFlags.ToString("X");
                this.pixel.Text = settings.PixelWidth + "x" + settings.PixelHeight;
                this.colorDepth.Text = settings.ColorDepth.ToString();
                this.ppi.Text = settings.HorizontalPixelsPerInch + " x " + settings.VerticalPixelsPerInch;
                this.orientation.Text = settings.DeviceOrientation.ToString();
                this.physical.Text = settings.WidthMilliInches + " x " + settings.HeightMilliInches;
                this.dpi.Text = settings.PixelsPerInch.ToString();
                this.displayEventsCount.Text = displaySettingsEvents.ToString();
            });
        }

        //! [eventhandler]

        // <summary>
        // Register for the display settings changed event
        // </summary>
        void RegisterForDisplaySettingsEvent()
        {
            //! [eventsubscription]
            // Register for display settings changed events.
            cmp.DisplaySettingsChanged += new CMPApp.DisplaySettingsChangedEventHandler(DisplaySettingsChanged);
            //! [eventsubscription]
        }

        // <summary>
        // Use the display settings to update the form
        // </summary>
        // <param name="settings">Display settings</param>
        void FormUpdateDisplaySettings(ref CMP_DISPLAY_SETTINGS settings)
        {
            CMP_ORIENTATION_POSITION DeviceOrientation = (CMP_ORIENTATION_POSITION)settings.DeviceOrientation;
            string metricFlagsText = settings.MetricsFlags.ToString("X");
            string pixeltext = settings.PixelWidth.ToString() + " x " + settings.PixelHeight.ToString();
            string colorDepthText = settings.ColorDepth.ToString();
            string ppiText = settings.HorizontalPixelsPerInch + " x " + settings.VerticalPixelsPerInch;
            string physicalText = settings.WidthMilliInches + " x " + settings.HeightMilliInches;
            string dpiText = settings.PixelsPerInch.ToString();

            UiDispatch(() =>
            {
                metricsFlags.Text = metricFlagsText;
                pixel.Text = pixeltext;
                colorDepth.Text = colorDepthText;
                ppi.Text = ppiText;
                orientation.Text = DeviceOrientation.ToString();
                physical.Text = physicalText;
                dpi.Text = dpiText;
            });
        }

        void FormErrorDisplaySettings()
        {
            UiDispatch(() =>
            {
                metricsFlags.Text = errorStr;
                pixel.Text = errorStr;
                colorDepth.Text = errorStr;
                ppi.Text = errorStr;
                orientation.Text = errorStr;
                physical.Text = errorStr;
                dpi.Text = errorStr;
            });
        }


        private void BackButton_Click(object sender, EventArgs e)
        {
            parentForm.Show();
            Hide();
        }

        // <summary>
        // Refresh the CMP related data on the form
        // </summary>
        void RefreshData()
        {
            Int32 rc = (Int32)CMP_ERROR_ID.CMP_NO_ERROR;

            {
                CMP_DISPLAY_SETTINGS dispSettings = new CMP_DISPLAY_SETTINGS();

                rc = cmp.GetDisplaySettings(ref dispSettings);

                if (CMPApp.CMP_SUCCESS(rc))
                {
                    FormUpdateDisplaySettings(ref dispSettings);
                }
                else
                {
                    FormErrorDisplaySettings();
                    ReportStatus("GetDisplaySettings", rc);
                }
            }

        }

        private void FormDisplaySettings_Shown(object sender, EventArgs e)
        {
            Maximize();
        }


    }
}
