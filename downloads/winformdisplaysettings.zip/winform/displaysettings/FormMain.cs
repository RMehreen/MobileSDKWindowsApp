﻿//
// C# Display Settings example using COM Interop with Citrix Mobility SDK
//
// Uses Citrix Mobility SDK to reveal display settings.
// Retrieves information on the device's display settings after a change 
// in the settings is detected (through a change orientation).
//
// Copyright (c) 2012 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using CitrixMobility;

namespace displaysettings
{


    public partial class FormMain : ScaleForm
    {


        // <summary>
        // Initialize Form.
        // </summary>
        public FormMain(CMPApp cmpapp) : base(cmpapp, null)
        {
            cmp.ReportStatus += new CMPApp.ReportStatusEventHandler(ReportStatus);

            InitializeComponent();

            // capture data about the current layout
            CaptureInitialLayout();

            ScaleLayout();

            // register for resize events
            this.Resize += new System.EventHandler(this.Form1_Resize);

            // register for system display settings changed events
            SystemEvents.DisplaySettingsChanged += new EventHandler(SystemEvents_DisplaySettingsChanged);
        }

        // <summary>
        // Resize event handler
        // </summary>
        // <param name="sender">object of sender</param>
        // <param name="e">event arguments</param>
        private void Form1_Resize(object sender, EventArgs e)
        {
            Control control = (Control)sender;

            string formsize = control.Width.ToString() + " x " + control.Height.ToString();

            // UiDispatch(() => formSize.Text = formsize);
        }

        // <summary>
        // System display settings changed event handler
        // </summary>
        // <param name="sender">object of sender</param>
        // <param name="e">event arguments</param>
        void SystemEvents_DisplaySettingsChanged(object sender, EventArgs e)
        {
            // get the working area (both values and string representation)
            string screenSize = GetWorkAreaString();

            UiDispatch(() =>
                {
                    //this.screenSize.Text = screenSize;

                    Maximize();
                }
            );
        }


        private void Quit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }



        // <summary>
        // 1X button pressed
        // </summary>
        private void OneX_Click(object sender, EventArgs e)
        {
            Scale(ScaleMode.Scale_OneX);
        }

        // <summary>
        // 2X button pressed
        // </summary>
        private void TwoX_Click(object sender, EventArgs e)
        {
            Scale(ScaleMode.Scale_TwoX);
        }

        // <summary>
        // DPI button pressed
        // </summary>
        private void DPIFactor_Click(object sender, EventArgs e)
        {
            Scale(ScaleMode.Scale_DPI);
        }


        private void FitButton_Click(object sender, EventArgs e)
        {
            Scale(ScaleMode.Scale_Fit);
        }

        private void MaxButton_Click(object sender, EventArgs e)
        {
            Maximize();
        }

        private void ViewportButton_Click(object sender, EventArgs e)
        {
            ScaleForm viewportForm = new FormViewport(cmp, this);

            viewportForm.Show();
            this.Hide();
        }

        private void OrientationButton_Click(object sender, EventArgs e)
        {
            ScaleForm orientationForm = new FormOrientation(cmp, this);

            orientationForm.Show();
            this.Hide();
        }

        private void SettingsButton_Click(object sender, EventArgs e)
        {
            ScaleForm settingsForm = new FormDisplaySettings(cmp, this);

            settingsForm.Show();
            this.Hide();
        }

        private void ScrollModeButton_Click(object sender, EventArgs e)
        {
            ScaleForm scrollModeForm = new FormScrollMode(cmp, this);

            scrollModeForm.Show();
            this.Hide();
        }

        private void FormMain_Shown(object sender, EventArgs e)
        {
            Maximize();
        }


    }
}
