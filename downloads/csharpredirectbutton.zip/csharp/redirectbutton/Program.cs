﻿// C# Redirect button example using Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to redirect button presses.
//
// Copyright (c) 2012 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.Linq;
using CitrixMobility;
using System.Threading;

using CMPRESULT = System.Int32;

namespace redirectbutton
{
    class Program
    {
        static CitrixMobile cmp;

        [STAThread]
        static void Main()
        {
            // Initialise result to "No Error"
            CMPRESULT rc = (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Console.WriteLine("Creating CitrixMobile object");

                // Creates the CitrixMobile Object which contains all the CMP interfaces. e.g. IButton, ICamera
                cmp = new CitrixMobile();

                Console.WriteLine("Calling OpenSession");

                // Opens a connection to the remote mobile device
                // It is good practice to close the operation when no longer needed 
                rc = cmp.OpenSession();
                
                if(CMP_SUCCESS(rc))
                {
                    Console.WriteLine("Hooking button pressed event");

                    // register for button events
                    RegisterForEvents();

                    Console.WriteLine("Checking if Back button is supported");
                    
                    bool backButtonSupported;

                    rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_BUTTON_SET_TARGET, (short)CMP_BUTTON_ID.CMP_BUTTON_BACK, out backButtonSupported);

                    Console.WriteLine("Back button support rc {0:X} support {1}", rc, backButtonSupported);

                    if (backButtonSupported)
                    {
                        CMP_BUTTON_TARGET target = CMP_BUTTON_TARGET.CMP_BUTTON_TARGET_CLIENT;

                        rc = cmp.GetButtonTarget(CMP_BUTTON_ID.CMP_BUTTON_BACK, out target);

                        Console.WriteLine("Current Button Target rc {0:X} value {1:X}", rc, target);

                        rc = SetButtonTarget(CMP_BUTTON_TARGET.CMP_BUTTON_TARGET_HOST);

                        if (CMP_SUCCESS(rc))
                        {
                            // Loop for thirty seconds to allow for events to happen
                            for (int i = 0; i < 30; i++)
                            {
                                Thread.Sleep(1000);
                            }
                        }

                        // reset it back to the client side when done
                        rc = SetButtonTarget(CMP_BUTTON_TARGET.CMP_BUTTON_TARGET_CLIENT);
                    }
                    else
                    {
                        Console.WriteLine("Back button is not supported.");
                        Console.WriteLine("Press any key to continue...");
                        Console.ReadKey();
                    }
                }
                else
                {
                    Console.WriteLine("OpenSession failed rc={0:X}", rc);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }

        //! [buttonpressed_handler]
        // <summary>
        // ButtonPressed event handler.
        // </summary>
        // <param name="Button">Button ID.</param>
        static void cmp_ButtonPressed(CMP_BUTTON_ID Button)
        {
            Console.WriteLine("ButtonPressed: {0:X}", Button);
        }
        //! [buttonpressed_handler]

        //! [targetchanged_handler]
        // <summary>
        // ButtonTargetChanged event handler.
        // </summary>
        // <param name="rc">Return code.</param>
        // <param name="Button">Button ID.</param>
        // <param name="ButtonTarget">Button target.</param>
        static void cmp_ButtonTargetChanged(CMPRESULT rc, CMP_BUTTON_ID Button, CMP_BUTTON_TARGET ButtonTarget)
        {
            Console.WriteLine("ButtonTargetChanged: rc({0:X}) Button({1:X}) ButtonTarget({2:X})",
                rc, Button, ButtonTarget);
        }
        //! [targetchanged_handler]

        /// <summary>
        /// Check CMP return code for success.
        /// </summary>
        static bool CMP_SUCCESS(CMPRESULT rc)
        {
            // Need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        /// <summary>
        /// Register for button pressed and button target changed events
        /// </summary>
        static void RegisterForEvents()
        {
            //! [buttonpressed_subscription]
            // Subscribed ButtonPressed event
            cmp.ButtonPressed += new ICMPEvents_ButtonPressedEventHandler(cmp_ButtonPressed);
            //! [buttonpressed_subscription]

            //! [targetchanged_subscription]
            // Subscribed ButtonTargetChanged event
            cmp.ButtonTargetChanged += new ICMPEvents_ButtonTargetChangedEventHandler(cmp_ButtonTargetChanged);
            //! [targetchanged_subscription]
        }

        /// <summary>
        /// Set the button target to the host event handler
        /// </summary>
        static CMPRESULT SetButtonTarget(CMP_BUTTON_TARGET target)
        {
            CMPRESULT rc;

            //! [redirect_button]
            // Redirect the "Back" button to the host (this application).
            rc = cmp.SetButtonTarget(CMP_BUTTON_ID.CMP_BUTTON_BACK, target);
            //! [redirect_button]

            if (CMP_SUCCESS(rc))
            {
                Console.WriteLine("SetButtonTarget success");
            }
            else
            {
                Console.WriteLine("SetButtonTarget failed rc={0:X}", rc);
            }

            return (rc);
        }

    }
}
