// C++ Take picture example using Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to take a picture and transfer it to server.
//
// Copyright (c) 2012 Citrix Systems
//


#include <stdio.h>
#include <windows.h>

// Citrix Mobility Pack include files
#include <cmp.h>

// Local functions
void        ReportStatus(LPCSTR text, CMPRESULT rc);
CMPRESULT   RegisterForEvent(HANDLE hCMP);
CMPRESULT   TakePicture(HANDLE hCMP, CMP_UNIQUE_ID pictureId, CMP_IMAGE_FORMAT imageFormat);
BOOL        CopyPicture(LPCWSTR pictureSource);

// Local structure
struct PICTURE_DATA
{
    CMPRESULT           pictureResult;
    CMP_UNIQUE_ID       pictureId;
    CMP_IMAGE_FORMAT    pictureFormat;
    UINT32              pictureSize;
    UTF8_STRING         filename;
};

// local variables
HANDLE          hPictureEvent = NULL;                                               // picture event
PICTURE_DATA    g_PictureData = { CMP_NO_ERROR, 0, (CMP_IMAGE_FORMAT)0, 0, NULL};   // picture event data

CMP_UNIQUE_ID pictureId = 0x121;

/**
 * main entry point
 */
int __cdecl main(int argc, char **argv)
{
    CMPRESULT rc;
    DWORD winrc;

    // create an event that is not manual reset with initial state set to non-signaled
    hPictureEvent = CreateEvent(NULL, FALSE, FALSE, NULL);

    // initialize Citrix Mobility Pack for MultiThreadApartment(TRUE)
    rc = CMPInitialize(TRUE);

    ReportStatus("CMPInitialize", rc);

    if(CMP_SUCCESS(rc))
    {
        HANDLE hCMP;

        // open the Citrix Mobility Pack handle
        rc = CMPOpen(&hCMP);

        // report if failure
        ReportStatus("CMPOpen", rc);

        if(CMP_SUCCESS(rc))
        {
            // establish a connection between XenApp and Receiver (virtual channel)
            rc = CMPOpenSession(hCMP);

            // report if failure
            ReportStatus("CMPOpenSession", rc);

            if(CMP_SUCCESS(rc))
            {
                // register for the picture taken event
                rc = RegisterForEvent(hCMP);

                if(CMP_SUCCESS(rc))
                {
                    // request that a picture be taken in JPEG format
                    rc = TakePicture(hCMP, pictureId, CMP_IMAGE_FORMAT_JPEG);

                    if(CMP_SUCCESS(rc))
                    {
                        DWORD waitTime = 60000;

                        printf("Waiting for the picture to be taken within the next 60 seconds.\n");

                        // wait for 60 seconds for the picture to be taken
                        winrc = WaitForSingleObject(hPictureEvent, waitTime);

                        if(winrc == WAIT_OBJECT_0)
                        {
                            // the picture taken event has happened within the time limit
                            if(CMP_SUCCESS(g_PictureData.pictureResult))
                            {
                                printf("Picture id(0x%X) format(%u) size(%u) filename(%s)\n", 
                                        g_PictureData.pictureId, g_PictureData.pictureFormat, 
                                        g_PictureData.pictureSize, g_PictureData.filename);

                                // only process picture if it is one of ours
                                if(pictureId == g_PictureData.pictureId)
                                {
                                    BSTR bstrFilename = NULL;

                                    // convert the UTF-8 filename to UTF-16 (Windows Unicode)
                                    rc = UTF8ToBSTR((UTF8_STRING)g_PictureData.filename, -1, &bstrFilename);

                                    if(CMP_SUCCESS(rc))
                                    {
                                        BOOL copySuccess;

                                        copySuccess = CopyPicture(bstrFilename);
                                    }
                                }

                            }
                            else
                            {
                                ReportStatus("TakePicture event", g_PictureData.pictureResult);
                            }
                        }
                        else
                        {
                            printf("Take Picture timeout\n");
                        }
                    }
                }

                rc = CMPCloseSession(hCMP);

                ReportStatus("CMPCloseSession", rc);

            }
        }

        rc = CMPClose(hCMP);

        ReportStatus("CMPClose", rc);

        rc = CMPUninitialize();

        ReportStatus("CMPUninitialize", rc);
    }

}

/// <summary>
/// Check CMP return code for success and report errors if they happen.
/// </summary>
void ReportStatus(LPCSTR text, CMPRESULT rc)
{
    if(CMP_FAILURE(rc))
    {
        printf("%s CMPResult(%08X)\n", text, rc);
    }

    return;
}

//! [eventhandler]
// <summary>
// PictureTaken event handler.
// </summary>
// <param name="hCMP">CMP handler.</param>
// <param name="result">Picture result.</param>
// <param name="pictureId">Picture identifier.</param>
// <param name="pictureFormat">Picture format.</param>
// <param name="pictureSize">Picture size.</param>
// <param name="filename">Picture filename.</param>
void CMPCALL PictureTaken(
	HANDLE hCMP, 
	CMPRESULT result, 
	CMP_UNIQUE_ID pictureId,
	CMP_IMAGE_FORMAT pictureFormat, 
	UINT32 pictureSize, 
	UTF8_STRING filename)
{
    printf("PictureTaken event\n");

    // Copy the relevant data and then signal the event
    g_PictureData.pictureResult = result;
    g_PictureData.pictureId     = pictureId;
    g_PictureData.pictureFormat = pictureFormat;
    g_PictureData.pictureSize   = pictureSize;
    g_PictureData.filename      = _strdup(filename);

    printf("Picture result(0x%X) id(0x%X) format(%u) size(%u) filename(%s)\n", 
            result, pictureId, pictureFormat, pictureSize, filename);

    SetEvent(hPictureEvent);
}
//! [eventhandler]


/// <summary>
/// Register for take picture event
/// </summary>
CMPRESULT RegisterForEvent(HANDLE hCMP)
{
    CMPRESULT rc;

    //! [eventsubscription]
    // Subscribed PictureTaken event.
    rc = CMPRegisterForEvent(hCMP, CMP_EVENT_CAMERA_PICTURE_TAKEN, (CMP_EVENT_CALLBACK)PictureTaken);
    //! [eventsubscription]

    // report if failure
    ReportStatus("CMPRegisterForEvent", rc);

    return(rc);
}

/// <summary>
/// Take a picture
/// </summary>
CMPRESULT TakePicture(HANDLE hCMP, CMP_UNIQUE_ID pictureId, CMP_IMAGE_FORMAT imageFormat)
{
    CMPRESULT rc;

    //! [takepicture]
    // request a picture to be taken
    rc = CMPTakePicture(hCMP, pictureId, imageFormat);
    //! [takepicture]

    // report if failure
    ReportStatus("CMPTakePicture", rc);

    return(rc);
}

/// <summary>
/// Copy the picture to a known destination directory on server
/// </summary>
BOOL CopyPicture(LPCWSTR pictureSource)
{
    BOOL Success = FALSE;

    LPCWSTR file = wcsrchr(pictureSource, L'\\');
    WCHAR newLocation[MAX_PATH];

    wcscpy_s(newLocation, MAX_PATH, L"c:\\photos\\");

    if(file != NULL)
    {
        BOOL copySuccess;
        file++;

        // build the destination path for the picture based on
        // the original picture file name
        wcscat_s(newLocation, MAX_PATH, file);

        printf("CMPGetPictureFilename mobileFilename(%S) newLocation(%S)\n", pictureSource, newLocation);

        // allow for the existing destination file to be overwritten
        copySuccess = CopyFile(pictureSource, newLocation, FALSE);

        if(copySuccess == FALSE)
        {
            printf("Copy failed rc(%u)\n", GetLastError());
        }
        else
        {
            Success = TRUE;
            printf("Copy succeeded\n");
        }
    }

    return(Success);
}