﻿// C# Show picker example using COM Interop with Citrix Mobility SDK
//
// Uses Citrix Mobility SDK to show a picker control
//
// Copyright (c) 2012 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CitrixMobility;
using System.Threading;

using CMPRESULT     = System.Int32;
using CMP_UNIQUE_ID = System.Int32;

namespace showpicker
{
    class Program
    {
        static CitrixMobile cmp;
        static string[] pickerText = { "Blue", "Green", "Yellow", "White" };
        const CMP_UNIQUE_ID PickerId = 0x13141516;

        [STAThread]
        static void Main(string[] args)
        {
            int rc = (int)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Console.WriteLine("Creating CitrixMobile object");
                cmp = new CitrixMobile();

                Console.WriteLine("Calling OpenSession");
                rc = cmp.OpenSession();

                if(CMP_SUCCESS(rc))
                {
                    // register for picker control state changed
                    RegisterForEvent();

                    // Show the picker control
                    rc = ShowPicker();

                    if (CMP_SUCCESS(rc))
                    {
                        // Loop for thirty seconds to allow for events to happen
                        for (int i = 0; i < 30; i++)
                        {
                            Thread.Sleep(1000);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("OpenSession failed rc={0:X}", rc);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }

        //! [eventhandler]
        // <summary>
        // PickerControlStateChanged event handler.
        // </summary>
        // <param name="pickerId">Picker identifier.</param>
        // <param name="pickerStateFlags">Picker state flags.</param>
        // <param name="rc">Return code.</param>
        // <param name="selectedIndex">Selected index.</param>
        static void cmp_PickerControlStateChanged(
            CMP_UNIQUE_ID pickerId,
            Int16 pickerStateFlags,
            CMPRESULT rc,
            Int16 selectedIndex)
        {
            CMP_PICKER_CONTROL_STATE pickerState = (CMP_PICKER_CONTROL_STATE)pickerStateFlags;

            Console.WriteLine("Picker control state changed pickerId({0:X}) flags({1:X}) rc({2:X} selectedIndex({3})",
                              pickerId, pickerStateFlags, rc, selectedIndex);

            // only proceed if picker is one of ours
            if (pickerId == PickerId)
            {
                if (IsPickerVisible(pickerState))
                {
                    Console.WriteLine("Picker is visible");
                }

                if (IsPickerSelected(pickerState))
                {
                    Console.WriteLine("Picker item has been selected.  Index({0}) Item({1})",
                                      selectedIndex, pickerText[selectedIndex]);
                }

                if (IsPickerAborted(pickerState))
                {
                    Console.WriteLine("Picker control was aborted");
                }
            }
        }
        //! [eventhandler]

        /// <summary>
        /// Check CMP return code for success.
        /// </summary>
        static bool CMP_SUCCESS(CMPRESULT rc)
        {
            // Need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        /// <summary>
        /// Register for picker control state changed
        /// </summary>
        static void RegisterForEvent()
        {
            Console.WriteLine("Hooking picker control changed event");

            //! [eventsubscription]                    
            // Subscribed PickerControlStateChanged event.
            cmp.PickerControlStateChanged += new ICMPEvents_PickerControlStateChangedEventHandler(cmp_PickerControlStateChanged);
            //! [eventsubscription]
        }

        /// <summary>
        /// Show the picker control
        /// </summary>
        static CMPRESULT ShowPicker()
        {
            CMPRESULT rc;
            CMP_DISPLAY_RECT rect = new CMP_DISPLAY_RECT();
            string pickerTitle = "Pick a color";

            //! [showpicker]
            // Show the picker control.
            rc = cmp.ShowPicker(PickerId, ref rect, 0, ref pickerText, pickerTitle);
            //! [showpicker]

            if (CMP_SUCCESS(rc))
            {
                Console.WriteLine("ShowPicker success");
            }
            else
            {
                Console.WriteLine("ShowPicker failed rc={0:X}", rc);
            }

            return (rc);
        }

        /// <summary>
        /// Determine if the picker is currently visible
        /// </summary>
        static bool IsPickerVisible(CMP_PICKER_CONTROL_STATE state)
        {
            bool visible = false;

            if ((state & CMP_PICKER_CONTROL_STATE.CMP_PICKER_CONTROL_STATE_VISIBLE) != 0)
            {
                visible = true;
            }

            return (visible);
        }

        /// <summary>
        /// Determine if the picker has been selected
        /// </summary>
        static bool IsPickerSelected(CMP_PICKER_CONTROL_STATE state)
        {
            bool selected = false;

            if ((state & CMP_PICKER_CONTROL_STATE.CMP_PICKER_CONTROL_STATE_SELECTED) != 0)
            {
                selected = true;
            }

            return (selected);
        }

        /// <summary>
        /// Determine if the picker has been aborted
        /// </summary>
        static bool IsPickerAborted(CMP_PICKER_CONTROL_STATE state)
        {
            bool aborted = false;

            if ((state & CMP_PICKER_CONTROL_STATE.CMP_PICKER_CONTROL_STATE_ABORTED) != 0)
            {
                aborted = true;
            }

            return (aborted);
        }

    }
}

