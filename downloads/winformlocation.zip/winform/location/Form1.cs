﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using LocationApiLib;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace location
{
    public partial class Form1 : Form
    {
        //! [ilocation]
        // Instance of ILocation interface.
        private ILocation location;
        //! [ilocation]

        // There are two kinds of location information available: Latitude and Longitude,
        // and Civic address information.
        //
        // These information are identified by the corresponding GUIDs as specified in the
        // LocationApi.h header file in the Windows SDK.
        //! [guid]
        private static string IID_LatLongReportString = "7FED806D-0EF8-4f07-80AC-36A0BEAE3134";
        Guid IID_LatLongReport = new Guid(IID_LatLongReportString);

        private static string IID_CivicAddressReportString = "C0B19F70-4ADF-445d-87F2-CAD8FD711792";
        Guid IID_CivicAddressReport = new Guid(IID_CivicAddressReportString);
        //! [guid]

        public Form1()
        {
            InitializeComponent();
        }

        // <summary>
        // Dispatch action to UI thread if necessary.
        // </summary>
        // <param name="action">The action.</param>
        private void UiDispatch(Action action)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(action);
            }
            else
            {
                action();
            }
        }

        // <summary>
        // Worker thread to retrieve location information.
        // </summary>
        public void LocationThreadRunner()
        {
            // Clear existing Location information.
            latitudeTextBox.Text = string.Empty;
            longitudeTextBox.Text = string.Empty;
            errorRadiusTextBox.Text = string.Empty;
            timestampTextBox.Text = string.Empty;
            address1TextBox.Text = string.Empty;
            address2TextBox.Text = string.Empty;
            suburbTextBox.Text = string.Empty;
            stateTextBox.Text = string.Empty;
            postCodeTextBox.Text = string.Empty;
            countryTextBox.Text = string.Empty;
            
            UiDispatch(() => this.status.Text = "Retrieving Location LatLong report status...");

        //! [latlongstatus]
        // Work out what the LatLong report status is.
        LOCATION_REPORT_STATUS locStatus = location.GetReportStatus(ref IID_LatLongReport);
        //! [latlongstatus]
            if (locStatus == LOCATION_REPORT_STATUS.REPORT_RUNNING)
            {
                UiDispatch(() => this.status.Text = "LatLong information is available.");

                // Work out our latitude and longitude information.
                try
                {
        //! [getlatlongreport]
        // Get LatLong report.
        ILatLongReport latLongReport = (ILatLongReport)this.location.GetReport(ref IID_LatLongReport);

        // Once we have a LatLong report, we can extract the latitude and longitude information.
        double latitude = latLongReport.GetLatitude();
        double longitude = latLongReport.GetLongitude();
        double errorRadius = latLongReport.GetErrorRadius();
        _SYSTEMTIME timestamp = latLongReport.GetTimestamp();
        //! [getlatlongreport]

                    UiDispatch(() => this.status.Text = "Retrieved latitude and longitude.");

                    UiDispatch(() => this.latitudeTextBox.Text = latitude.ToString());
                    UiDispatch(() => this.longitudeTextBox.Text = longitude.ToString());
                    UiDispatch(() => this.errorRadiusTextBox.Text = errorRadius.ToString());

                    DateTime utcTime = new DateTime(timestamp.wYear, timestamp.wMonth, timestamp.wDay, timestamp.wHour, timestamp.wMinute, timestamp.wSecond);
                    UiDispatch(() => this.timestampTextBox.Text = utcTime.ToString("u"));
                }
                catch (COMException e)
                {
                    UiDispatch(() => this.status.Text = "Exception while retrieving LatLong information: " + e.ToString());
                }
            }
            else
            {
                UiDispatch(() => this.status.Text = "LatLong report information is not available: " + locStatus);
            }

            UiDispatch(() => this.status.Text = "Retrieving Location Civic report status...");

        //! [civicsstatus]
        // Work out what the civic address report status is.
        locStatus = location.GetReportStatus(ref IID_CivicAddressReport);
        //! [civicsstatus]
            if (locStatus == LOCATION_REPORT_STATUS.REPORT_RUNNING)
            {
                // Work out whether civic address information.
                try
                {
        //! [getcivicreport]
        // Get civic address report.
        ICivicAddressReport civicReport = (ICivicAddressReport)location.GetReport(ref IID_CivicAddressReport);

        // Once we have a Civic report, we can extract the civic information.
        if (civicReport.GetAddressLine1() != null)
        {
            UiDispatch(() => this.address1TextBox.Text = civicReport.GetAddressLine1());
        }
        if (civicReport.GetAddressLine2() != null)
        {
            UiDispatch(() => this.address2TextBox.Text = civicReport.GetAddressLine2());
        }
        if (civicReport.GetCity() != null)
        {
            UiDispatch(() => this.suburbTextBox.Text = civicReport.GetCity());
        }
        if (civicReport.GetStateProvince() != null)
        {
            UiDispatch(() => this.stateTextBox.Text = civicReport.GetStateProvince());
        }
        if (civicReport.GetPostalCode() != null)
        {
            UiDispatch(() => this.postCodeTextBox.Text = civicReport.GetPostalCode());
        }
        if (civicReport.GetCountryRegion() != null)
        {
            UiDispatch(() => this.countryTextBox.Text = civicReport.GetCountryRegion());
        }
        //! [getcivicreport]

                    UiDispatch(() => this.status.Text = "Retrieved civic information.");
                }
                catch (COMException e)
                {
                    UiDispatch(() => this.status.Text = "Exception while retrieving civic information: " + e.ToString());
                }
            }
            else
            {
                UiDispatch(() => this.status.Text = "Civic report information is not available: " + locStatus);
            }
        }

        // <summary>
        // Handle the Location button press.
        // </summary>
        private void locationButton_Click(object sender, EventArgs e)
        {
            UiDispatch(() => this.status.Text = "Retrieving location information...");

            if (null == this.location)
            {
                this.location = new Location();
            }
            
            // Queue a background work item to retrieve the location information.
            ThreadPool.QueueUserWorkItem((o) => this.LocationThreadRunner());
        }
    }
}
