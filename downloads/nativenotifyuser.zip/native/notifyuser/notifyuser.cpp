// C++ Notify User example using Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to send a notification to the user of the mobile device.
//
// Copyright (c) 2012 Citrix Systems
//

#include <stdio.h>
#include <windows.h>

#include <cmp.h>

// global notifyId - used for tracking NotifyUser requests
CMP_UNIQUE_ID notifyId = 0x12345678;

// local functions
void        ReportStatus(LPCSTR text, CMPRESULT rc);
CMPRESULT   RegisterForEvent(HANDLE hCMP);
void        WaitForCMPEvents(int seconds);
CMPRESULT   NotifyUser(HANDLE hCMP, USHORT flags, UTF8_STRING text);

//
// main entry point for simple notify user program
//
int __cdecl main(int argc, char **argv)
{
    CMPRESULT rc;
    HANDLE hCMP = NULL;

    // initialize for STA (Single Thread Apartment) in COM
    rc = CMPInitialize(FALSE);

    ReportStatus("CMPInitialize", rc);

    // Open a handle to the mobile device
    rc = CMPOpen(&hCMP);

    ReportStatus("CMPOpen", rc);

    if(CMP_SUCCESS(rc))
    {
        // open the link between the two sides
        rc = CMPOpenSession(hCMP);

        ReportStatus("CMPOpenSession", rc);

        if(CMP_SUCCESS(rc))
        {
            // register for user notified event
            rc = RegisterForEvent(hCMP);

            if(CMP_SUCCESS(rc))
            {
                // notify the user via vibrate and text.
                rc = NotifyUser(hCMP, CMP_NOTIFICATION_FLAG_VIBRATE | CMP_NOTIFICATION_FLAG_TEXT, "You have been notified via vibrate and text.");

                printf("You have been notified via vibrate and text.");
                WaitForCMPEvents(3);

                // notify the user via audio and text.
                rc = NotifyUser(hCMP, CMP_NOTIFICATION_FLAG_AUDIO | CMP_NOTIFICATION_FLAG_TEXT, "You have been notified via audio and text.");
                
                printf("You have been notified via audio and text.");
                WaitForCMPEvents(3);

                // notify the user via light and text
                rc = NotifyUser(hCMP, CMP_NOTIFICATION_FLAG_LIGHT | CMP_NOTIFICATION_FLAG_TEXT, "You have been notified via light and text.");
                
                printf("You have been notified via light and text.");
                WaitForCMPEvents(3);

                if(CMP_SUCCESS(rc))
                {
                    // let events come in over the next 30 seconds
                    // if this was a Windows program and we had a message loop, we would not need to do this
                    WaitForCMPEvents(30);
                }
            }

            // close our connection
            CMPCloseSession(hCMP);
        }

        // release our handle
        CMPClose(hCMP);
    }

    // uninitialize COM
    CMPUninitialize();

}

//! [eventhandler]
// <summary>
// UserNotified event handler.
// </summary>
// <param name="hCMP">CMP handler.</param>
// <param name="rc">Return code.</param>
// <param name="NotifyId">Notification identifier.</param>
void CMPAPI UserNotified(HANDLE hCMP, CMPRESULT rc, CMP_UNIQUE_ID NotifyId)
{
    // only proceed if the notification is one of ours
    if(notifyId == NotifyId)
    {
        printf("UserNotified hCMP(%p) rc(0x%X) NotifyId(%X)\n", hCMP, rc, NotifyId);
    }
}
//! [eventhandler]

/// <summary>
/// Check CMP return code for success and report errors if they happen.
/// </summary>
void ReportStatus(LPCSTR text, CMPRESULT rc)
{
    // only print if something went wrong
    if(CMP_FAILURE(rc))
    {
        printf("%s CMPResult(%08X)\n", text, rc);
    }

    return;
}

/// <summary>
/// Register for user notified event to get callback
/// </summary>
CMPRESULT RegisterForEvent(HANDLE hCMP)
{
    CMPRESULT rc;

    //! [eventsubscription]
    // Subscribe to UserNotified event.
    rc = CMPRegisterForEvent(hCMP, CMP_EVENT_USER_NOTIFIED, (CMP_EVENT_CALLBACK)UserNotified); 
    //! [eventsubscription]

    ReportStatus("CMPRegisterForEvent CMP_EVENT_USER_NOTIFIED", rc);

    return(rc);
}

/// <summary>
/// Notify the user of an event
/// </summary>
CMPRESULT NotifyUser(HANDLE hCMP, USHORT flags, UTF8_STRING text)
{
    CMPRESULT rc;

    //! [notifyuser]
    // Send a vibration notification with text to the mobile device.
    rc = CMPNotifyUser(hCMP, notifyId, flags, text);
    //! [notifyuser]

    ReportStatus("CMPNotifyUser", rc);

    return(rc);
}

// <summary>
// A "wait" spin loop to give the events a chance to happen
// </summary>
void WaitForCMPEvents(int seconds)
{
    for(int i=0; i<seconds; i++)
    {
        Sleep(1000);
    }
}
