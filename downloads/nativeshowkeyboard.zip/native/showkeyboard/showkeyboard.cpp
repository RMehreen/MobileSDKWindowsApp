// C++ Show keyboard example using COM Interop with Citrix Mobility SDK
//
// Uses Citrix Mobility SDK to show a display keyboard
//
// Copyright (c) 2012 Citrix Systems
//

#include <stdio.h>
#include <windows.h>

#include <cmp.h>

// Local functions
void        ReportStatus(LPCSTR text, CMPRESULT rc);
void        WaitForCMPEvents(int seconds);
CMPRESULT   RegisterForEvent(HANDLE hCMP);
CMPRESULT   ShowKeyboard(HANDLE hCMP, CMP_KEYBOARD_TYPE kybdType, INT16 kybdFlags);

//
// main entry point for simple phone call program
//
int __cdecl main(int argc, char **argv)
{
    CMPRESULT rc;
    HANDLE hCMP = NULL;

    // initialize for STA (Single Thread Apartment) in COM
    rc = CMPInitialize(FALSE);

    ReportStatus("CMPInitialize", rc);

    // Open a handle to the mobile device
    rc = CMPOpen(&hCMP);

    ReportStatus("CMPOpen", rc);

    if(CMP_SUCCESS(rc))
    {
        // open the link between the two sides
        rc = CMPOpenSession(hCMP);

        ReportStatus("CMPOpenSession", rc);

        if(CMP_SUCCESS(rc))
        {
            // register for keyboard state change events
            rc = RegisterForEvent(hCMP);

            if(CMP_SUCCESS(rc))
            {
                // Not using the rectangle here but could be used to indicate what part of the screen to show with the keyboard.
                // Typically this would be a edit text box.
                rc = ShowKeyboard(hCMP, CMP_KYBD_TYPE_STANDARD, 0);

                // let events come in over the next 30 seconds
                // if this was a Windows program and we had a message loop, we would not need to do this
                if(CMP_SUCCESS(rc))
                {
                    WaitForCMPEvents(30);
                }
            }

            // close our connection
            CMPCloseSession(hCMP);
        }

        // release our handle
        CMPClose(hCMP);
    }

    // uninitialize COM
    CMPUninitialize();

}

//! [eventhandler]
// <summary>
// KeyboardStateChanged event handler.
// </summary>
// <param name="hCMP">CMP handler.</param>
// <param name="rc">Return code.</param>
// <param name="kybdType">Keyboard type.</param>
// <param name="kybdFlags">Keyboard flags.</param>
// <param name="kybdAutoCaps">Keyboard auto caps lock.</param>
// <param name="kybdReturnKey">Keyboard return key</param>
void CMPAPI KeyboardStateChanged(
	HANDLE hCMP, 
	CMPRESULT rc, 
	CMP_KEYBOARD_TYPE kybdType, 
	INT16 kybdFlags, 
	CMP_KEYBOARD_AUTOCAPS kybdAutoCaps, 
	CMP_KEYBOARD_RETURNKEY kybdReturnKey)
{
    printf("KeyboardStateChanged hCMP(%p) rc(0x%X) kybdType(%u) "
		"Flags(0x%X) AutoCaps(%u) ReturnKey(%u)\n", 
		hCMP, rc, kybdType, kybdFlags, kybdAutoCaps, kybdReturnKey);
}
//! [eventhandler]

/// <summary>
/// Check CMP return code for success and report errors if they happen.
/// </summary>
void ReportStatus(LPCSTR text, CMPRESULT rc)
{
    // only print if something went wrong
    if(CMP_FAILURE(rc))
    {
        printf("%s CMPResult(%08X)\n", text, rc);
    }

    return;
}

// <summary>
// A "wait" spin loop to give the events a chance to happen
// </summary>
void WaitForCMPEvents(int seconds)
{
    for(int i=0; i<seconds; i++)
    {
        Sleep(1000);
    }
}

/// <summary>
/// Register to keyboard state changed event
/// </summary>
CMPRESULT RegisterForEvent(HANDLE hCMP)
{
    CMPRESULT rc;

    //! [eventsubscription]
    // Subscribed KeyboardStateChanged event
    rc = CMPRegisterForEvent(hCMP, CMP_EVENT_KEYBOARD_STATE_CHANGED, (CMP_EVENT_CALLBACK)KeyboardStateChanged); 
    //! [eventsubscription]

    ReportStatus("CMPRegisterForEvent CMP_EVENT_KEYBOARD_STATE_CHANGED", rc);

    return(rc);
}

/// <summary>
/// Show the keyboard
/// </summary>
CMPRESULT ShowKeyboard(HANDLE hCMP, CMP_KEYBOARD_TYPE kybdType, INT16 kybdFlags)
{
    CMPRESULT rc;
    CMP_KEYBOARD_STATE kybdState;

    memset(&kybdState, 0, sizeof(kybdState));

    //! [showkeyboard]
    kybdState.KybdType = kybdType;

    // Flags change how ShowKeyboard works.  The flags are defined in CMP_KEYBOARD_FLAGS
    kybdState.KybdFlags = kybdFlags;

    // Show the keyboard with the specific settings
    rc = CMPShowKeyboard(hCMP, &kybdState);
    //! [showkeyboard]

    ReportStatus("CMPShowKeyboard", rc);

    return(rc);
}
