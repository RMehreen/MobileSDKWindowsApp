﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

using CitrixMobility;

namespace capabilities
{
    public partial class Form1 : Form
    {
        // <summary>
        // Instance of CitrixMobile.
        // </summary>
        private CitrixMobile cmp = null;

        // <summary>
        // ICA session connected state.
        // </summary>
        private bool icaSessionConnected = false;

        // <summary>
        // Instance of DeviceCapabilities to encapsulate capabilities to be displayed in the PropertyGrid.
        // </summary>
        private DeviceCapabilities deviceCaps = new DeviceCapabilities();

        // <summary>
        // Check CMP return code for success.
        // </summary>
        public bool CMP_SUCCESS(int rc)
        {
            // Need to mask the result since the top half can have the component ID.
            return ((rc & 0xffff) == (int)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        // <summary>
        // Dispatch action to UI thread if necessary.
        // </summary>
        // <param name="action">The action.</param>
        private void UiDispatch(Action action)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(action);
            }
            else
            {
                action();
            }
        }

        // <summary>
        // Report CMP status.
        // </summary>
        // <param name="text">Status text.</param>
        // <param name="rc">CMP return code.</param>
        private void ReportStatus(string text, int rc)
        {
            // Only report status if something went wrong.
            if (!CMP_SUCCESS(rc))
            {
                string msg = string.Format("{0}, CMPResult: 0x{1:X}", text, rc);
                
                // Write to trace output.
                Helpers.Trace(msg);
                // Update status text.
                UiDispatch(() => this.status.Text = msg);
            }
        }

        public Form1()
        {
            InitializeComponent();

            // Initialise CMP framework.
            InitialiseCmp();
        }

        // <summary>
        // Initialise CMP framework.
        // </summary>
        private void InitialiseCmp()
        {
            int rc = (int)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Helpers.Trace("Creating CitrixMobile object");
                // Create an instance of CitrixMobile object.
                cmp = new CitrixMobile();

                Helpers.Trace("Register for ICA session state changed events");
                // Register for ICA session events.
                cmp.SessionStateChanged += new ICMPEvents_SessionStateChangedEventHandler(cmp_SessionStateChanged);

                Helpers.Trace("Register for orientation changed events");
                // Register for orientation change events.
                cmp.OrientationChanged += new ICMPEvents_OrientationChangedEventHandler(cmp_OrientationChanged);

                Helpers.Trace("Calling OpenSession");
                // Open CMP session.
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    icaSessionConnected = true;

                    // Load device capabilities information.
                    LoadCapabilities();
                    propertyGrid1.SelectedObject = deviceCaps;
                }
                else
                {
                    ReportStatus("OpenSession failed", rc);
                }
            }
            catch (System.Exception ex)
            {
                Helpers.Trace(ex.Message);
                Helpers.Trace(ex.StackTrace);
            }
        }

        // <summary>
        // Load the current device capabilities into the DeviceCapabilities object.
        // </summary>
        private void LoadCapabilities()
        {
            int rc = (int)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                bool bValue;
                int iValue;
                short sValue;

                // Load CAPID_INPUT capabilities.
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_ENABLE, out bValue);
                deviceCaps.CAP_INPUT_ENABLE = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_KYBD, out bValue);
                deviceCaps.CAP_INPUT_KYBD = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_PHYSICAL_KYBD, out bValue);
                deviceCaps.CAP_INPUT_PHYSICAL_KYBD = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_TRACKBALL, out bValue);
                deviceCaps.CAP_INPUT_TRACKBALL = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_MOUSE, out bValue);
                deviceCaps.CAP_INPUT_MOUSE = bValue;
        //![capability_stdkybd]
        // Determine whether the standard on-screen keyboard is enabled on the connected device.
        rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_STD_KYBD, out bValue);
        //![capability_stdkybd]
                deviceCaps.CAP_INPUT_STD_KYBD = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_NUMPAD_KYBD, out bValue);
                deviceCaps.CAP_INPUT_NUMPAD_KYBD = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_PHONEPAD_KYBD, out bValue);
                deviceCaps.CAP_INPUT_PHONEPAD_KYBD = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_URL_KYBD, out bValue);
                deviceCaps.CAP_INPUT_URL_KYBD = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_EMAIL_KYBD, out bValue);
                deviceCaps.CAP_INPUT_EMAIL_KYBD = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_PHONE_NAME_KYBD, out bValue);
                deviceCaps.CAP_INPUT_PHONE_NAME_KYBD = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_NUMBERS_PUNC_KYBD, out bValue);
                deviceCaps.CAP_INPUT_NUMBERS_PUNC_KYBD = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_DECIMAL_POINT_KYBD, out bValue);
                deviceCaps.CAP_INPUT_DECIMAL_POINT_KYBD = bValue;
        //![capability_inputhide]
        // Determine whether the ability to show/hide on-screen keyboard is enabled on the connected device.
        rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_HIDE, out bValue);
        //![capability_inputhide]
                deviceCaps.CAP_INPUT_HIDE = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_AUTO_CORRECT, out bValue);
                deviceCaps.CAP_INPUT_AUTO_CORRECT = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_AUTO_CAPITALIZATION, out bValue);
                deviceCaps.CAP_INPUT_AUTO_CAPITALIZATION = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_AUTO_CAPITAL_WORD, out bValue);
                deviceCaps.CAP_INPUT_AUTO_CAPITAL_WORD = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_AUTO_CAPITAL_SENTENCE, out bValue);
                deviceCaps.CAP_INPUT_AUTO_CAPITAL_SENTENCE = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_AUTO_CAPITAL_LETTERS, out bValue);
                deviceCaps.CAP_INPUT_AUTO_CAPITAL_LETTERS = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_DEFAULT, out bValue);
                deviceCaps.CAP_INPUT_RETURN_KEY_DEFAULT = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_GO, out bValue);
                deviceCaps.CAP_INPUT_RETURN_KEY_GO = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_GOOGLE, out bValue);
                deviceCaps.CAP_INPUT_RETURN_KEY_GOOGLE = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_JOIN, out bValue);
                deviceCaps.CAP_INPUT_RETURN_KEY_JOIN = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_NEXT, out bValue);
                deviceCaps.CAP_INPUT_RETURN_KEY_NEXT = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_ROUTE, out bValue);
                deviceCaps.CAP_INPUT_RETURN_KEY_ROUTE = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_SEARCH, out bValue);
                deviceCaps.CAP_INPUT_RETURN_KEY_SEARCH = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_SEND, out bValue);
                deviceCaps.CAP_INPUT_RETURN_KEY_SEND = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_DONE, out bValue);
                deviceCaps.CAP_INPUT_RETURN_KEY_DONE = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_INPUT, (short)CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY, out bValue);
                deviceCaps.CAP_INPUT_RETURN_KEY = bValue;

                // Load CAPID_ORIENTATION capabilities.
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_ORIENTATION, (short)CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_ENABLE, out bValue);
                deviceCaps.CAP_ORIENTATION_ENABLE = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_ORIENTATION, (short)CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_DEVICE, out bValue);
                deviceCaps.CAP_ORIENTATION_DEVICE = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_ORIENTATION, (short)CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_APPLICATION, out bValue);
                deviceCaps.CAP_ORIENTATION_APPLICATION = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_ORIENTATION, (short)CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_PORTRAIT, out bValue);
                deviceCaps.CAP_ORIENTATION_PORTRAIT = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_ORIENTATION, (short)CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_PORTRAIT_DOWN, out bValue);
                deviceCaps.CAP_ORIENTATION_PORTRAIT_DOWN = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_ORIENTATION, (short)CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_LANDSCAPE_LEFT, out bValue);
                deviceCaps.CAP_ORIENTATION_LANDSCAPE_LEFT = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_ORIENTATION, (short)CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_LANDSCAPE_RIGHT, out bValue);
                deviceCaps.CAP_ORIENTATION_LANDSCAPE_RIGHT = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_ORIENTATION, (short)CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_LOCK_UNLOCK, out bValue);
                deviceCaps.CAP_ORIENTATION_LOCK_UNLOCK = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_ORIENTATION, (short)CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_FOLLOW_SENSOR, out bValue);
                deviceCaps.CAP_ORIENTATION_FOLLOW_SENSOR = bValue;

                // Load CAPID_DISPLAY_INFO capabilities.
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_ENABLE, out bValue);
                deviceCaps.CAP_DISPLAY_ENABLE = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_RESOLUTION_FLAG, out bValue);
                deviceCaps.CAP_DISPLAY_RESOLUTION_FLAG = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_COLOR_FLAG, out bValue);
                deviceCaps.CAP_DISPLAY_COLOR_FLAG = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_PHYSICAL_FLAG, out bValue);
                deviceCaps.CAP_DISPLAY_PHYSICAL_FLAG = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_PPI_FLAG, out bValue);
                deviceCaps.CAP_DISPLAY_PPI_FLAG = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_PPI_X_Y_FLAG, out bValue);
                deviceCaps.CAP_DISPLAY_PPI_X_Y_FLAG = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_ORIENTATION_FLAG, out bValue);
                deviceCaps.CAP_DISPLAY_ORIENTATION_FLAG = bValue;
                rc = cmp.GetCapabilityInt32(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_METRICS, out iValue);
                deviceCaps.CAP_DISPLAY_METRICS = iValue;
        //![capability_displaywidth]
        // Get the display width of the connected device.
        rc = cmp.GetCapabilityInt32(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_WIDTH, out iValue);
        //![capability_displaywidth]
                deviceCaps.CAP_DISPLAY_WIDTH = iValue;
                rc = cmp.GetCapabilityInt32(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_HEIGHT, out iValue);
                deviceCaps.CAP_DISPLAY_HEIGHT = iValue;
                rc = cmp.GetCapabilityInt32(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_X_MILLI_INCHES, out iValue);
                deviceCaps.CAP_DISPLAY_X_MILLI_INCHES = iValue;
                rc = cmp.GetCapabilityInt32(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_Y_MILLI_INCHES, out iValue);
                deviceCaps.CAP_DISPLAY_Y_MILLI_INCHES = iValue;
        //![capability_displaydpi]
        // Get the display DPI of the connected device.
        rc = cmp.GetCapabilityInt32(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_PIXELS_PER_INCH, out iValue);
        //![capability_displaydpi]
                deviceCaps.CAP_DISPLAY_PIXELS_PER_INCH = iValue;
                rc = cmp.GetCapabilityInt32(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_X_PIXELS_PER_INCH, out iValue);
                deviceCaps.CAP_DISPLAY_X_PIXELS_PER_INCH = iValue;
                rc = cmp.GetCapabilityInt32(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_Y_PIXELS_PER_INCH, out iValue);
                deviceCaps.CAP_DISPLAY_Y_PIXELS_PER_INCH = iValue;
                rc = cmp.GetCapabilityInt16(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_INITIAL_ORIENTATION, out sValue);
                deviceCaps.CAP_DISPLAY_INITIAL_ORIENTATION = sValue;
                rc = cmp.GetCapabilityInt16(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_COLOR_DEPTH, out sValue);
                deviceCaps.CAP_DISPLAY_COLOR_DEPTH = sValue;

                // Load CAPID_SCROLL_MODES capabilities.
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_SCROLL_MODES, (short)CMP_CAP_SCROLLMODES_KEY_ID.CAP_SCROLLMODES_ENABLE, out bValue);
                deviceCaps.CAP_SCROLLMODES_ENABLE = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_SCROLL_MODES, (short)CMP_CAP_SCROLLMODES_KEY_ID.CAP_SCROLLMODES_MOUSEWHEEL_FLAG, out bValue);
                deviceCaps.CAP_SCROLLMODES_MOUSEWHEEL_FLAG = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_SCROLL_MODES, (short)CMP_CAP_SCROLLMODES_KEY_ID.CAP_SCROLLMODES_DRAG_FLAG, out bValue);
                deviceCaps.CAP_SCROLLMODES_DRAG_FLAG = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_SCROLL_MODES, (short)CMP_CAP_SCROLLMODES_KEY_ID.CAP_SCROLLMODES_PAN_FLAG, out bValue);
                deviceCaps.CAP_SCROLLMODES_PAN_FLAG = bValue;
                rc = cmp.GetCapabilityInt16(CMP_CAP_ID.CAPID_SCROLL_MODES, (short)CMP_CAP_SCROLLMODES_KEY_ID.CAP_SCROLLMODES_DEFAULT_MODE, out sValue);
                deviceCaps.CAP_SCROLLMODES_DEFAULT_MODE = sValue;

                // Load CAPID_BUTTON_SET_TARGET capabilities.
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_BUTTON_SET_TARGET, (short)CMP_CAP_BUTTON_KEY_ID.CAP_BUTTON_ENABLE, out bValue);
                deviceCaps.CAP_BUTTON_ENABLE = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_BUTTON_SET_TARGET, (short)CMP_CAP_BUTTON_KEY_ID.CAP_BUTTON_BACK, out bValue);
                deviceCaps.CAP_BUTTON_BACK = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_BUTTON_SET_TARGET, (short)CMP_CAP_BUTTON_KEY_ID.CAP_BUTTON_SEARCH, out bValue);
                deviceCaps.CAP_BUTTON_SEARCH = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_BUTTON_SET_TARGET, (short)CMP_CAP_BUTTON_KEY_ID.CAP_BUTTON_HOME, out bValue);
                deviceCaps.CAP_BUTTON_HOME = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_BUTTON_SET_TARGET, (short)CMP_CAP_BUTTON_KEY_ID.CAP_BUTTON_MENU, out bValue);
                deviceCaps.CAP_BUTTON_MENU = bValue;
                rc = cmp.GetCapabilityInt16(CMP_CAP_ID.CAPID_BUTTON_SET_TARGET, (short)CMP_CAP_BUTTON_KEY_ID.CAP_BUTTON_MASK, out sValue);
                deviceCaps.CAP_BUTTON_MASK = sValue;

                // Load CMP_CAP_TAKE_PICTURE_KEY_ID capabilities.
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_TAKE_PICTURE, (short)CMP_CAP_TAKE_PICTURE_KEY_ID.CAP_TAKE_PICTURE_ENABLE, out bValue);
                deviceCaps.CAP_TAKE_PICTURE_ENABLE = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_TAKE_PICTURE, (short)CMP_CAP_TAKE_PICTURE_KEY_ID.CAP_TAKE_PICTURE_JPEG, out bValue);
                deviceCaps.CAP_TAKE_PICTURE_JPEG = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_TAKE_PICTURE, (short)CMP_CAP_TAKE_PICTURE_KEY_ID.CAP_TAKE_PICTURE_PNG, out bValue);
                deviceCaps.CAP_TAKE_PICTURE_PNG = bValue;

                // Load CMP_CAP_DEVICE_KEY_ID capabilities.
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_DEVICE_INFO, (short)CMP_CAP_DEVICE_KEY_ID.CAP_DEVICE_ENABLE, out bValue);
                deviceCaps.CAP_DEVICE_ENABLE = bValue;
                rc = cmp.GetCapabilityInt16(CMP_CAP_ID.CAPID_DEVICE_INFO, (short)CMP_CAP_DEVICE_KEY_ID.CAP_DEVICE_OS, out sValue);
                deviceCaps.CAP_DEVICE_OS = sValue;
                rc = cmp.GetCapabilityInt16(CMP_CAP_ID.CAPID_DEVICE_INFO, (short)CMP_CAP_DEVICE_KEY_ID.CAP_DEVICE_OS_VER_HIGH, out sValue);
                deviceCaps.CAP_DEVICE_OS_VER_HIGH = sValue;
                rc = cmp.GetCapabilityInt16(CMP_CAP_ID.CAPID_DEVICE_INFO, (short)CMP_CAP_DEVICE_KEY_ID.CAP_DEVICE_OS_VER_LOW, out sValue);
                deviceCaps.CAP_DEVICE_OS_VER_LOW = sValue;
                rc = cmp.GetCapabilityInt16(CMP_CAP_ID.CAPID_DEVICE_INFO, (short)CMP_CAP_DEVICE_KEY_ID.CAP_DEVICE_OS_VER_MINOR, out sValue);
                deviceCaps.CAP_DEVICE_OS_VER_MINOR = sValue;
                rc = cmp.GetCapabilityInt16(CMP_CAP_ID.CAPID_DEVICE_INFO, (short)CMP_CAP_DEVICE_KEY_ID.CAP_DEVICE_OS_VER_BUILD, out sValue);
                deviceCaps.CAP_DEVICE_OS_VER_BUILD = sValue;
                rc = cmp.GetCapabilityInt16(CMP_CAP_ID.CAPID_DEVICE_INFO, (short)CMP_CAP_DEVICE_KEY_ID.CAP_DEVICE_TYPE, out sValue);
                deviceCaps.CAP_DEVICE_TYPE = sValue;

                // Load CMP_CAP_VIEWPORT_KEY_ID capabilities.
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_VIEWPORT, (short)CMP_CAP_VIEWPORT_KEY_ID.CAP_VIEWPORT_ENABLE, out bValue);
                deviceCaps.CAP_VIEWPORT_ENABLE = bValue;

                // Load CMP_CAP_DYNAMIC_DISPLAY_KEY_ID capabilities.
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_DYNAMIC_DISPLAY, (short)CMP_CAP_DYNAMIC_DISPLAY_KEY_ID.CAP_DYNAMIC_DISPLAY_ENABLE, out bValue);
                deviceCaps.CAP_DYNAMIC_DISPLAY_ENABLE = bValue;

                // Load CMP_CAP_PICKER_CONTROL_KEY_ID capabilities.
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_PICKER_CONTROL, (short)CMP_CAP_PICKER_CONTROL_KEY_ID.CAP_PICKER_CONTROL_ENABLE, out bValue);
                deviceCaps.CAP_PICKER_CONTROL_ENABLE = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_PICKER_CONTROL, (short)CMP_CAP_PICKER_CONTROL_KEY_ID.CAP_PICKER_CONTROL_TITLE_FLAG, out bValue);
                deviceCaps.CAP_PICKER_CONTROL_TITLE_FLAG = bValue;

                // Load CMP_CAP_PHONE_CALL_KEY_ID capabilities.
        //![capability_phone]
        // Determine whether phone dialing is enabled on the connected device.
        rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_PHONE_CALL, (short)CMP_CAP_PHONE_CALL_KEY_ID.CAP_PHONE_CALL_ENABLE, out bValue);
        //![capability_phone]
                deviceCaps.CAP_PICKER_CONTROL_ENABLE = bValue;

                // Load CMP_CAP_SMS_KEY_ID capabilities.
        //![capability_sms]
        // Determine whether sending SMS is enabled on the connected device.
        rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_SMS, (short)CMP_CAP_SMS_KEY_ID.CAP_SMS_ENABLE, out bValue);
        //![capability_sms]
                deviceCaps.CAP_SMS_ENABLE = bValue;

                // Load CMP_CAP_NOTIFICATION_KEY_ID capabilities.
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_NOTIFICATION, (short)CMP_CAP_NOTIFICATION_KEY_ID.CAP_NOTIFICATION_ENABLE, out bValue);
                deviceCaps.CAP_NOTIFICATION_ENABLE = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_NOTIFICATION, (short)CMP_CAP_NOTIFICATION_KEY_ID.CAP_NOTIFICATION_LIGHT, out bValue);
                deviceCaps.CAP_NOTIFICATION_LIGHT = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_NOTIFICATION, (short)CMP_CAP_NOTIFICATION_KEY_ID.CAP_NOTIFICATION_VIBRATE, out bValue);
                deviceCaps.CAP_NOTIFICATION_VIBRATE = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_NOTIFICATION, (short)CMP_CAP_NOTIFICATION_KEY_ID.CAP_NOTIFICATION_AUDIO, out bValue);
                deviceCaps.CAP_NOTIFICATION_AUDIO = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_NOTIFICATION, (short)CMP_CAP_NOTIFICATION_KEY_ID.CAP_NOTIFICATION_TEXT, out bValue);
                deviceCaps.CAP_NOTIFICATION_TEXT = bValue;

                // Load CMP_CAP_RECEIVER_CONTROLS_KEY_ID capabilities.
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_RECEIVER_CONTROLS, (short)CMP_CAP_RECEIVER_CONTROLS_KEY_ID.CAP_RECEIVER_CONTROLS_ENABLE, out bValue);
                deviceCaps.CAP_RECEIVER_CONTROLS_ENABLE = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_RECEIVER_CONTROLS, (short)CMP_CAP_RECEIVER_CONTROLS_KEY_ID.CAP_RECEIVER_CONTROLS_DISABLE, out bValue);
                deviceCaps.CAP_RECEIVER_CONTROLS_DISABLE = bValue;

                // Load CMP_CAP_EVENT_FILTER_KEY_ID capabilities.
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_EVENT_FILTER, (short)CMP_CAP_EVENT_FILTER_KEY_ID.CAP_EVENT_FILTER_ENABLE, out bValue);
                deviceCaps.CAP_EVENT_FILTER_ENABLE = bValue;
                rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_EVENT_FILTER, (short)CMP_CAP_EVENT_FILTER_KEY_ID.CAP_EVENT_FILTER_SUPPORT, out bValue);
                deviceCaps.CAP_EVENT_FILTER_SUPPORT = bValue;
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }

        // <summary>
        // Tear down CMP connection when closed.
        // </summary>
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if ((null != cmp) && icaSessionConnected)
            {
                // Close CMP session.
                cmp.CloseSession();
                cmp = null;
            }
        }

        // <summary>
        // Session state change handler.
        // </summary>
        // <remarks>Update the ICA session state upon connect/disconnect.</remarks>
        // <param name="SessState">Session state</param>
        void cmp_SessionStateChanged(CMP_SESSION_STATE SessState)
        {
            switch (SessState)
            {
                case CMP_SESSION_STATE.CMP_SESSION_STATE_CONNECTED:
                    Helpers.Trace("SessionStateChanged: CMP_SESSION_STATE_CONNECTED");
                    icaSessionConnected = true;

                    // Load device capabilities information when (re)connected.
                    LoadCapabilities();
                    propertyGrid1.SelectedObject = deviceCaps;
                    break;
                case CMP_SESSION_STATE.CMP_SESSION_STATE_DISCONNECTED:
                    Helpers.Trace("SessionStateChanged: CMP_SESSION_STATE_DISCONNECTED");
                    icaSessionConnected = false;
                    break;
                default:
                    break;
            }
        }

        // <summary>
        // Reload capabilities when orientation changed.
        // </summary>
        // <param name="rc">Return code.</param>
        // <param name="DeviceOrientation">Device orientation.</param>
        // <param name="AppOrientation">Application orientation.</param>
        // <param name="OrientationFlags">Orientation flags.</param>
        void cmp_OrientationChanged(int rc, CMP_ORIENTATION_POSITION DeviceOrientation, CMP_ORIENTATION_POSITION AppOrientation, short OrientationFlags)
        {
            if ((null != cmp) && icaSessionConnected)
            {
                Helpers.Trace("OrientationChanged: rc=0x{0:X}, DeviceOrientation=0x{1:X}, AppOrientation=0x{2:X}, OrientationFlags=0x{3:X}",
                    rc, DeviceOrientation, AppOrientation, OrientationFlags);

                // Reload capabilities so that orientation properties are updated.
                LoadCapabilities();
                propertyGrid1.SelectedObject = deviceCaps;
            }
        }
    }
}
