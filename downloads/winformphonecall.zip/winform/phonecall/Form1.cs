﻿// C# Phone Call example using COM Interop with Citrix Mobility SDK
//
// Uses Citrix Mobility SDK to start a phone call
//
// Copyright (c) 2012 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CitrixMobility;

namespace phonecall
{
    public partial class Form1 : Form
    {
        // <summary>
        // Initialise Phone Call id (unique to this application).
        // </summary>
        private int phoneCallId = 0x22654321;

        // <summary>
        // Phone number to call.
        // </summary>
        private string phoneNumber = string.Empty;

        // <summary>
        // Instance of CitrixMobile.
        // </summary>
        private CitrixMobile cmp = null;

        // <summary>
        // ICA session connected state.
        // </summary>
        private bool icaSessionConnected = false;

        // <summary>
        // Check CMP return code for success.
        // </summary>
        public static bool CMP_SUCCESS(int rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (int)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        // <summary>
        // Dispatch action to UI thread if necessary.
        // </summary>
        // <param name="action">The action.</param>
        private void UiDispatch(Action action)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(action);
            }
            else
            {
                action();
            }
        }

        // <summary>
        // Report CMP status.
        // </summary>
        // <param name="text">Status text.</param>
        // <param name="rc">CMP return code.</param>
        private void ReportStatus(string text, int rc)
        {
            // Only report status if something went wrong.
            if (!CMP_SUCCESS(rc))
            {
                string msg = string.Format("{0}, CMPResult: 0x{1:X}", text, rc);

                // Write to trace output.
                Helpers.Trace(msg);
                // Update status text.
                UiDispatch(() => this.status.Text = msg);
            }
        }

        public Form1()
        {
            InitializeComponent();

            // Initialises CMP framework.
            InitialiseCmp();
        }

        // <summary>
        // Initialise CMP framework.
        // </summary>
        private void InitialiseCmp()
        {
            int rc = (int)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Helpers.Trace("Creating CitrixMobile object");
                // Create an instance of CitrixMobile object.
                cmp = new CitrixMobile();

                Helpers.Trace("Register for ICA session state changed events");
                // Register for ICA session events.
                cmp.SessionStateChanged += new ICMPEvents_SessionStateChangedEventHandler(cmp_SessionStateChanged);

                Helpers.Trace("Calling OpenSession");
                // Open CMP session.
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    icaSessionConnected = true;

                    Helpers.Trace("Register for phone call started events");
        //! [eventsubscription]
        // Register for phone call events.
        cmp.PhoneCallStarted += new ICMPEvents_PhoneCallStartedEventHandler(cmp_PhoneCallStarted);
        //! [eventsubscription]
                }
                else
                {
                    ReportStatus("OpenSession failed", rc);
                }
            }
            catch (System.Exception ex)
            {
                Helpers.Trace(ex.Message);
                Helpers.Trace(ex.StackTrace);
            }
        }

        // <summary>
        // Tear down CMP connection when closed.
        // </summary>
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (null != cmp)
            {
                // Close CMP session.
                cmp.CloseSession();
                cmp = null;
            }
        }

        //! [phonecall]
        // <summary>
        // Make a phone call.
        // </summary>
        // <param name="phoneNumber">The number to call.</param>
        // <param name="phoneCallId">The application unique phone call ID.</param>
        private void MakePhoneCall(string phoneNumber, int phoneCallId)
        {
            // Initiate a phone call on the connected device.
            int rc = cmp.StartPhoneCall(phoneNumber, phoneCallId);
        }
        //! [phonecall]

        // <summary>
        // Session state change handler.
        // </summary>
        // <remarks>Update the ICA session state upon connect/disconnect.</remarks>
        // <param name="SessState">Session state</param>
        void cmp_SessionStateChanged(CMP_SESSION_STATE SessState)
        {
            switch (SessState)
            {
                case CMP_SESSION_STATE.CMP_SESSION_STATE_CONNECTED:
                    icaSessionConnected = true;
                    break;
                case CMP_SESSION_STATE.CMP_SESSION_STATE_DISCONNECTED:
                    icaSessionConnected = false;
                    break;
                default:
                    break;
            }
        }

        //! [eventhandler]
        // <summary>
        // Phone Call Started event handler.
        // </summary>
        // <param name="rc">Return code.</param>
        // <param name="PhoneCallId">Phone call identifier.</param>
        private void cmp_PhoneCallStarted(int rc, int PhoneCallId)
        {
            // Only proceed if call is one of ours.
            if (phoneCallId == PhoneCallId)
            {
                Helpers.Trace("Phone call started. rc:0x{0:X} PhoneCallId:0x{1:X}", rc, PhoneCallId);

                // Indicate that phone call was started.
                UiDispatch(() => this.status.Text = string.Format("Phone call to {0} was started.", phoneNumber));
            }
        }
        //! [eventhandler]
        
        // <summary>
        // Call button event handler.
        // </summary>
        private void callButton_Click(object sender, EventArgs e)
        {
            if ((null != cmp) && icaSessionConnected)
            {
                phoneNumber = numberBox.Text.Trim();

                if (!string.IsNullOrEmpty(phoneNumber))
                {
                    Helpers.Trace("Phone number retrieved");
                    UiDispatch(() => this.status.Text = string.Format("Initiating phone call to {0}...", phoneNumber));

                    // Initiate the phone call process on the connected device.
                    MakePhoneCall(phoneNumber, phoneCallId);
                }
                else
                {
                    // Phone number is required.
                    UiDispatch(() => this.status.Text = string.Format("Phone number must be specified."));
                }
            }
        }
    }
}
