﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using CitrixMobility;

namespace redirectbutton
{
    public partial class Form2 : Form
    {
        private CitrixMobile cmp = null;

        public Form2(CitrixMobile cmpInstance)
        {
            InitializeComponent();

            if (null != cmpInstance)
            {
                cmp = cmpInstance;

        //! [buttonpressed_subscription]
        // Register for button pressed events.
        cmp.ButtonPressed += new ICMPEvents_ButtonPressedEventHandler(cmp_ButtonPressed);
        //! [buttonpressed_subscription]
            }
        }

        // <summary>
        // Close this dialog and go back.
        // </summary>
        private void GoBack()
        {
            if (null != cmp)
            {
                cmp.ButtonPressed -= new ICMPEvents_ButtonPressedEventHandler(cmp_ButtonPressed);
            }
            this.Close();
        }

        //! [buttonpressed_handler]
        // <summary>
        // Device button pressed handler.
        // </summary>
        // <param name="Button">Button ID.</param>
        private void cmp_ButtonPressed(CMP_BUTTON_ID Button)
        {
            Helpers.Trace("_cmp_ButtonPressed: {0:X}", Button);

            if (CMP_BUTTON_ID.CMP_BUTTON_BACK == Button)
            {
                // Go back to previous step if the "Back" button is pressed.
                GoBack();
            }
        }
        //! [buttonpressed_handler]
        
        // <summary>
        // "Go Back" button press handler.
        // </summary>
        private void goBackButton_Click(object sender, EventArgs e)
        {
            GoBack();
        }

        private void Form2_Activated(object sender, EventArgs e)
        {
            if (null != cmp)
            {
        //! [redirect_button]
        // Redirect "Back" button to host (this application).
        int rc = cmp.SetButtonTarget(CitrixMobility.CMP_BUTTON_ID.CMP_BUTTON_BACK, CitrixMobility.CMP_BUTTON_TARGET.CMP_BUTTON_TARGET_HOST);
        //! [redirect_button]

                Helpers.Trace("SetButtonTarget: rc={0:X}", rc);
            }
        }
    }
}
