﻿// C# Redirect button example using COM Interop with Citrix Mobility SDK
//
// Uses Citrix Mobility SDK to redirect button presses.
//
// Copyright (c) 2012 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using CitrixMobility;

namespace redirectbutton
{
    public partial class Form1 : Form
    {
        // <summary>
        // Instance of CitrixMobile.
        // </summary>
        private CitrixMobile cmp = null;

        // <summary>
        // Public accessor to CitrixMobile.
        // </summary>
        public CitrixMobile Cmp
        {
            get { return cmp; }
        }

        // <summary>
        // ICA session connected state.
        // </summary>
        private bool icaSessionConnected = false;

        // <summary>
        // Check CMP return code for success.
        // </summary>
        public static bool CMP_SUCCESS(int rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (int)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        // <summary>
        // Dispatch action to UI thread if necessary.
        // </summary>
        // <param name="action">The action.</param>
        private void UiDispatch(Action action)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(action);
            }
            else
            {
                action();
            }
        }

        // <summary>
        // Report CMP status.
        // </summary>
        // <param name="text">Status text.</param>
        // <param name="rc">CMP return code.</param>
        private void ReportStatus(string text, int rc)
        {
            // Only report status if something went wrong.
            if (!CMP_SUCCESS(rc))
            {
                string msg = string.Format("{0}, CMPResult: 0x{1:X}", text, rc);

                // Write to trace output.
                Helpers.Trace(msg);
                // Update status text.
                UiDispatch(() => this.status.Text = msg);
            }
        }

        public Form1()
        {
            InitializeComponent();

            // Initialises CMP framework.
            InitialiseCmp();
        }

        // <summary>
        // Initialise CMP framework.
        // </summary>
        private void InitialiseCmp()
        {
            int rc = (int)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Helpers.Trace("Creating CitrixMobile object");
                // Create an instance of CitrixMobile object.
                cmp = new CitrixMobile();

                Helpers.Trace("Register for ICA session state changed events");
                // Register for ICA session events.
                cmp.SessionStateChanged += new ICMPEvents_SessionStateChangedEventHandler(cmp_SessionStateChanged);

                Helpers.Trace("Calling OpenSession");
                // Open CMP session.
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    icaSessionConnected = true;

                    bool hasBackButton = false;
                    rc = cmp.GetCapabilityBool(CMP_CAP_ID.CAPID_BUTTON_SET_TARGET, (short)CMP_BUTTON_ID.CMP_BUTTON_BACK, out hasBackButton);

                    // Enable/disable "Next Step..." button.
                    nextStepButton.Enabled = hasBackButton;

                    if (hasBackButton)
                    {
                        Helpers.Trace("Register for button target changed events");
        //! [targetchanged_subscription]
        // Register for button pressed events.
        cmp.ButtonTargetChanged += new ICMPEvents_ButtonTargetChangedEventHandler(cmp_ButtonTargetChanged);
        //! [targetchanged_subscription]
                    }
                    else
                    {
                        UiDispatch(() => this.status.Text = string.Format("Back button is not supported."));
                    }
                }
                else
                {
                    ReportStatus("OpenSession failed", rc);
                }
            }
            catch (System.Exception ex)
            {
                Helpers.Trace(ex.Message);
                Helpers.Trace(ex.StackTrace);
            }
        }

        // <summary>
        // Tear down CMP connection when closed.
        // </summary>
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (null != cmp)
            {
                // Close CMP session.
                cmp.CloseSession();
                cmp = null;
            }
        }

        // <summary>
        // Session state change handler.
        // </summary>
        // <remarks>Update the ICA session state upon connect/disconnect.</remarks>
        // <param name="SessState">Session state</param>
        void cmp_SessionStateChanged(CMP_SESSION_STATE SessState)
        {
            switch (SessState)
            {
                case CMP_SESSION_STATE.CMP_SESSION_STATE_CONNECTED:
                    icaSessionConnected = true;

                    if (null != cmp)
                    {
                        // Redirect "Back" button to host (this application).
                        cmp.SetButtonTarget(CitrixMobility.CMP_BUTTON_ID.CMP_BUTTON_BACK, CitrixMobility.CMP_BUTTON_TARGET.CMP_BUTTON_TARGET_HOST);
                    }
                    break;
                case CMP_SESSION_STATE.CMP_SESSION_STATE_DISCONNECTED:
                    icaSessionConnected = false;
                    break;
                default:
                    break;
            }
        }

        // <summary>
        // Button target changed handler.
        // </summary>
        // <param name="rc">Return code.</param>
        // <param name="Button">Button ID.</param>
        // <param name="ButtonTarget">Button target.</param>
        void cmp_ButtonTargetChanged(int rc, CMP_BUTTON_ID Button, CMP_BUTTON_TARGET ButtonTarget)
        {
            Helpers.Trace("ButtonTargetChanged: rc({0:X}), Button({1:X}), ButtonTarget({2:X})",
                rc, Button, ButtonTarget);
        }

        // <summary>
        // Show the dialog box for the next step.
        // </summary>
        private void nextStepButton_Click(object sender, EventArgs e)
        {
            Form2 nextDialog = new Form2(cmp);
            nextDialog.ShowDialog();
        }

        // <summary>
        // Redirect the device's "Back" button to the host (this application).
        // </summary>
        // <param name="sender"></param>
        // <param name="e"></param>
        private void Form1_Activated(object sender, EventArgs e)
        {
            if ((null != cmp) && icaSessionConnected)
            {
        //! [redirect_button]
        // Redirect "Back" button to host (this application).
        int rc = cmp.SetButtonTarget(CitrixMobility.CMP_BUTTON_ID.CMP_BUTTON_BACK, CitrixMobility.CMP_BUTTON_TARGET.CMP_BUTTON_TARGET_CLIENT);
        //! [redirect_button]

                Helpers.Trace("SetButtonTarget: rc={0:X}", rc);
            }
        }
    }
}
