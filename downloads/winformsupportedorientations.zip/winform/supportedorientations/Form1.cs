﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using CitrixMobility;

namespace supportedorientations
{
    public partial class Form1 : Form
    {
        // <summary>
        // Instance of CitrixMobile.
        // </summary>
        private CitrixMobile cmp = null;

        // <summary>
        // Check CMP return code for success.
        // </summary>
        public static bool CMP_SUCCESS(int rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (int)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        // <summary>
        // Dispatch action to UI thread if necessary.
        // </summary>
        // <param name="action">The action.</param>
        private void UiDispatch(Action action)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(action);
            }
            else
            {
                action();
            }
        }

        // <summary>
        // Display the specified status text.
        // </summary>
        // <param name="statusText">Status text.</param>
        private void UpdateStatus(string statusText)
        {
            UiDispatch(() => status.Text = statusText);
        }

        // <summary>
        // Report CMP status.
        // </summary>
        // <param name="text">Status text.</param>
        // <param name="rc">CMP return code.</param>
        private void ReportStatus(string text, int rc)
        {
            // Only report status if something went wrong.
            if (!CMP_SUCCESS(rc))
            {
                string msg = string.Format("{0}, CMPResult: 0x{1:X}", text, rc);

                // Write to trace output.
                Helpers.Trace(msg);
                // Update status text.
                UpdateStatus(msg);
            }
        }

        public Form1()
        {
            InitializeComponent();
            // Initialises CMP framework.
            InitialiseCmp();
        }

        // <summary>
        // Initialise CMP framework.
        // </summary>
        private void InitialiseCmp()
        {
            int rc = (int)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Helpers.Trace("Creating CitrixMobile object");
                // Create an instance of CitrixMobile object.
                cmp = new CitrixMobile();

                Helpers.Trace("Calling OpenSession");
                // Open CMP session.
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    CMP_SUPPORTED_ORIENTATIONS supportedOrientations;

                    //! [getsupportedorientations]
                    // Gets the current supported orientations of the device
                    rc = cmp.GetSupportedOrientations(out supportedOrientations);
                    //! [getsupportedorientations]

                    if (CMP_SUCCESS(rc))
                    {
                        // If successful, prints information of the current supported orientations of the device
                        Console.WriteLine("GetSupportedOrientations {0}\n", supportedOrientations.ToString());

                        Helpers.Trace("Register for SupportedOrientationsChanged event");
                        //! [eventsubscription]
                        // Register for SupportedOrientationsChanged event.
                        cmp.SupportedOrientationsChanged += new ICMPEvents_SupportedOrientationsChangedEventHandler(cmp_SupportedOrientationsChanged);
                        //! [eventsubscription]
                    }
                    else
                    {
                        string msg = string.Format("GetSupportedOrientations failed rc={0:X}", rc);
                        UpdateStatus(msg);
                        Helpers.Trace(msg);
                    }
                }
                else
                {
                    string msg = string.Format("OpenSession failed rc={0:X}", rc);
                    UpdateStatus(msg);
                    Helpers.Trace(msg);
                }
            }
            catch (System.Exception ex)
            {
                UpdateStatus(ex.Message);
                Helpers.Trace(ex.Message);
                Helpers.Trace(ex.StackTrace);
            }
        }

        //! [eventhandler]
        // <summary>
        // SupportedOrientationsChanged event handler.
        // </summary>
        // <param name="rc">Result code</param>
        // <param name="supportedOrientations">New supported orientations</param>
        void cmp_SupportedOrientationsChanged(int rc, CMP_SUPPORTED_ORIENTATIONS supportedOrientations)
        {
            if (CMP_SUCCESS(rc))
            {
                // If successful, prints information of the current supported orientations of the device
                UpdateStatus(String.Format("SupportedOrientationsChanged event {0}", supportedOrientations.ToString()));
            }
        }
        //! [eventhandler]

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            CMP_SUPPORTED_ORIENTATIONS supportedorientations;
            Enum.TryParse<CMP_SUPPORTED_ORIENTATIONS>(comboBox1.SelectedValue.ToString(), out supportedorientations);

            //! [setsupportedorientations]
            int rc = cmp.SetSupportedOrientations(supportedorientations);
            //! [setsupportedorientations]

            ReportStatus("SetSupportedOrientations", rc);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.DataSource = Enum.GetValues(typeof(CMP_SUPPORTED_ORIENTATIONS));
        }
    }
}
