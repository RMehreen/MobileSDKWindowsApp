﻿// C# Show keyboard example using Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to show a display keyboard
//
// Copyright (c) 2012 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.Linq;
using CitrixMobility;
using System.Threading;

using CMPRESULT = System.Int32;

namespace showkeyboard
{
    class Program
    {

        static CitrixMobile cmp;

        [STAThread]
        static void Main()
        {
            // Initialise result to "No Error"
            CMPRESULT rc = (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Console.WriteLine("Creating CitrixMobile object");

                // Creates the CitrixMobile Object which contains all the CMP interfaces. e.g. IButton, ICamera
                cmp = new CitrixMobile();

                Console.WriteLine("Calling OpenSession");

                // Opens a connection to the remote mobile device
                // It is good practice to close the operation when no longer needed 
                rc = cmp.OpenSession();
                
                if(CMP_SUCCESS(rc))
                {
                    // register for keyboard state changed event
                    RegisterForEvent();

                    rc = ShowKeyboard();

                    // Loop for thirty seconds to allow for events to happen
                    for (int i = 0; i < 30; i++ )
                    {
                        Thread.Sleep(1000);
                    }
                }
                else
                {
                    Console.WriteLine("OpenSession failed rc={0:X}", rc);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }

        //! [eventhandler]
        // <summary>
        // KeyboardStateChanged event handler.
        // </summary>
        // <param name="rc">Return code.</param>
        // <param name="kybdType">Keyboard type.</param>
        // <param name="kybdFlags">Keyboard flags.</param>
        // <param name="kybdAutoCaps">Keyboard auto caps lock.</param>
        // <param name="kybdReturnKey">Keyboard return key</param>
        static void cmp_KeyboardStateChanged(
            CMPRESULT rc,
            CMP_KEYBOARD_TYPE kybdType,
            Int16 kybdFlags,
            CMP_KEYBOARD_AUTOCAPS kybdAutoCaps,
            CMP_KEYBOARD_RETURNKEY kybdReturnKey)
        {
            Console.WriteLine(
                "Keyboard state changed rc({0:X}) " +
                "kbtype({1:X}) flags({2:X}) " +
                "kbReturnKey({3:X}) kbAutoCaps({4:X})",
                rc, kybdType, kybdFlags, kybdAutoCaps, kybdReturnKey);
        }
        //! [eventhandler]

        /// <summary>
        /// Check CMP return code for success.
        /// </summary>
        static bool CMP_SUCCESS(CMPRESULT rc)
        {
            // Need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        /// <summary>
        /// Register for keyboard state changed event
        /// </summary>
        static void RegisterForEvent()
        {
            Console.WriteLine("Hooking keyboard state changed event");

            //! [eventsubscription]
            // Subscribed KeyboardStateChanged event
            cmp.KeyboardStateChanged += new ICMPEvents_KeyboardStateChangedEventHandler(cmp_KeyboardStateChanged);
            //! [eventsubscription]
        }

        /// <summary>
        /// Show the keyboard
        /// </summary>
        static CMPRESULT ShowKeyboard()
        {
            CMPRESULT rc;

            // Creating the object "CMP Keyboard State"
            CMP_KEYBOARD_STATE kybdState = new CMP_KEYBOARD_STATE();

            //! [showkeyboard]
            // Setting the Keyboard Type to the type "Standard"
            kybdState.KybdType = CMP_KEYBOARD_TYPE.CMP_KYBD_TYPE_STANDARD;

            kybdState.KybdFlags = 0;

            // Show the display keyboard, referring to Keyboard State
            rc = cmp.ShowKeyboard(ref kybdState);
            //! [showkeyboard]

            if (CMP_SUCCESS(rc))
            {
                Console.WriteLine("ShowKeyboard success");
            }
            else
            {
                Console.WriteLine("ShowKeyboard failed rc={0:X}", rc);
            }

            return (rc);
        }

    }
}
