﻿//
// C# capabilities example using Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to reveal capabilities
//
// Copyright (c) 2012 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CitrixMobility;
using System.IO;
using System.Diagnostics;
using System.Threading;

using CMPRESULT = System.Int32;

namespace capabilities
{
    class Program
    {
        static public CitrixMobile cmp;
        

        [STAThread]
        static void Main(string[] args)
        {
            // Initialise result to "No Error"
            CMPRESULT rc = (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR;
            
            try
            {
                Console.WriteLine("Creating CitrixMobile object");

                // Creates the CitrixMobile Object which contains all the CMP interfaces. e.g. IButton, ICamera
                cmp = new CitrixMobile();

                Console.WriteLine("Calling OpenSession");

                // Opens a connection to the remote mobile device
                // It is good practice to close the operation when no longer needed 
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    // Gets and displays the device's capabilities 
                    GetCapabilities();
                }
                else
                {
                    Console.WriteLine("OpenSession failed rc={0:X}", rc);
                }

                // Sleep for ten seconds to allow for the results to be read
                Thread.Sleep(10000);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }

        // <summary>
        // Load the current device capabilities into the DeviceCapabilities object.
        // </summary>
        static void GetCapabilities()
        {
            try
            {
                // Get and report CAPID_INPUT capabilities.
                GetInputCaps();

                // Get CAPID_ORIENTATION capabilities.
                GetOrientationCaps();

                // Get CAPID_DISPLAY_INFO capabilities.
                GetDisplayCaps();

                // Get CAPID_SCROLL_MODES capabilities.
                GetScrollModeCaps();

                // Get CAPID_BUTTON_SET_TARGET capabilities.
                GetButtonCaps();

                // Get CMP_CAP_TAKE_PICTURE_KEY_ID capabilities.
                GetPictureCaps();

                // Get CMP_CAP_DEVICE_KEY_ID capabilities.
                GetDeviceCaps();

                // Get CMP_CAP_VIEWPORT_KEY_ID capabilities.
                GetViewportCaps();

                // Get CMP_CAP_DYNAMIC_DISPLAY_KEY_ID capabilities.
                GetDynamicDisplayCaps();

                // Get CMP_CAP_PICKER_CONTROL_KEY_ID capabilities.
                GetPickerCaps();

                // Get CMP_CAP_PHONE_CALL_KEY_ID capabilities.
                GetPhoneCaps();

                // Get CMP_CAP_SMS_KEY_ID capabilities.
                GetSMSCaps();

                // Get CMP_CAP_NOTIFICATION_KEY_ID capabilities.
                GetNotificationCaps();

                // Get CMP_CAP_RECEIVER_CONTROLS_KEY_ID capabilities.
                GetReceiverControlsCaps();

                // Get CMP_CAP_EVENT_FILTER_KEY_ID capabilities.
                GetEventFilterCaps();
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }

        // <summary>
        // Get input related capabilities.
        // </summary>
        static void GetInputCaps()
        {
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_ENABLE, "CAP_INPUT_ENABLE =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_KYBD, "CAP_INPUT_KYBD =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_PHYSICAL_KYBD, "CAP_INPUT_PHYSICAL_KYBD =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_TRACKBALL, "CAP_INPUT_TRACKBALL =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_MOUSE, "CAP_INPUT_MOUSE =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_STD_KYBD, "CAP_INPUT_STD_KYBD =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_NUMPAD_KYBD, "CAP_INPUT_NUMPAD_KYBD =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_PHONEPAD_KYBD, "CAP_INPUT_PHONEPAD_KYBD =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_URL_KYBD, "CAP_INPUT_URL_KYBD =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_EMAIL_KYBD, "CAP_INPUT_EMAIL_KYBD =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_PHONE_NAME_KYBD, "CAP_INPUT_PHONE_NAME_KYBD =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_NUMBERS_PUNC_KYBD, "CAP_INPUT_NUMBERS_PUNC_KYBD =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_DECIMAL_POINT_KYBD, "CAP_INPUT_DECIMAL_POINT_KYBD =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_HIDE, "CAP_INPUT_HIDE =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_AUTO_CORRECT, "CAP_INPUT_AUTO_CORRECT =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_AUTO_CAPITALIZATION, "CAP_INPUT_AUTO_CAPITALIZATION =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_AUTO_CAPITAL_WORD, "CAP_INPUT_AUTO_CAPITAL_WORD =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_AUTO_CAPITAL_SENTENCE, "CAP_INPUT_AUTO_CAPITAL_SENTENCE =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_AUTO_CAPITAL_LETTERS, "CAP_INPUT_AUTO_CAPITAL_LETTERS =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_DEFAULT, "CAP_INPUT_RETURN_KEY_DEFAULT =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_GO, "CAP_INPUT_RETURN_KEY_GO =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_GOOGLE, "CAP_INPUT_RETURN_KEY_GOOGLE =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_JOIN, "CAP_INPUT_RETURN_KEY_JOIN =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_NEXT, "CAP_INPUT_RETURN_KEY_NEXT =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_ROUTE, "CAP_INPUT_RETURN_KEY_ROUTE =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_SEARCH, "CAP_INPUT_RETURN_KEY_SEARCH =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_SEND, "CAP_INPUT_RETURN_KEY_SEND =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY_DONE, "CAP_INPUT_RETURN_KEY_DONE =");
            GetInputCapBool(CMP_CAP_INPUT_KEY_ID.CAP_INPUT_RETURN_KEY, "CAP_INPUT_RETURN_KEY =");
        }

        // <summary>
        // Get orientation related capabilities.
        // </summary>
        static void GetOrientationCaps()
        {
            GetOrientationCapBool(CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_ENABLE, "CAP_ORIENTATION_ENABLE =");
            GetOrientationCapBool(CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_DEVICE, "CAP_ORIENTATION_DEVICE =");
            GetOrientationCapBool(CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_APPLICATION, "CAP_ORIENTATION_APPLICATION =");
            GetOrientationCapBool(CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_PORTRAIT, "CAP_ORIENTATION_PORTRAIT =");
            GetOrientationCapBool(CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_PORTRAIT_DOWN, "CAP_ORIENTATION_PORTRAIT_DOWN =");
            GetOrientationCapBool(CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_LANDSCAPE_LEFT, "CAP_ORIENTATION_LANDSCAPE_LEFT =");
            GetOrientationCapBool(CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_LANDSCAPE_RIGHT, "CAP_ORIENTATION_LANDSCAPE_RIGHT =");
            GetOrientationCapBool(CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_LOCK_UNLOCK, "CAP_ORIENTATION_LOCK_UNLOCK =");
            GetOrientationCapBool(CMP_CAP_ORIENTATION_KEY_ID.CAP_ORIENTATION_FOLLOW_SENSOR, "CAP_ORIENTATION_FOLLOW_SENSOR =");
        }

        // <summary>
        // Get display related capabilities.
        // </summary>
        static void GetDisplayCaps()
        {
            GetDisplayCapBool(CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_ENABLE, "CAP_DISPLAY_ENABLE =");
            GetDisplayCapBool(CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_RESOLUTION_FLAG, "CAP_DISPLAY_RESOLUTION_FLAG =");
            GetDisplayCapBool(CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_COLOR_FLAG, "CAP_DISPLAY_COLOR_FLAG =");
            GetDisplayCapBool(CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_PHYSICAL_FLAG, "CAP_DISPLAY_PHYSICAL_FLAG =");
            GetDisplayCapBool(CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_PPI_FLAG, "CAP_DISPLAY_PPI_FLAG =");
            GetDisplayCapBool(CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_PPI_X_Y_FLAG, "CAP_DISPLAY_PPI_X_Y_FLAG =");
            GetDisplayCapBool(CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_ORIENTATION_FLAG, "CAP_DISPLAY_ORIENTATION_FLAG =");

            GetDisplayCapInt32(CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_METRICS, "CAP_DISPLAY_METRICS =");
            GetDisplayCapInt32(CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_WIDTH, "CAP_DISPLAY_WIDTH =");
            GetDisplayCapInt32(CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_HEIGHT, "CAP_DISPLAY_HEIGHT =");
            GetDisplayCapInt32(CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_X_MILLI_INCHES, "CAP_DISPLAY_X_MILLI_INCHES =");
            GetDisplayCapInt32(CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_Y_MILLI_INCHES, "CAP_DISPLAY_Y_MILLI_INCHES =");
            GetDisplayCapInt32(CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_PIXELS_PER_INCH, "CAP_DISPLAY_PIXELS_PER_INCH =");
            GetDisplayCapInt32(CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_X_PIXELS_PER_INCH, "CAP_DISPLAY_X_PIXELS_PER_INCH =");
            GetDisplayCapInt32(CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_Y_PIXELS_PER_INCH, "CAP_DISPLAY_Y_PIXELS_PER_INCH =");
            GetDisplayCapInt16(CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_INITIAL_ORIENTATION, "CAP_DISPLAY_INITIAL_ORIENTATION =");
            GetDisplayCapInt16(CMP_CAP_DISPLAY_KEY_ID.CAP_DISPLAY_COLOR_DEPTH, "CAP_DISPLAY_COLOR_DEPTH =");
        }

        // <summary>
        // Get scroll mode related capabilities.
        // </summary>
        static void GetScrollModeCaps()
        {
            GetScrollModeCapBool(CMP_CAP_SCROLLMODES_KEY_ID.CAP_SCROLLMODES_ENABLE, "CAP_SCROLLMODES_ENABLE =");
            GetScrollModeCapBool(CMP_CAP_SCROLLMODES_KEY_ID.CAP_SCROLLMODES_MOUSEWHEEL_FLAG, "CAP_SCROLLMODES_MOUSEWHEEL_FLAG =");
            GetScrollModeCapBool(CMP_CAP_SCROLLMODES_KEY_ID.CAP_SCROLLMODES_DRAG_FLAG, "CAP_SCROLLMODES_DRAG_FLAG =");
            GetScrollModeCapBool(CMP_CAP_SCROLLMODES_KEY_ID.CAP_SCROLLMODES_PAN_FLAG, "CAP_SCROLLMODES_PAN_FLAG =");
            GetScrollModeCapBool(CMP_CAP_SCROLLMODES_KEY_ID.CAP_SCROLLMODES_DEFAULT_MODE, "CAP_SCROLLMODES_DEFAULT_MODE =");
        }

        // <summary>
        // Get button related capabilities.
        // </summary>
        static void GetButtonCaps()
        {
            GetButtonCapBool(CMP_CAP_BUTTON_KEY_ID.CAP_BUTTON_ENABLE, "CAP_BUTTON_ENABLE =");
            GetButtonCapBool(CMP_CAP_BUTTON_KEY_ID.CAP_BUTTON_BACK, "CAP_BUTTON_BACK =");
            GetButtonCapBool(CMP_CAP_BUTTON_KEY_ID.CAP_BUTTON_SEARCH, "CAP_BUTTON_SEARCH =");
            GetButtonCapBool(CMP_CAP_BUTTON_KEY_ID.CAP_BUTTON_HOME, "CAP_BUTTON_HOME =");
            GetButtonCapBool(CMP_CAP_BUTTON_KEY_ID.CAP_BUTTON_MENU, "CAP_BUTTON_MENU =");
            GetButtonCapInt16(CMP_CAP_BUTTON_KEY_ID.CAP_BUTTON_MASK, "CAP_BUTTON_MASK =");
        }

        // <summary>
        // Get take picture related capabilities.
        // </summary>
        static void GetPictureCaps()
        {
            GetPictureCapBool(CMP_CAP_TAKE_PICTURE_KEY_ID.CAP_TAKE_PICTURE_ENABLE, "CAP_TAKE_PICTURE_ENABLE =");
            GetPictureCapBool(CMP_CAP_TAKE_PICTURE_KEY_ID.CAP_TAKE_PICTURE_JPEG, "CAP_TAKE_PICTURE_JPEG =");
            GetPictureCapBool(CMP_CAP_TAKE_PICTURE_KEY_ID.CAP_TAKE_PICTURE_PNG, "CAP_TAKE_PICTURE_PNG =");
        }

        // <summary>
        // Get device related information.
        // </summary>
        static void GetDeviceCaps()
        {
            GetDeviceCapBool(CMP_CAP_DEVICE_KEY_ID.CAP_DEVICE_ENABLE, "CAP_DEVICE_ENABLE =");
            GetDeviceCapInt16(CMP_CAP_DEVICE_KEY_ID.CAP_DEVICE_OS, "CAP_DEVICE_OS =");
            GetDeviceCapInt16(CMP_CAP_DEVICE_KEY_ID.CAP_DEVICE_OS_VER_HIGH, "CAP_DEVICE_OS_VER_HIGH =");
            GetDeviceCapInt16(CMP_CAP_DEVICE_KEY_ID.CAP_DEVICE_OS_VER_LOW, "CAP_DEVICE_OS_VER_LOW =");
            GetDeviceCapInt16(CMP_CAP_DEVICE_KEY_ID.CAP_DEVICE_OS_VER_MINOR, "CAP_DEVICE_OS_VER_MINOR =");
            GetDeviceCapInt16(CMP_CAP_DEVICE_KEY_ID.CAP_DEVICE_OS_VER_BUILD, "CAP_DEVICE_OS_VER_BUILD =");
            GetDeviceCapInt16(CMP_CAP_DEVICE_KEY_ID.CAP_DEVICE_TYPE, "CAP_DEVICE_TYPE =");
        }

        // <summary>
        // Get viewport related capabilities.
        // </summary>
        static void GetViewportCaps()
        {
            GetViewportCapBool(CMP_CAP_VIEWPORT_KEY_ID.CAP_VIEWPORT_ENABLE, "CAP_VIEWPORT_ENABLE =");
        }

        // <summary>
        // Get dynamic display related capabilities.
        // </summary>
        static void GetDynamicDisplayCaps()
        {
            GetDynamicDisplayCapBool(CMP_CAP_DYNAMIC_DISPLAY_KEY_ID.CAP_DYNAMIC_DISPLAY_ENABLE, "CAP_DYNAMIC_DISPLAY_ENABLE =");
        }

        /// <summary>
        /// Get Picker related capabilities.
        /// </summary>
        static void GetPickerCaps()
        {
            GetPickerCapBool(CMP_CAP_PICKER_CONTROL_KEY_ID.CAP_PICKER_CONTROL_ENABLE, "CAP_PICKER_CONTROL_ENABLE =");
            GetPickerCapBool(CMP_CAP_PICKER_CONTROL_KEY_ID.CAP_PICKER_CONTROL_TITLE_FLAG, "CAP_PICKER_CONTROL_TITLE_FLAG =");
        }

        // <summary>
        // Get phone related capabilities.
        // </summary>
        static void GetPhoneCaps()
        {
            GetPhoneCapBool(CMP_CAP_PHONE_CALL_KEY_ID.CAP_PHONE_CALL_ENABLE, "CAP_PHONE_CALL_ENABLE =");
        }

        // <summary>
        // Get SMS related capabilities.
        // </summary>
        static void GetSMSCaps()
        {
            GetSMSCapBool(CMP_CAP_SMS_KEY_ID.CAP_SMS_ENABLE, "CAP_SMS_ENABLE =");
        }

        // <summary>
        // Get notification related capabilities.
        // </summary>
        static void GetNotificationCaps()
        {
            GetNotificationCapBool(CMP_CAP_NOTIFICATION_KEY_ID.CAP_NOTIFICATION_ENABLE, "CAP_NOTIFICATION_ENABLE =");
            GetNotificationCapBool(CMP_CAP_NOTIFICATION_KEY_ID.CAP_NOTIFICATION_LIGHT, "CAP_NOTIFICATION_LIGHT =");
            GetNotificationCapBool(CMP_CAP_NOTIFICATION_KEY_ID.CAP_NOTIFICATION_VIBRATE, "CAP_NOTIFICATION_VIBRATE =");
            GetNotificationCapBool(CMP_CAP_NOTIFICATION_KEY_ID.CAP_NOTIFICATION_AUDIO, "CAP_NOTIFICATION_AUDIO =");
            GetNotificationCapBool(CMP_CAP_NOTIFICATION_KEY_ID.CAP_NOTIFICATION_TEXT, "CAP_NOTIFICATION_TEXT =");
        }

        // <summary>
        // Get Receiver control related capabilities.
        // </summary>
        static void GetReceiverControlsCaps()
        {
            GetReceiverControlsCapBool(CMP_CAP_RECEIVER_CONTROLS_KEY_ID.CAP_RECEIVER_CONTROLS_ENABLE, "CAP_RECEIVER_CONTROLS_ENABLE =");
            GetReceiverControlsCapBool(CMP_CAP_RECEIVER_CONTROLS_KEY_ID.CAP_RECEIVER_CONTROLS_DISABLE, "CAP_RECEIVER_CONTROLS_DISABLE =");
        }

        // <summary>
        // Get event filter related capabilities.
        // </summary>
        static void GetEventFilterCaps()
        {
            GetEventFilterCapBool(CMP_CAP_EVENT_FILTER_KEY_ID.CAP_EVENT_FILTER_ENABLE, "CAP_EVENT_FILTER_ENABLE =");
            GetEventFilterCapBool(CMP_CAP_EVENT_FILTER_KEY_ID.CAP_EVENT_FILTER_SUPPORT, "CAP_EVENT_FILTER_SUPPORT =");
        }

        //
        // Checks if there is an error
        //
        static bool CMP_SUCCESS(CMPRESULT rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        static CMPRESULT GetInputCapBool(CMP_CAP_INPUT_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapBool(CMP_CAP_ID.CAPID_INPUT, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetOrientationCapBool(CMP_CAP_ORIENTATION_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapBool(CMP_CAP_ID.CAPID_ORIENTATION, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetDisplayCapBool(CMP_CAP_DISPLAY_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapBool(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetDisplayCapInt32(CMP_CAP_DISPLAY_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapInt32(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetDisplayCapInt16(CMP_CAP_DISPLAY_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapInt16(CMP_CAP_ID.CAPID_DISPLAY_INFO, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetScrollModeCapBool(CMP_CAP_SCROLLMODES_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapBool(CMP_CAP_ID.CAPID_SCROLL_MODES, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetButtonCapBool(CMP_CAP_BUTTON_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapBool(CMP_CAP_ID.CAPID_BUTTON_SET_TARGET, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetButtonCapInt16(CMP_CAP_BUTTON_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapInt16(CMP_CAP_ID.CAPID_BUTTON_SET_TARGET, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetPictureCapBool(CMP_CAP_TAKE_PICTURE_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapBool(CMP_CAP_ID.CAPID_TAKE_PICTURE, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetDeviceCapBool(CMP_CAP_DEVICE_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapBool(CMP_CAP_ID.CAPID_DEVICE_INFO, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetDeviceCapInt16(CMP_CAP_DEVICE_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapInt16(CMP_CAP_ID.CAPID_DEVICE_INFO, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetViewportCapBool(CMP_CAP_VIEWPORT_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapBool(CMP_CAP_ID.CAPID_VIEWPORT, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetDynamicDisplayCapBool(CMP_CAP_DYNAMIC_DISPLAY_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapBool(CMP_CAP_ID.CAPID_DYNAMIC_DISPLAY, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetPickerCapBool(CMP_CAP_PICKER_CONTROL_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapBool(CMP_CAP_ID.CAPID_PICKER_CONTROL, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetPhoneCapBool(CMP_CAP_PHONE_CALL_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapBool(CMP_CAP_ID.CAPID_PHONE_CALL, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetSMSCapBool(CMP_CAP_SMS_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapBool(CMP_CAP_ID.CAPID_SMS, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetNotificationCapBool(CMP_CAP_NOTIFICATION_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapBool(CMP_CAP_ID.CAPID_NOTIFICATION, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetReceiverControlsCapBool(CMP_CAP_RECEIVER_CONTROLS_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapBool(CMP_CAP_ID.CAPID_RECEIVER_CONTROLS, (short)keyId, prefixOutput));
        }

        static CMPRESULT GetEventFilterCapBool(CMP_CAP_EVENT_FILTER_KEY_ID keyId, string prefixOutput)
        {
            return (GetCapBool(CMP_CAP_ID.CAPID_EVENT_FILTER, (short)keyId, prefixOutput));
        }

        //! [GetCapValue]
        // <summary>
        // Display bool capability value.
        // </summary>
        // <param name="capId">Capability ID.</param>
        // <param name="keyId">Capabiluty Key ID.</param>
        // <param name="prefixOutput">Display prefix.</param>
        // <returns>CMPRESULT return code.</returns>
        static CMPRESULT GetCapBool(CMP_CAP_ID capId, short keyId, string prefixOutput)
        {
            CMPRESULT rc;
            bool keyValue;

            rc = cmp.GetCapabilityBool(capId, keyId, out keyValue);

            if (CMP_SUCCESS(rc))
            {
                Console.WriteLine("{0} {1}", prefixOutput, keyValue);
            }
            else
            {
                Console.WriteLine("{0} Error({1:X})", prefixOutput, rc);
            }

            return (rc);
        }

        // <summary>
        // Display Int16 capability value.
        // </summary>
        // <param name="capId">Capability ID.</param>
        // <param name="keyId">Capabiluty Key ID.</param>
        // <param name="prefixOutput">Display prefix.</param>
        // <returns>CMPRESULT return code.</returns>
        static CMPRESULT GetCapInt16(CMP_CAP_ID capId, short keyId, string prefixOutput)
        {
            CMPRESULT rc;
            Int16 keyValue;

            rc = cmp.GetCapabilityInt16(capId, keyId, out keyValue);

            if (CMP_SUCCESS(rc))
            {
                Console.WriteLine("{0} {1}", prefixOutput, keyValue);
            }
            else
            {
                Console.WriteLine("{0} Error({1:X})", prefixOutput, rc);
            }

            return (rc);
        }

        // <summary>
        // Display Int32 capability value.
        // </summary>
        // <param name="capId">Capability ID.</param>
        // <param name="keyId">Capabiluty Key ID.</param>
        // <param name="prefixOutput">Display prefix.</param>
        // <returns>CMPRESULT return code.</returns>
        static CMPRESULT GetCapInt32(CMP_CAP_ID capId, short keyId, string prefixOutput)
        {
            CMPRESULT rc;
            Int32 keyValue;

            rc = cmp.GetCapabilityInt32(capId, keyId, out keyValue);

            if (CMP_SUCCESS(rc))
            {
                Console.WriteLine("{0} {1}", prefixOutput, keyValue);
            }
            else
            {
                Console.WriteLine("{0} Error({1:X})", prefixOutput, rc);
            }

            return (rc);
        }
        //! [GetCapValue]
    }

}
