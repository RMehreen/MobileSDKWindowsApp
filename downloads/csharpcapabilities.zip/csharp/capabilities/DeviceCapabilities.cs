﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace capabilities
{
    public enum CMP_CAP_INPUT_KEY_ID
    {
        CAP_INPUT_ENABLE = 0,                               /*!< Bool - capability is enabled                         */
        CAP_INPUT_KYBD = 1,                                 /*!< Bool - supports display keyboard                     */
        CAP_INPUT_PHYSICAL_KYBD = 2,                        /*!< Bool - supports physical keyboard                    */
        CAP_INPUT_TRACKBALL = 3,                            /*!< Bool - supports trackball                            */
        CAP_INPUT_MOUSE = 4,                                /*!< Bool - supports mouse                                */
        CAP_INPUT_STD_KYBD = 5,                             /*!< Bool - supports standard display keyboard            */
        CAP_INPUT_NUMPAD_KYBD = 6,                          /*!< Bool - supports number pad display keyboard          */
        CAP_INPUT_PHONEPAD_KYBD = 7,                        /*!< Bool - supports phone pad display keyboard           */
        CAP_INPUT_URL_KYBD = 8,                             /*!< Bool - supports phone pad display keyboard           */
        CAP_INPUT_EMAIL_KYBD = 9,                           /*!< Bool - supports email display keyboard               */
        CAP_INPUT_PHONE_NAME_KYBD = 10,                     /*!< Bool - supports phone name keyboard                  */
        CAP_INPUT_NUMBERS_PUNC_KYBD = 11,                   /*!< Bool - supports numbers and punctuation keyboard     */
        CAP_INPUT_DECIMAL_POINT_KYBD = 12,                  /*!< Bool - supports number pad with decimal point        */
        CAP_INPUT_HIDE = 13,                                /*!< Bool - supports hide/show display keyboard           */
        CAP_INPUT_AUTO_CORRECT = 14,                        /*!< Bool - supports keyboard auto correction             */
        CAP_INPUT_AUTO_CAPITALIZATION = 15,                 /*!< Bool - supports keyboard auto capitalization         */
        CAP_INPUT_AUTO_CAPITAL_WORD = 16,                   /*!< Bool - supports keyboard auto capitalization - word  */
        CAP_INPUT_AUTO_CAPITAL_SENTENCE = 17,               /*!< Bool - supports keyboard auto capitalization - sentence*/
        CAP_INPUT_AUTO_CAPITAL_LETTERS = 18,                /*!< Bool - supports keyboard auto capitalization - letters*/
        CAP_INPUT_RETURN_KEY_DEFAULT = 19,                  /*!< Bool - supports return key text default "return"     */
        CAP_INPUT_RETURN_KEY_GO = 20,                       /*!< Bool - supports return key text "go"                 */
        CAP_INPUT_RETURN_KEY_GOOGLE = 21,                   /*!< Bool - supports return key text "Google"             */
        CAP_INPUT_RETURN_KEY_JOIN = 22,                     /*!< Bool - supports return key text "Join"               */
        CAP_INPUT_RETURN_KEY_NEXT = 23,                     /*!< Bool - supports return key text "Next"               */
        CAP_INPUT_RETURN_KEY_ROUTE = 24,                    /*!< Bool - supports return key text "Route"              */
        CAP_INPUT_RETURN_KEY_SEARCH = 25,                   /*!< Bool - supports return key text "Search"             */
        CAP_INPUT_RETURN_KEY_SEND = 26,                     /*!< Bool - supports return key text "Send"               */
        CAP_INPUT_RETURN_KEY_DONE = 27,                     /*!< Bool - supports return key text "Done"               */
        CAP_INPUT_RETURN_KEY = 28                           /*!< Bool - supports return key changes                   */
    };

    public enum CMP_CAP_ORIENTATION_KEY_ID
    {
        CAP_ORIENTATION_ENABLE = 0,                         /*!< Bool - capability is enabled         */
        CAP_ORIENTATION_DEVICE = 1,                         /*!< Bool */
        CAP_ORIENTATION_APPLICATION = 2,                    /*!< Bool */
        CAP_ORIENTATION_PORTRAIT = 3,                       /*!< Bool */
        CAP_ORIENTATION_PORTRAIT_DOWN = 4,                  /*!< Bool */
        CAP_ORIENTATION_LANDSCAPE_LEFT = 5,                 /*!< Bool */
        CAP_ORIENTATION_LANDSCAPE_RIGHT = 6,                /*!< Bool */
        CAP_ORIENTATION_LOCK_UNLOCK = 9,                    /*!< Bool */
        CAP_ORIENTATION_FOLLOW_SENSOR = 10                  /*!< Bool */
    };

    public enum CMP_CAP_DISPLAY_KEY_ID
    {
        CAP_DISPLAY_ENABLE = 0,                             /*!< Bool - capability is enabled                 */
        CAP_DISPLAY_RESOLUTION_FLAG = 1,                    /*!< Bool - resolution for x and y valid          */
        CAP_DISPLAY_COLOR_FLAG = 2,                         /*!< Bool - color depth valid                     */
        CAP_DISPLAY_PHYSICAL_FLAG = 3,                      /*!< Bool - physical dimensions for x and y valid */
        CAP_DISPLAY_PPI_FLAG = 4,                           /*!< Bool - points per inch valid                 */
        CAP_DISPLAY_PPI_X_Y_FLAG = 5,                       /*!< Bool - points per inch valid for x and y     */
        CAP_DISPLAY_ORIENTATION_FLAG = 6,                   /*!< Bool - orientation data valid                */
        CAP_DISPLAY_METRICS = 7,                            /*!< UINT16 - all metrics flags in one group      */
        CAP_DISPLAY_WIDTH = 8,                              /*!< UINT32 - width in pixels                     */
        CAP_DISPLAY_HEIGHT = 9,                             /*!< UINT32 - height in pixels                    */
        CAP_DISPLAY_X_MILLI_INCHES = 10,                    /*!< UINT32 - width in milliinches                */
        CAP_DISPLAY_Y_MILLI_INCHES = 11,                    /*!< UINT32 - height in milliinches               */
        CAP_DISPLAY_PIXELS_PER_INCH = 12,                   /*!< UINT32 - pixels per inch                     */
        CAP_DISPLAY_X_PIXELS_PER_INCH = 13,                 /*!< UINT32 - horizontal pixels per inch          */
        CAP_DISPLAY_Y_PIXELS_PER_INCH = 14,                 /*!< UINT32 - vertical pixels per inch            */
        CAP_DISPLAY_INITIAL_ORIENTATION = 15,               /*!< UINT16 - initial orientation position        */
        CAP_DISPLAY_COLOR_DEPTH = 16,                       /*!< UINT16 - color depth (color bits per pixel)  */
    };

    public enum CMP_CAP_SCROLLMODES_KEY_ID
    {
        CAP_SCROLLMODES_ENABLE = 0,                         /*!< Bool - capability is enabled             */
        CAP_SCROLLMODES_MOUSEWHEEL_FLAG = 1,                /*!< Bool - mouse wheel emulation supported   */
        CAP_SCROLLMODES_DRAG_FLAG = 2,                      /*!< Bool - drag mode supported               */
        CAP_SCROLLMODES_PAN_FLAG = 3,                       /*!< Bool - pan mode supported                */
        CAP_SCROLLMODES_DEFAULT_MODE = 4                    /*!< UINT16 - default scroll mode             */
    };

    public enum CMP_CAP_BUTTON_KEY_ID
    {
        CAP_BUTTON_ENABLE = 0,                              /*!< Bool - capability is enabled       */
        CAP_BUTTON_BACK = 1,                                /*!< Bool - back button supported       */
        CAP_BUTTON_SEARCH = 2,                              /*!< Bool - search button supported     */
        CAP_BUTTON_HOME = 3,                                /*!< Bool - home button supported       */
        CAP_BUTTON_MENU = 4,                                /*!< Bool - menu button supported       */
        CAP_BUTTON_MASK = 5                                 /*!< UInt - button mask value           */
    };

    public enum CMP_CAP_TAKE_PICTURE_KEY_ID
    {
        CAP_TAKE_PICTURE_ENABLE = 0,                        /*!< Bool - capability is enabled  */
        CAP_TAKE_PICTURE_JPEG = 1,                          /*!< Bool - camera supports JPEG   */
        CAP_TAKE_PICTURE_PNG = 2,                           /*!< Bool - camera supports PNG    */
    };

    public enum CMP_CAP_DEVICE_KEY_ID
    {
        CAP_DEVICE_ENABLE = 0,                              /*!< Bool - capability is enabled         */
        CAP_DEVICE_OS = 1,                                  /*!< UINT16 - device operating system     */
        CAP_DEVICE_OS_VER_HIGH = 2,                         /*!< UINT16 - os version high version     */
        CAP_DEVICE_OS_VER_LOW = 3,                          /*!< UINT16 - os version low version      */
        CAP_DEVICE_OS_VER_MINOR = 4,                        /*!< UINT16 - os version minor version    */
        CAP_DEVICE_OS_VER_BUILD = 5,                        /*!< UINT16 - os version build version    */
        CAP_DEVICE_TYPE = 6,                                /*!< UINT16 - device type                 */
    };

    public enum CMP_CAP_VIEWPORT_KEY_ID
    {
        CAP_VIEWPORT_ENABLE = 0,                            /*!< Bool - capability is enabled    */
    };

    public enum CMP_CAP_DYNAMIC_DISPLAY_KEY_ID
    {
        CAP_DYNAMIC_DISPLAY_ENABLE = 0,                     /*!< Bool - capability is enabled */
    };

    public enum CMP_CAP_PICKER_CONTROL_KEY_ID
    {
        CAP_PICKER_CONTROL_ENABLE = 0,                      /*!< Bool - capability is enabled      */
        CAP_PICKER_CONTROL_TITLE_FLAG = 1,                  /*!< Bool - picker title is supported  */
    };

    public enum CMP_CAP_PHONE_CALL_KEY_ID
    {
        CAP_PHONE_CALL_ENABLE = 0,                          /*!< Bool - capability is enabled  */
    };

    public enum CMP_CAP_SMS_KEY_ID
    {
        CAP_SMS_ENABLE = 0,                                 /*!< Bool - capability is enabled */
    };

    public enum CMP_CAP_NOTIFICATION_KEY_ID
    {
        CAP_NOTIFICATION_ENABLE = 0,                        /*!< Bool - capability is enabled             */
        CAP_NOTIFICATION_LIGHT = 1,                         /*!< Bool - supports light notification       */
        CAP_NOTIFICATION_VIBRATE = 2,                       /*!< Bool - supports vibration                */
        CAP_NOTIFICATION_AUDIO = 3,                         /*!< Bool - supports audio notification       */
        CAP_NOTIFICATION_TEXT = 4,                          /*!< Bool - supports text notification        */
    };

    public enum CMP_CAP_RECEIVER_CONTROLS_KEY_ID
    {
        CAP_RECEIVER_CONTROLS_ENABLE = 0,                   /*!< Bool - capability is enabled                         */
        CAP_RECEIVER_CONTROLS_DISABLE = 1,                  /*!< Bool - receiver supports Enable/disable of controls  */
    };

    public enum CMP_CAP_EVENT_FILTER_KEY_ID
    {
        CAP_EVENT_FILTER_ENABLE = 0,                        /*!< Bool - capability is enabled                 */
        CAP_EVENT_FILTER_SUPPORT = 1,                       /*!< Bool - supports Enable/disable of events     */
    };

    internal class DeviceCapabilities
    {
        // CMP_CAP_INPUT_KEY_ID
        [Description("CAP_INPUT_ENABLE indicates whether the CMP_CAP_INPUT_KEY_ID category is available."), Category("CMP_CAP_INPUT_KEY_ID")] 
        public bool CAP_INPUT_ENABLE { get; set; }

        [Description("Supports on-screen keyboard."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_KYBD { get; set; }

        [Description("Supports physical keyboard."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_PHYSICAL_KYBD { get; set; }

        [Description("Supports trackball."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_TRACKBALL { get; set; }

        [Description("Supports mouse."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_MOUSE { get; set; }

        [Description("Supports standard on-screen keyboard."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_STD_KYBD { get; set; }

        [Description("Supports number pad on-screen keyboard."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_NUMPAD_KYBD { get; set; }

        [Description("Supports phone pad on-screen keyboard."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_PHONEPAD_KYBD { get; set; }

        [Description("Supports URL on-screen keyboard."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_URL_KYBD { get; set; }

        [Description("Supports email on-screen keyboard."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_EMAIL_KYBD { get; set; }

        [Description("Supports phone name on-screen keyboard."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_PHONE_NAME_KYBD { get; set; }

        [Description("Supports number and punctuation on-screen keyboard."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_NUMBERS_PUNC_KYBD { get; set; }

        [Description("Supports number pad with decimal point on-screen keyboard."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_DECIMAL_POINT_KYBD { get; set; }

        [Description("Support hide/show on-screen keyboard."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_HIDE { get; set; }

        [Description("Supports keyboard auto correction."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_AUTO_CORRECT { get; set; }

        [Description("Supports keyboard auto capitalization."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_AUTO_CAPITALIZATION { get; set; }

        [Description("Supports keyboard auto capitalization of word."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_AUTO_CAPITAL_WORD { get; set; }

        [Description("Supports keyboard auto capitalization of sentence."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_AUTO_CAPITAL_SENTENCE { get; set; }

        [Description("Supports keyboard auto capitalization of letters."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_AUTO_CAPITAL_LETTERS { get; set; }

        [Description("Supports return key text default \"return\"."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_RETURN_KEY_DEFAULT { get; set; }

        [Description("Supports return key text \"Go\"."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_RETURN_KEY_GO { get; set; }

        [Description("Supports return key text \"Google\"."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_RETURN_KEY_GOOGLE { get; set; }

        [Description("Supports return key text \"Join\"."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_RETURN_KEY_JOIN { get; set; }

        [Description("Supports return key text \"Next\"."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_RETURN_KEY_NEXT { get; set; }

        [Description("Supports return key text \"Route\"."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_RETURN_KEY_ROUTE { get; set; }

        [Description("Supports return key text \"Search\"."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_RETURN_KEY_SEARCH { get; set; }

        [Description("Supports return key text \"Send\"."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_RETURN_KEY_SEND { get; set; }

        [Description("Supports return key text \"Done\"."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_RETURN_KEY_DONE { get; set; }

        [Description("Supports return key changes."), Category("CMP_CAP_INPUT_KEY_ID")]
        public bool CAP_INPUT_RETURN_KEY { get; set; }

        // CMP_CAP_ORIENTATION_KEY_ID
        [Description("CAP_ORIENTATION_ENABLE indicates whether the CMP_CAP_ORIENTATION_KEY_ID category is available."), Category("CMP_CAP_ORIENTATION_KEY_ID")]
        public bool CAP_ORIENTATION_ENABLE { get; set; }

        [Description("Supports orientation changes."), Category("CMP_CAP_ORIENTATION_KEY_ID")]
        public bool CAP_ORIENTATION_DEVICE { get; set; }

        [Description("Supports orientation changes by application."), Category("CMP_CAP_ORIENTATION_KEY_ID")]
        public bool CAP_ORIENTATION_APPLICATION { get; set; }

        [Description("Supports Portrait orientation."), Category("CMP_CAP_ORIENTATION_KEY_ID")]
        public bool CAP_ORIENTATION_PORTRAIT { get; set; }

        [Description("Supports Portrait-Down orientation."), Category("CMP_CAP_ORIENTATION_KEY_ID")]
        public bool CAP_ORIENTATION_PORTRAIT_DOWN { get; set; }

        [Description("Supports Landscape-Left orientation."), Category("CMP_CAP_ORIENTATION_KEY_ID")]
        public bool CAP_ORIENTATION_LANDSCAPE_LEFT { get; set; }

        [Description("Supports Landscape-Right orientation."), Category("CMP_CAP_ORIENTATION_KEY_ID")]
        public bool CAP_ORIENTATION_LANDSCAPE_RIGHT { get; set; }

        [Description("Supports orientation lock/unlock."), Category("CMP_CAP_ORIENTATION_KEY_ID")]
        public bool CAP_ORIENTATION_LOCK_UNLOCK { get; set; }

        [Description("Supports follow sensor orientation."), Category("CMP_CAP_ORIENTATION_KEY_ID")]
        public bool CAP_ORIENTATION_FOLLOW_SENSOR { get; set; }

        // CMP_CAP_DISPLAY_KEY_ID
        [Description("CAP_DISPLAY_ENABLE indicates whether the CMP_CAP_DISPLAY_KEY_ID category is available."), Category("CMP_CAP_DISPLAY_KEY_ID")]
        public bool CAP_DISPLAY_ENABLE { get; set; }

        [Description("Resolution information for x and y is available."), Category("CMP_CAP_DISPLAY_KEY_ID")]
        public bool CAP_DISPLAY_RESOLUTION_FLAG { get; set; }

        [Description("Color depth information is available."), Category("CMP_CAP_DISPLAY_KEY_ID")]
        public bool CAP_DISPLAY_COLOR_FLAG { get; set; }

        [Description("Physical dimensions for x and y is available."), Category("CMP_CAP_DISPLAY_KEY_ID")]
        public bool CAP_DISPLAY_PHYSICAL_FLAG { get; set; }

        [Description("Points per inch information is available."), Category("CMP_CAP_DISPLAY_KEY_ID")]
        public bool CAP_DISPLAY_PPI_FLAG { get; set; }

        [Description("Points per inch information for x and y is available."), Category("CMP_CAP_DISPLAY_KEY_ID")]
        public bool CAP_DISPLAY_PPI_X_Y_FLAG { get; set; }

        [Description("Orientation information is available."), Category("CMP_CAP_DISPLAY_KEY_ID")]
        public bool CAP_DISPLAY_ORIENTATION_FLAG { get; set; }

        [Description("All metrics flags in one group."), Category("CMP_CAP_DISPLAY_KEY_ID")]
        public int CAP_DISPLAY_METRICS { get; set; }

        [Description("Display width in pixels."), Category("CMP_CAP_DISPLAY_KEY_ID")]
        public int CAP_DISPLAY_WIDTH { get; set; }

        [Description("Display height in pixels."), Category("CMP_CAP_DISPLAY_KEY_ID")]
        public int CAP_DISPLAY_HEIGHT { get; set; }

        [Description("Display width in milliinches."), Category("CMP_CAP_DISPLAY_KEY_ID")]
        public int CAP_DISPLAY_X_MILLI_INCHES { get; set; }

        [Description("Display height in milliinches."), Category("CMP_CAP_DISPLAY_KEY_ID")]
        public int CAP_DISPLAY_Y_MILLI_INCHES { get; set; }

        [Description("Display pixels per inch."), Category("CMP_CAP_DISPLAY_KEY_ID")]
        public int CAP_DISPLAY_PIXELS_PER_INCH { get; set; }

        [Description("Display horizontal pixels per inch."), Category("CMP_CAP_DISPLAY_KEY_ID")]
        public int CAP_DISPLAY_X_PIXELS_PER_INCH { get; set; }

        [Description("Display vertical pixels per inch."), Category("CMP_CAP_DISPLAY_KEY_ID")]
        public int CAP_DISPLAY_Y_PIXELS_PER_INCH { get; set; }

        [Description("Initial display orientation position."), Category("CMP_CAP_DISPLAY_KEY_ID")]
        public short CAP_DISPLAY_INITIAL_ORIENTATION { get; set; }

        [Description("Display color depth (color bits per pixel)."), Category("CMP_CAP_DISPLAY_KEY_ID")]
        public short CAP_DISPLAY_COLOR_DEPTH { get; set; }

        // CMP_CAP_SCROLLMODES_KEY_ID
        [Description("CAP_SCROLLMODES_ENABLE indicates whether the CMP_CAP_SCROLLMODES_KEY_ID category is available."), Category("CMP_CAP_SCROLLMODES_KEY_ID")]
        public bool CAP_SCROLLMODES_ENABLE { get; set; }

        [Description("Supports mouse wheel emulation."), Category("CMP_CAP_SCROLLMODES_KEY_ID")]
        public bool CAP_SCROLLMODES_MOUSEWHEEL_FLAG { get; set; }

        [Description("Supports drag mode."), Category("CMP_CAP_SCROLLMODES_KEY_ID")]
        public bool CAP_SCROLLMODES_DRAG_FLAG { get; set; }

        [Description("Supports pan mode."), Category("CMP_CAP_SCROLLMODES_KEY_ID")]
        public bool CAP_SCROLLMODES_PAN_FLAG { get; set; }

        [Description("Default scroll mode."), Category("CMP_CAP_SCROLLMODES_KEY_ID")]
        public short CAP_SCROLLMODES_DEFAULT_MODE { get; set; }

        // CMP_CAP_BUTTON_KEY_ID
        [Description("CAP_BUTTON_ENABLE indicates whether the CMP_CAP_BUTTON_KEY_ID category is available."), Category("CMP_CAP_BUTTON_KEY_ID")]
        public bool CAP_BUTTON_ENABLE { get; set; }

        [Description("Supports back button."), Category("CMP_CAP_BUTTON_KEY_ID")]
        public bool CAP_BUTTON_BACK { get; set; }

        [Description("Supports search button."), Category("CMP_CAP_BUTTON_KEY_ID")]
        public bool CAP_BUTTON_SEARCH { get; set; }

        [Description("Supports home button."), Category("CMP_CAP_BUTTON_KEY_ID")]
        public bool CAP_BUTTON_HOME { get; set; }

        [Description("Supports menu button."), Category("CMP_CAP_BUTTON_KEY_ID")]
        public bool CAP_BUTTON_MENU { get; set; }

        [Description("Button mask value."), Category("CMP_CAP_BUTTON_KEY_ID")]
        public short CAP_BUTTON_MASK { get; set; }

        // CMP_CAP_TAKE_PICTURE_KEY_ID
        [Description("CAP_TAKE_PICTURE_ENABLE indicates whether the CMP_CAP_TAKE_PICTURE_KEY_ID category is available."), Category("CMP_CAP_TAKE_PICTURE_KEY_ID")]
        public bool CAP_TAKE_PICTURE_ENABLE { get; set; }

        [Description("Camera supports JPEG."), Category("CMP_CAP_TAKE_PICTURE_KEY_ID")]
        public bool CAP_TAKE_PICTURE_JPEG { get; set; }

        [Description("Camera supports PNG."), Category("CMP_CAP_TAKE_PICTURE_KEY_ID")]
        public bool CAP_TAKE_PICTURE_PNG { get; set; }

        // CMP_CAP_DEVICE_KEY_ID
        [Description("CAP_DEVICE_ENABLE indicates whether the CMP_CAP_DEVICE_KEY_ID category is available."), Category("CMP_CAP_DEVICE_KEY_ID")]
        public bool CAP_DEVICE_ENABLE { get; set; }

        [Description("Device operating system."), Category("CMP_CAP_DEVICE_KEY_ID")]
        public short CAP_DEVICE_OS { get; set; }
        
        [Description("Device operating system high version."), Category("CMP_CAP_DEVICE_KEY_ID")]
        public short CAP_DEVICE_OS_VER_HIGH { get; set; }
        
        [Description("Device operating system low version."), Category("CMP_CAP_DEVICE_KEY_ID")]
        public short CAP_DEVICE_OS_VER_LOW { get; set; }
        
        [Description("Device operation system minor version."), Category("CMP_CAP_DEVICE_KEY_ID")]
        public short CAP_DEVICE_OS_VER_MINOR { get; set; }
        
        [Description("Device operating system build version."), Category("CMP_CAP_DEVICE_KEY_ID")]
        public short CAP_DEVICE_OS_VER_BUILD { get; set; }
        
        [Description("Device type."), Category("CMP_CAP_DEVICE_KEY_ID")]
        public short CAP_DEVICE_TYPE { get; set; }

        // CMP_CAP_VIEWPORT_KEY_ID
        [Description("CAP_VIEWPORT_ENABLE indicates whether the CMP_CAP_VIEWPORT_KEY_ID category is available."), Category("CMP_CAP_VIEWPORT_KEY_ID")]
        public bool CAP_VIEWPORT_ENABLE { get; set; }

        // CMP_CAP_DYNAMIC_DISPLAY_KEY_ID
        [Description("CAP_DYNAMIC_DISPLAY_ENABLE indicates whether the CMP_CAP_DYNAMIC_DISPLAY_KEY_ID category is available."), Category("CMP_CAP_DYNAMIC_DISPLAY_KEY_ID")]
        public bool CAP_DYNAMIC_DISPLAY_ENABLE { get; set; }

        // CMP_CAP_PICKER_CONTROL_KEY_ID
        [Description("CAP_PICKER_CONTROL_ENABLE indicates whether the CMP_CAP_PICKER_CONTROL_KEY_ID category is available."), Category("CMP_CAP_PICKER_CONTROL_KEY_ID")]
        public bool CAP_PICKER_CONTROL_ENABLE { get; set; }

        [Description("Supports picker title."), Category("CMP_CAP_PICKER_CONTROL_KEY_ID")]
        public bool CAP_PICKER_CONTROL_TITLE_FLAG { get; set; }

        // CMP_CAP_PHONE_CALL_KEY_ID
        [Description("CAP_PHONE_CALL_ENABLE indicates whether the CMP_CAP_PHONE_CALL_KEY_ID category is available."), Category("CMP_CAP_PHONE_CALL_KEY_ID")]
        public bool CAP_PHONE_CALL_ENABLE { get; set; }

        // CMP_CAP_SMS_KEY_ID
        [Description("CAP_SMS_ENABLE indicates whether the CMP_CAP_SMS_KEY_ID category is available."), Category("CMP_CAP_SMS_KEY_ID")]
        public bool CAP_SMS_ENABLE { get; set; }

        // CMP_CAP_NOTIFICATION_KEY_ID
        [Description("CAP_NOTIFICATION_ENABLE indicates whether the CMP_CAP_NOTIFICATION_KEY_ID category is available."), Category("CMP_CAP_NOTIFICATION_KEY_ID")]
        public bool CAP_NOTIFICATION_ENABLE { get; set; }

        [Description("Supports light notification."), Category("CMP_CAP_NOTIFICATION_KEY_ID")]
        public bool CAP_NOTIFICATION_LIGHT { get; set; }

        [Description("Supports vibration notification."), Category("CMP_CAP_NOTIFICATION_KEY_ID")]
        public bool CAP_NOTIFICATION_VIBRATE { get; set; }

        [Description("Supports audio notification."), Category("CMP_CAP_NOTIFICATION_KEY_ID")]
        public bool CAP_NOTIFICATION_AUDIO { get; set; }

        [Description("Supports text notification."), Category("CMP_CAP_NOTIFICATION_KEY_ID")]
        public bool CAP_NOTIFICATION_TEXT { get; set; }

        // CMP_CAP_RECEIVER_CONTROLS_KEY_ID
        [Description("CAP_RECEIVER_CONTROLS_ENABLE indicates whether the CMP_CAP_RECEIVER_CONTROLS_KEY_ID category is available."), Category("CMP_CAP_RECEIVER_CONTROLS_KEY_ID")]
        public bool CAP_RECEIVER_CONTROLS_ENABLE { get; set; }

        [Description("Supports enable/disable of Receiver controls."), Category("CMP_CAP_RECEIVER_CONTROLS_KEY_ID")]
        public bool CAP_RECEIVER_CONTROLS_DISABLE { get; set; }

        // CMP_CAP_EVENT_FILTER_KEY_ID
        [Description("CAP_EVENT_FILTER_ENABLE indicates whether the CMP_CAP_EVENT_FILTER_KEY_ID category is available."), Category("CMP_CAP_EVENT_FILTER_KEY_ID")]
        public bool CAP_EVENT_FILTER_ENABLE { get; set; }

        [Description("Supports enable/disable of events filter."), Category("CMP_CAP_EVENT_FILTER_KEY_ID")]
        public bool CAP_EVENT_FILTER_SUPPORT { get; set; }
    }
}
