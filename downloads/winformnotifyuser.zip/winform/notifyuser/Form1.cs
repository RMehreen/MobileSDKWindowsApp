﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CitrixMobility;

namespace notifyuser
{
    public partial class Form1 : Form
    {
        // <summary>
        // These are bit masks corresponding to the notification flags defined by the CMP SDK. 
        // </summary>
        //! [notificationflags]
        private const short LIGHT_NOTIFICATION_FLAG     = 0x0001;       // Light notification.
        private const short VIBRATE_NOTIFICATION_FLAG   = 0x0002;       // Vibrate notification.
        private const short AUDIO_NOTIFICATION_FLAG     = 0x0004;       // Audio notification.
        private const short TEXT_NOTIFICATION_FLAG      = 0x0008;       // Text notification.
        //! [notificationflags]

        // <summary>
        // The following are unique IDs for each notification sent by this example. For the purposes of this example, these
        // are used to identify the type of notification sent, and subsequently handled in the UserNotified event.
        // </summary>
        //! [notificationids]
        private const int LIGHT_NOTIFICATION_ID         = 0x12340001;   // ID for sending light notification.
        private const int VIBRATE_NOTIFICATION_ID       = 0x12340002;   // ID for sending vibrate notification.
        private const int AUDIO_NOTIFICATION_ID         = 0x12340003;   // ID for sending audio notification.
        private const int TEXT_NOTIFICATION_ID          = 0x12340004;   // ID for sending text notification.
        private const int AUDIOVIBRATE_NOTIFICATION_ID  = 0x12340005;   // ID for sending audio+vibrate notification.
        //! [notificationids]

        // <summary>
        // Instance of CitrixMobile.
        // </summary>
        private CitrixMobile cmp = null;

        // <summary>
        // ICA session connected state.
        // </summary>
        private bool icaSessionConnected = false;

        // <summary>
        // Check CMP return code for success.
        // </summary>
        public static bool CMP_SUCCESS(int rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (int)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        // <summary>
        // Dispatch action to UI thread if necessary.
        // </summary>
        // <param name="action">The action.</param>
        private void UiDispatch(Action action)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(action);
            }
            else
            {
                action();
            }
        }

        // <summary>
        // Report CMP status.
        // </summary>
        // <param name="text">Status text.</param>
        // <param name="rc">CMP return code.</param>
        private void ReportStatus(string text, int rc)
        {
            // Only report status if something went wrong.
            if (!CMP_SUCCESS(rc))
            {
                string msg = string.Format("{0}, CMPResult: 0x{1:X}", text, rc);

                // Write to trace output.
                Helpers.Trace(msg);
                // Update status text.
                UiDispatch(() => this.status.Text = msg);
            }
        }

        public Form1()
        {
            InitializeComponent();

            // Initialises CMP framework.
            InitialiseCmp();
        }

        // <summary>
        // Initialise CMP framework.
        // </summary>
        private void InitialiseCmp()
        {
            int rc = (int)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Helpers.Trace("Creating CitrixMobile object");
                // Create an instance of CitrixMobile object.
                cmp = new CitrixMobile();

                Helpers.Trace("Register for ICA session state changed events");
                // Register for ICA session events.
                cmp.SessionStateChanged += new ICMPEvents_SessionStateChangedEventHandler(cmp_SessionStateChanged);

                Helpers.Trace("Calling OpenSession");
                // Open CMP session.
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    icaSessionConnected = true;

                    Helpers.Trace("Register for user notified events");
        //! [eventsubscription]
        // Register for user notified events.
        cmp.UserNotified += new ICMPEvents_UserNotifiedEventHandler(cmp_UserNotified);
        //! [eventsubscription]
                }
                else
                {
                    ReportStatus("OpenSession failed", rc);
                }
            }
            catch (System.Exception ex)
            {
                Helpers.Trace(ex.Message);
                Helpers.Trace(ex.StackTrace);
            }
        }

        // <summary>
        // Tear down CMP connection when closed.
        // </summary>
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (null != cmp)
            {
                // Close CMP session.
                cmp.CloseSession();
                cmp = null;
            }
        }

        // <summary>
        // Session state change handler.
        // </summary>
        // <remarks>Update the ICA session state upon connect/disconnect.</remarks>
        // <param name="SessState">Session state</param>
        private void cmp_SessionStateChanged(CMP_SESSION_STATE SessState)
        {
            switch (SessState)
            {
                case CMP_SESSION_STATE.CMP_SESSION_STATE_CONNECTED:
                    icaSessionConnected = true;
                    break;
                case CMP_SESSION_STATE.CMP_SESSION_STATE_DISCONNECTED:
                    icaSessionConnected = false;
                    break;
                default:
                    break;
            }
        }

        //! [eventhandler]
        // <summary>
        // UserNotified event handler.
        // </summary>
        // <param name="rc">Return code.</param>
        // <param name="NotificationId">Notification identifier.</param>
        private void cmp_UserNotified(int rc, int NotificationId)
        {
            Helpers.Trace("UserNotified rc:{0:X} NotifyId:{1:X}", rc, NotificationId);

            string notificationType = string.Empty;

            switch (NotificationId)
            {
                case LIGHT_NOTIFICATION_ID:
                    notificationType = "light";
                    break;
                case VIBRATE_NOTIFICATION_ID:
                    notificationType = "vibrate";
                    break;
                case AUDIO_NOTIFICATION_ID:
                    notificationType = "audio";
                    break;
                case TEXT_NOTIFICATION_ID:
                    notificationType = "text";
                    break;
                case AUDIOVIBRATE_NOTIFICATION_ID:
                    notificationType = "audio+vibrate";
                    break;
                default:
                    // Not one of ours.
                    break;
            }

            if (!string.IsNullOrEmpty(notificationType))
            {
                UiDispatch(() => this.status.Text = string.Format("User was notified through {0} notification.", notificationType));
            }
        }
        //! [eventhandler]

        private void lightButton_Click(object sender, EventArgs e)
        {
            if ((cmp != null) && icaSessionConnected)
            {
                int rc = (int)CMP_ERROR_ID.CMP_NOTIFY_NO_ERROR;

                try
                {
        //! [lightnotification]
        // Send a light notification.
        rc = cmp.NotifyUser(LIGHT_NOTIFICATION_ID, LIGHT_NOTIFICATION_FLAG, string.Empty);
        //! [lightnotification]
                }
                catch (Exception ex)
                {
                    Helpers.Trace("Light NotifyUser exception: {0}", ex.Message);
                }
                finally
                {
                    ReportStatus("Light NotifyUser failed", rc);
                }
            }
        }

        private void vibrateButton_Click(object sender, EventArgs e)
        {
            if ((cmp != null) && icaSessionConnected)
            {
                int rc = (int)CMP_ERROR_ID.CMP_NOTIFY_NO_ERROR;

                try
                {
        //! [vibratenotification]
        // Send a vibrate notification.
        rc = cmp.NotifyUser(VIBRATE_NOTIFICATION_ID, VIBRATE_NOTIFICATION_FLAG, string.Empty);
        //! [vibratenotification]
                }
                catch (Exception ex)
                {
                    Helpers.Trace("Vibrate NotifyUser exception: {0}", ex.Message);
                }
                finally
                {
                    ReportStatus("Vibrate NotifyUser failed", rc);
                }
            }
        }
        //! [audioeventhandler]
        private void audioButton_Click(object sender, EventArgs e)
        {
            if ((cmp != null) && icaSessionConnected)
            {
                int rc = (int)CMP_ERROR_ID.CMP_NOTIFY_NO_ERROR;

                try
                {
        //! [audionotification]
        // Send an audio notification.
        rc = cmp.NotifyUser(AUDIO_NOTIFICATION_ID, AUDIO_NOTIFICATION_FLAG, string.Empty);
        //! [audionotification]
                }
                catch (Exception ex)
                {
                    Helpers.Trace("Audio NotifyUser exception: {0}", ex.Message);
                }
                finally
                {
                    ReportStatus("Audio NotifyUser failed", rc);
                }
            }
        }
        //! [audioeventhandler]

        private void textButton_Click(object sender, EventArgs e)
        {
            if ((cmp != null) && icaSessionConnected)
            {
                int rc = (int)CMP_ERROR_ID.CMP_NOTIFY_NO_ERROR;

                try
                {
        //! [textnotification]
        // Send a text notification.
        rc = cmp.NotifyUser(TEXT_NOTIFICATION_ID, TEXT_NOTIFICATION_FLAG, "You have been notified through text notification.");
        //! [textnotification]
                }
                catch (Exception ex)
                {
                    Helpers.Trace("Text NotifyUser exception: {0}", ex.Message);
                }
                finally
                {
                    ReportStatus("Text NotifyUser failed", rc);
                }
            }
        }

        private void audioVibrateButton_Click(object sender, EventArgs e)
        {
            if ((cmp != null) && icaSessionConnected)
            {
                int rc = (int)CMP_ERROR_ID.CMP_NOTIFY_NO_ERROR;

                try
                {
        //! [audiovibratenotification]
        // Send an audio+vibrate notification.
        rc = cmp.NotifyUser(AUDIOVIBRATE_NOTIFICATION_ID, AUDIO_NOTIFICATION_FLAG | VIBRATE_NOTIFICATION_FLAG, string.Empty);
        //! [audiovibratenotification]
                }
                catch (Exception ex)
                {
                    Helpers.Trace("Audio+vibrate NotifyUser exception: {0}", ex.Message);
                }
                finally
                {
                    ReportStatus("Audio+vibrate NotifyUser failed", rc);
                }
            }
        }
    }
}
