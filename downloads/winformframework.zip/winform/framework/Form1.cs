﻿// C# Phone Call example using COM Interop with Citrix Mobility SDK
//
// Uses Citrix Mobility SDK to start a phone call
//
// Copyright (c) 2012 Citrix Systems
//
//! [winform_framework]
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CitrixMobility;

namespace framework
{
    public partial class Form1 : Form
    {
        // <summary>
        // Instance of CitrixMobile.
        // </summary>
        private CitrixMobile cmp = null;

        // <summary>
        // ICA session connected state.
        // </summary>
        private bool icaSessionConnected = false;

        // <summary>
        // Check CMP return code for success.
        // </summary>
        public static bool CMP_SUCCESS(int rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (int)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        
        public Form1()
        {
            InitializeComponent();

            // Initialises CMP framework.
            InitialiseCmp();
        }

        // <summary>
        // Initialise CMP framework.
        // </summary>
        private void InitialiseCmp()
        {
            int rc = (int)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Helpers.Trace("Creating CitrixMobile object");

                // Part 1:
                // =======
                // Create an instance of CitrixMobile object.
                cmp = new CitrixMobile();

                Helpers.Trace("Register for ICA session state changed events");

                // Part 2:
                // =======
                // Register for ICA session events.
                cmp.SessionStateChanged += new ICMPEvents_SessionStateChangedEventHandler(cmp_SessionStateChanged);

                Helpers.Trace("Calling OpenSession");

                // Part 3:
                // =======
                // Establish a CMP session.
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    icaSessionConnected = true;

                    Helpers.Trace("Register for sample event");

                    // Part 4:
                    // =======
                    // Register for event corresponding to the SampleAPI call below.
                    cmp.SampleEvent += new ICMPEvents_SampleEventHandler(cmp_SampleEventHandler);
                }
                else
                {
                    Helpers.Trace("OpenSession failed rc={0:X}", rc);
                }
            }
            catch (System.Exception ex)
            {
                Helpers.Trace(ex.Message);
                Helpers.Trace(ex.StackTrace);
            }
        }
        

        // Part 6: 
        // =======
        // <summary>
        // Tear down CMP connection when closed.
        // </summary>
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (null != cmp)
            {
                // Close CMP session.
                cmp.CloseSession();
                cmp = null;
            }
        }

        // Part 2: ICA Session state change handler.
        // =========================================
        // <summary>
        // Session state change handler.
        // </summary>
        // <remarks>Update the ICA session state upon connect/disconnect.</remarks>
        void cmp_SessionStateChanged(CMP_SESSION_STATE SessState)
        {
            switch (SessState)
            {
                case CMP_SESSION_STATE.CMP_SESSION_STATE_CONNECTED:
                    icaSessionConnected = true;
                    break;
                case CMP_SESSION_STATE.CMP_SESSION_STATE_DISCONNECTED:
                    icaSessionConnected = false;
                    break;
                default:
                    break;
            }
        }

        // Part 5: Implement the event handler for the SampleAPI.
        // ======================================================
        // <summary>
        // Sample event handler.
        // </summary>
        private void cmp_SampleEventHandler(int rc, int UniqueId)
        {
            // Do something...
            // ...
            // ...
        }
        
        // <summary>
        // Button click event handler.
        // </summary>
        private void Button_Click(object sender, EventArgs e)
        {
            Helpers.Trace("Button clicked");

            if ((null != cmp) && icaSessionConnected)
            {
                // Call the CMP framework API. In this example, the result of the SampleAPI is provided
                // in an event callback and handle by cmp_SampleEventHandler.
                rc = cmp.SampleAPI(...);
            }
        }
    }
}
//! [winform_framework]