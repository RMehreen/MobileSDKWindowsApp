﻿// C# Audio capture example using Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to capture an audio clip and transfer it to server.
//
// Copyright (c) 2013 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.Linq;
using CitrixMobility;
using System.Collections;
using System.Threading;
using System.IO;

using CMPRESULT = System.Int32;
using CMP_UNIQUE_LONG_ID = System.Int64;

namespace captureaudio
{
    static class Program
    {
        struct AUDIO_DATA
        {
            public CMPRESULT result;
            public CMP_UNIQUE_LONG_ID captureId;
            public string audioMetadata;
            public string filename;
            public int audioSize;
            public CMP_CAPTURE_AUDIO_OPTIONS options;

            public AUDIO_DATA(CMPRESULT result, CMP_UNIQUE_LONG_ID captureId, string filename, string audioMetadata, int audioSize, CMP_CAPTURE_AUDIO_OPTIONS options)
            {
                this.result = result;
                this.captureId = captureId;
                this.audioSize = audioSize;
                this.filename = filename;
                this.audioMetadata = audioMetadata;
                this.options = options;
            }
        };

        static CitrixMobile cmp;
        static CMP_UNIQUE_LONG_ID CaptureId;
        static AUDIO_DATA audioData;
        static AutoResetEvent captureProcessed = new AutoResetEvent(false);


        [MTAThread]
        static void Main()
        {
            // Audio capture event data
            audioData = new AUDIO_DATA((CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR, 0, null, null, 0, new CMP_CAPTURE_AUDIO_OPTIONS());

            CMPRESULT rc = (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Console.WriteLine("Creating CitrixMobile object");

                // Creates the CitrixMobile Object which contains all the CMP interfaces. e.g. IButton, ICamera
                cmp = new CitrixMobile();

                Console.WriteLine("Calling OpenSession");

                // Opens a connection to the remote mobile device
                // It is good practice to close the operation when no longer needed 
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    // register for audio capture event
                    RegisterForEvent();

                    // set audio capture options
                    CMP_CAPTURE_AUDIO_OPTIONS options = new CMP_CAPTURE_AUDIO_OPTIONS();
                    options.Encoding = CMP_AUDIO_ENCODING.CMP_AUDIO_ENCODING_WAV;               // Will try to use specifed encoding, otherwise client default.
                    //options.Quality = CMP_CAPTURE_QUALITY.CMP_CAPTURE_QUALITY_MAXIMUM;        // Unset options will use the client default.
                    options.DurationLimit = 30;                                                 // Limit of time in seconds (0 = no limit)

                    // capture an audio clip
                    rc = CaptureAudio(ref options);

                    if (CMP_SUCCESS(rc))
                    {
                        // Block and wait for the capture event to arrive and processed.
                        // The wait will timeout in 60 seconds.
                        // The audio is processed in the event handler and captureProcessed 
                        // is signalled once complete.
                        captureProcessed.WaitOne(60000);
                    }
                    else
                    {
                        // report an error with capture
                        ReportError(rc);
                    }

                    Thread.Sleep(10000);
                }
                else
                {
                    Console.WriteLine("OpenSession failed rc={0:X}", rc);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }

        /// <summary>
        /// Check CMP return code for success.
        /// </summary>
        static bool CMP_SUCCESS(CMPRESULT rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        //! [eventhandler]
        // <summary>
        // AudioCaptured event handler.
        // </summary>
        // <param name="result">Capture result.</param>
        // <param name="uniqueId">Capture identifier.</param>
        // <param name="audioMetadata">Capture metadata filename.</param>
        // <param name="filename">Capture filename.</param>
        // <param name="audioSize">Capture size.</param>
        // <param name="Quality">Capture quality.</param>
        // <param name="Encoding">Capture encoding.</param>
        // <param name="DurationLimit">Capture duration limit.</param>
        static void cmp_AudioCaptured(
            CMPRESULT result,
            CMP_UNIQUE_LONG_ID uniqueId,
            string audioMetadata,
            string filename,
            int audioSize,
            CMP_CAPTURE_QUALITY Quality,
            CMP_AUDIO_ENCODING Encoding,
            int DurationLimit)
        {
            // only process capture if it is one of ours
            if (uniqueId == CaptureId)
            {
                Console.WriteLine("Capture event\n");

                if (CMP_SUCCESS(result))
                {
                    // Copy the relevant data and then signal the event
                    audioData.result = result;
                    audioData.captureId = uniqueId;
                    audioData.audioMetadata = audioMetadata;
                    audioData.filename = filename;
                    audioData.audioSize = audioSize;

                    CMP_CAPTURE_AUDIO_OPTIONS options = new CMP_CAPTURE_AUDIO_OPTIONS();
                    options.Quality = Quality;
                    options.Encoding = Encoding;
                    options.DurationLimit = DurationLimit;

                    audioData.options = options;

                    Console.WriteLine("Capture result({0:X}) id({1:X}) size({3:X}) filename(4) audioMetadata(5) options(6)\n",
                                        result, uniqueId, audioSize, filename, audioMetadata, options.ToString());
                    Console.WriteLine("Capture options Quality(0) Encoding(1) DurationLimit(2)\n",
                                        Quality.ToString(), Encoding.ToString(), DurationLimit);

                    //Save the capture to the local temporary directory (keeping the same file name and extension).
                    string newLocation = System.IO.Path.GetTempPath() + System.IO.Path.GetFileName(filename);

                    Console.WriteLine("CMPGetFilename mobileFilename({0}) newLocation({1})", filename, newLocation);

                    Console.WriteLine("Copying file..\n");

                    File.Copy(filename, newLocation, true);

                    Console.WriteLine("Copy succeeded\n");

                    Console.WriteLine("Opening file in default application...\n");
                    System.Diagnostics.Process.Start(newLocation);
                }

                captureProcessed.Set();
            }
        }
        //! [eventhandler]

        // <summary>
        // Register for audio capture event
        // </summary>
        static void RegisterForEvent()
        {
            Console.WriteLine("Hooking audio capture event");

            //! [eventsubscription]
            // Subscribed AudioCaptured event.
            cmp.AudioCaptured += new ICMPEvents_AudioCapturedEventHandler(cmp_AudioCaptured);
            //! [eventsubscription]
        }

        // <summary>
        // Request an audio capture
        // </summary>
        static CMPRESULT CaptureAudio(ref CMP_CAPTURE_AUDIO_OPTIONS options)
        {
            CMPRESULT rc;

            Console.WriteLine("Request an audio capture");

            //! [captureaudio]
            // Request an audio capture
            rc = cmp.CaptureAudio(ref options, out CaptureId);
            //! [captureaudio]

            Console.WriteLine("Audio capture request sent");

            return (rc);
        }

        // <summary>
        // Report an error with relation to AudioCapture
        // </summary>
        static void ReportError(CMPRESULT rc)
        {
            CMP_ERROR_ID err = (CMP_ERROR_ID)rc;

            Console.WriteLine("Error {0:X} with CaptureAudio", rc);

            switch (err)
            {
                case CMP_ERROR_ID.CMP_ERROR_CLIENT_DRIVE_UNAVAILABLE:
                    Console.WriteLine("Client Drive unavailable. Check session options on Receiver.");
                    break;
                case CMP_ERROR_ID.CMP_ERROR_AUDIO_RECORDING_DISABLED:
                    Console.WriteLine("Audio recording is disabled. Check session options on Receiver.");
                    break;
                case CMP_ERROR_ID.CMP_ERROR_CAPABILITY_NOT_SUPPORTED:
                    Console.WriteLine("This device does not support audio capture.");
                    break;
                default:
                    break;
            }
        }

    }
}
