﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;

using CitrixMobility;
using CMPRESULT = System.Int32;
using CMP_UNIQUE_LONG_ID = System.Int64;

namespace captureaudio
{
    public partial class Form1 : Form
    {
        // <summary>
        // Instance of CitrixMobile.
        // </summary>
        private CitrixMobile cmp = null;

        // <summary>
        // Audio capture ID.
        // </summary>
        private CMP_UNIQUE_LONG_ID captureId;
        
        // <summary>
        // Audio capture options.
        // </summary>
        private CMP_CAPTURE_AUDIO_OPTIONS options;

        // <summary>
        // ICA session connected state.
        // </summary>
        private bool icaSessionConnected = false;

        // <summary>
        // Indicates whether capture processing is in progress.
        // </summary>
        private bool processingCapture = false;

        // <summary>
        // Lock object.
        // </summary>
        private object stateLock = new object();

        // <summary>
        // Check CMP return code for success.
        // </summary>
        public static bool CMP_SUCCESS(int rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (int)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        // <summary>
        // Dispatch action to UI thread if necessary.
        // </summary>
        // <param name="action">The action.</param>
        private void UiDispatch(Action action)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(action);
            }
            else
            {
                action();
            }
        }

        // <summary>
        // Report CMP status.
        // </summary>
        // <param name="text">Status text.</param>
        // <param name="rc">CMP return code.</param>
        private void ReportStatus(string text, int rc)
        {
            // Only report status if something went wrong.
            if (!CMP_SUCCESS(rc))
            {
                string msg = string.Format("{0}, CMPResult: 0x{1:X}", text, rc);

                // Write to trace output.
                Helpers.Trace(msg);
                // Update status text.
                UpdateStatus(msg);
            }
        }

        public Form1()
        {
            InitializeComponent();

            // Initialises CMP framework.
            InitialiseCmp();
        }

        // <summary>
        // Initialise CMP framework.
        // </summary>
        private void InitialiseCmp()
        {
            int rc = (int)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Helpers.Trace("Creating CitrixMobile object");
                // Create an instance of CitrixMobile object.
                cmp = new CitrixMobile();

                Helpers.Trace("Register for ICA session state changed events");
                // Register for ICA session events.
                cmp.SessionStateChanged += new ICMPEvents_SessionStateChangedEventHandler(cmp_SessionStateChanged);

                Helpers.Trace("Calling OpenSession");
                // Open CMP session.
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    icaSessionConnected = true;

                    Helpers.Trace("Register for AudioCaptured event");
                    //! [eventsubscription]
                    // Register for AudioCaptured event.
                    cmp.AudioCaptured += new ICMPEvents_AudioCapturedEventHandler(cmp_AudioCaptured);
                    //! [eventsubscription]
                }
                else
                {
                    string msg = string.Format("OpenSession failed rc={0:X}", rc);
                    UpdateStatus(msg);
                    Helpers.Trace(msg);
                }
            }
            catch (System.Exception ex)
            {
                UpdateStatus(ex.Message);
                Helpers.Trace(ex.Message);
                Helpers.Trace(ex.StackTrace);
            }
        }

        //! [eventhandler]
        // <summary>
        // AudioCaptured event handler.
        // </summary>
        // <param name="rc">Capture result.</param>
        // <param name="uniqueId">Capture identifier.</param>
        // <param name="audioMetadata">Capture metadata filename.</param>
        // <param name="filename">Capture filename.</param>
        // <param name="audioSize">Capture size.</param>
        // <param name="Quality">Capture quality.</param>
        // <param name="Encoding">Camera encoding.</param>
        // <param name="DurationLimit">Capture duration limit.</param>
        void cmp_AudioCaptured(CMPRESULT rc, CMP_UNIQUE_LONG_ID uniqueId, string audioMetadata, string filename, 
            CMPRESULT audioSize, CMP_CAPTURE_QUALITY Quality, CMP_AUDIO_ENCODING Encoding, CMPRESULT DurationLimit)
        {
            // only process capture if it is one of ours
            if (uniqueId == captureId)
            {
                if (CMP_SUCCESS(rc))
                {
                    lock (stateLock)
                    {
                        processingCapture = true;
                    }

                    UpdateStatus(string.Format("Capture received: {0}", filename));

                    //Save the capture to the local temporary directory (keeping the same file name and extension).
                    string newLocation = System.IO.Path.GetTempPath() + System.IO.Path.GetFileName(filename);

                    UpdateStatus(string.Format("Saving capture to: {0}", newLocation));

                    File.Copy(filename, newLocation, true);

                    // Play the capture. Note that this is invoked in the UI thread.
                    PlayAudio(newLocation);
                    UpdateStatus(string.Format("Capture saved: {0}", newLocation));

                    lock (stateLock)
                    {
                        processingCapture = false;
                    }
                }
            }
        }
        //! [eventhandler]

        // <summary>
        // Tear down CMP connection when closed.
        // </summary>
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (null != cmp)
            {
                // Close CMP session.
                cmp.CloseSession();
                cmp = null;
            }
        }

        // <summary>
        // Session state change handler.
        // </summary>
        // <remarks>Update the ICA session state upon connect/disconnect.</remarks>
        // <param name="SessState">Session state</param>
        void cmp_SessionStateChanged(CMP_SESSION_STATE SessState)
        {
            switch (SessState)
            {
                case CMP_SESSION_STATE.CMP_SESSION_STATE_CONNECTED:
                    icaSessionConnected = true;
                    break;
                case CMP_SESSION_STATE.CMP_SESSION_STATE_DISCONNECTED:
                    icaSessionConnected = false;
                    break;
                default:
                    break;
            }
        }

        // <summary>
        // Display the specified status text.
        // </summary>
        // <param name="statusText">Status text.</param>
        private void UpdateStatus(string statusText)
        {
            UiDispatch(() => status.Text = statusText);
        }

        // <summary>
        // Play the specified audio file.
        // </summary>
        // <param name="pathToAudio">Path to the audio file.</param>
        private void PlayAudio(string pathToAudio)
        {
            UiDispatch(() => axWindowsMediaPlayer1.URL = pathToAudio);
        }

        private delegate void InvokeDelegate(string pathToAudio);

        // <summary>
        // Label click handler.
        // </summary>
        // <remarks>Initiate audio capture on the device when the label is clicked.</remarks>
        // <param name="sender"></param>
        // <param name="e"></param>
        private void label1_Click(object sender, EventArgs e)
        {
            if ((null != cmp) && icaSessionConnected && !processingCapture)
            {
                try
                {
                    UpdateStatus("Sending request to capture audio");
                    Helpers.Trace("Sending request to capture audio");

                    //! [captureaudio]
                    // Request a audio capture.
                    int rc = cmp.CaptureAudio(ref options, out captureId);
                    //! [captureaudio]

                    if (CMP_SUCCESS(rc))
                    {
                        UpdateStatus("Capture audio request sent successfully");
                        Helpers.Trace("Capture audio request sent successfully");
                    }
                    else
                    {
                        ReportError(rc);
                    }
                }
                catch (Exception ex)
                {
                    UpdateStatus(ex.Message);
                    Helpers.Trace(ex.Message);
                    Helpers.Trace(ex.StackTrace);
                }
            }
        }

        // <summary>
        // Report an error with relation to AudioCapture
        // </summary>
        private void ReportError(CMPRESULT rc)
        {
            CMP_ERROR_ID err = (CMP_ERROR_ID)rc;

            string msg = string.Format("Error {0:X} with CaptureAudio\n", rc);

            switch (err)
            {
                case CMP_ERROR_ID.CMP_ERROR_AUDIO_RECORDING_DISABLED:
                    msg += "Audio recording is disabled. Check session options on Receiver.";
                    break;
                case CMP_ERROR_ID.CMP_ERROR_CLIENT_DRIVE_UNAVAILABLE:
                    msg += "Client Drive unavailable. Check session options on Receiver.";
                    break;
                case CMP_ERROR_ID.CMP_ERROR_CAPABILITY_NOT_SUPPORTED:
                    msg += "This device does not support audio capture.";
                    break;
                default:
                    break;
            }

            UpdateStatus(msg);
            Helpers.Trace(msg);
        }
    }
}
