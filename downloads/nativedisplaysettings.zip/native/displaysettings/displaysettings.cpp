//
// C++ Display Settings example with Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to reveal display settings.
// Retrieves information on the device's display settings after a change 
// in the settings is detected (through a DisplaySettingsChanged event) 
// and prints them out on the console window.
//
// Copyright (c) 2012 Citrix Systems
//

#include <stdio.h>
#include <windows.h>

#include <cmp.h>

//
// Local functions
//
void ReportStatus(LPCSTR text, CMPRESULT rc);
void ReportDisplaySettings(CMP_DISPLAY_SETTINGS& displaySettings);

CMPRESULT RegisterEventHandler(HANDLE hCMP);
CMPRESULT GetDisplaySettings(HANDLE hCMP, CMP_DISPLAY_SETTINGS& displaySettings);
void      WaitForCMPEvents(int seconds);

//
// main entry point for simple display settings program
//
int __cdecl main(int argc, char **argv)
{
    CMPRESULT rc;
    HANDLE hCMP = NULL;

    // initialize for STA (Single Thread Apartment) in COM
    rc = CMPInitialize(FALSE);

    ReportStatus("CMPInitialize", rc);

    // Open a handle to the mobile device
    rc = CMPOpen(&hCMP);

    ReportStatus("CMPOpen", rc);

    if(CMP_SUCCESS(rc))
    {
        // open the link between the two sides
        rc = CMPOpenSession(hCMP);

        ReportStatus("CMPOpenSession", rc);

        if(CMP_SUCCESS(rc))
        {
            CMP_DISPLAY_SETTINGS displaySettings;

            // registry for display settings changed event
            rc = RegisterEventHandler(hCMP);

            // best practice to initialize the length of the structure
            memset(&displaySettings, 0, sizeof(displaySettings));
            displaySettings.Length = sizeof(CMP_DISPLAY_SETTINGS);

            // get the current display settings
            rc = GetDisplaySettings(hCMP, displaySettings);

            if(CMP_SUCCESS(rc))
            {
                ReportDisplaySettings(displaySettings);
            }

            printf("\nRotate the device to test the display settings change event\n");

            // let events come in over the next 30 seconds
            // if this was a Windows program and we had a message loop, we would not need to do this
            WaitForCMPEvents(30);

            // close our connection
            CMPCloseSession(hCMP);
        }

        // release our handle
        CMPClose(hCMP);
    }

    // uninitialize COM
    CMPUninitialize();
}

//! [eventhandler]
// <summary>
// Display Settings event handler.
// </summary>
// <param name="hCMP">CMP handler</param>
// <param name="metricsFlags">Metrix flags.</param>
// <param name="pixelWidth">Pixel width.</param>
// <param name="pixelHeight">Pixel height.</param>
// <param name="colorDepth">Colour depth.</param>
// <param name="XPixelsPerInch">X-axis pixels per inch.</param>
// <param name="YPixelsPerInch">Y-axis pixels per inch.</param>
// <param name="orientation">Device Orientation</param>
// <param name="WidthMilliInches">Width milli-inches</param>
// <param name="HeightMilliInches">Heigth milli-inches</param>
// <param name="normalizedDPI">Normalised dots per inch</param>
void CMPAPI DisplaySettingsChanged(
	HANDLE hCMP, 
	INT16 metricsFlags, 
	INT32 pixelWidth, 
	INT32 pixelHeight,
	INT16 colorDepth, 
	INT32 XPixelsPerInch, 
	INT32 YPixelsPerInch,
	CMP_ORIENTATION_POSITION orientation, 
	INT32 WidthMilliInches, 
	INT32 HeightMilliInches,
	INT32 normalizedDPI)
{
    printf("DisplaySettingsChanged hCMP(%p) MetricsFlags(0x%X) "
		"pixelWidth(%u) pixelHeight(%u) colorDepth(%u) "
		"xPixelsPerInch(%u) yPixelsPerInch(%u) orientation(%u) "
		"widthMilliInches(%u) heightMilliInches(%u) normalizedDPI(%u)\n",
		hCMP, metricsFlags, pixelWidth, pixelHeight, colorDepth, 
		XPixelsPerInch, YPixelsPerInch, orientation, 
		WidthMilliInches, HeightMilliInches, normalizedDPI);
}
//! [eventhandler]

/// <summary>
/// Check CMP return code for success and report errors if they happen.
/// </summary>
void ReportStatus(LPCSTR text, CMPRESULT rc)
{
    // only print if something went wrong
    if(CMP_FAILURE(rc))
    {
        printf("%s CMPResult(%08X)\n", text, rc);
    }

    return;
}

/// <summary>
/// Prints the new display settings on the console window when a change occurs.
/// </summary>
/// <param name="displaySettings">CMP Display settings.</param>
void ReportDisplaySettings(CMP_DISPLAY_SETTINGS& displaySettings)
{
    printf("DisplaySettings structure length(%u)\n",        displaySettings.Length);
    printf("Pixel width(%u) height(%u)\n",                  displaySettings.PixelWidth, displaySettings.PixelHeight);
    printf("Color depth(%u)\n",                             displaySettings.ColorDepth);
    printf("Orientation(%u)\n",                             displaySettings.DeviceOrientation);
    printf("Physical width(%u) height(%u) MilliInches\n",   displaySettings.WidthMilliInches, displaySettings.HeightMilliInches);
    printf("PPI X(%u) Y(%u)\n",                             displaySettings.HorizontalPixelsPerInch, displaySettings.VerticalPixelsPerInch);
}

/// <summary>
/// Register the event handler for DisplaySettingsChanged.
/// </summary>
/// <param name="hCMP">handle to CMP Object</param>
CMPRESULT RegisterEventHandler(HANDLE hCMP)
{
    CMPRESULT rc;

    //! [eventsubscription]
    // Subscribe to DisplaySettingsChanged event.
    rc = CMPRegisterForEvent(hCMP, CMP_EVENT_DISPLAY_SETTINGS_CHANGED, (CMP_EVENT_CALLBACK)DisplaySettingsChanged); 
    //! [eventsubscription]

    ReportStatus("CMPRegisterForEvent CMP_EVENT_DISPLAY_SETTINGS_CHANGED", rc);

    return(rc);
}

/// <summary>
/// Get the current display settings
/// </summary>
/// <param name="hCMP">handle to CMP Object</param>
/// <param name="displaySettings">collection of display settings in structure returned from call</param>
CMPRESULT GetDisplaySettings(HANDLE hCMP, CMP_DISPLAY_SETTINGS& displaySettings)
{
    CMPRESULT rc;

	//! [displaysettings]
    // Gets the display settings of the device.
    rc = CMPGetDisplaySettings(hCMP, &displaySettings);
	//! [displaysettings]

    ReportStatus("CMPGetDisplaySettings", rc);

    return(rc);
}

// <summary>
// A "wait" spin loop to give the events a chance to happen
// </summary>
void WaitForCMPEvents(int seconds)
{
    for(int i=0; i<seconds; i++)
    {
        Sleep(1000);
    }
}
