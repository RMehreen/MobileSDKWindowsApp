//
// C++ Phone Call example with Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to start a phone call
//
// Copyright (c) 2012 Citrix Systems
//

#include <stdio.h>
#include <windows.h>

#include <cmp.h>

// change the phone number to something more appropriate
#define PHONE_NUMBER        "+18005551212"

// unique number should not be a constant but it is here for an example
#define UNIQUE_CALL_ID      0x87654321

// Local functions
void        ReportStatus(LPCSTR text, CMPRESULT rc);
void        WaitForCMPEvents(int seconds);
CMPRESULT   RegisterForEvent(HANDLE hCMP);
CMPRESULT   StartCall(HANDLE hCMP, UTF8_STRING phoneNumber, CMP_UNIQUE_ID phonecallId);

//
// main entry point for simple phone call program
//
int __cdecl main(int argc, char **argv)
{
    CMPRESULT rc;
    HANDLE hCMP = NULL;

    // initialize for STA (Single Thread Apartment) in COM
    rc = CMPInitialize(FALSE);

    ReportStatus("CMPInitialize", rc);

    // Open a handle to the mobile device
    rc = CMPOpen(&hCMP);

    ReportStatus("CMPOpen", rc);

    if(CMP_SUCCESS(rc))
    {
        // open the link between the two sides
        rc = CMPOpenSession(hCMP);

        ReportStatus("CMPOpenSession", rc);

        if(CMP_SUCCESS(rc))
        {
            // register for PhoneCallStarted event
            rc = RegisterForEvent(hCMP);

            if(CMP_SUCCESS(rc))
            {
                // start the phone call
                rc = StartCall(hCMP, PHONE_NUMBER, UNIQUE_CALL_ID);

                if(CMP_SUCCESS(rc))
                {
                    // let events come in over the next 30 seconds
                    // if this was a Windows program and we had a message loop, we would not need to do this
                    WaitForCMPEvents(30);
                }
            }

            // close our connection
            CMPCloseSession(hCMP);
        }

        // release our handle
        CMPClose(hCMP);
    }

    // uninitialize COM
    CMPUninitialize();

}

//! [eventhandler]
// <summary>
// PhoneCallStarted event handler.
// </summary>
// <param name="hCMP">CMP handler.</param>
// <param name="rc">Return code.</param>
// <param name="PhoneCallId">Phone call identifier.</param>
void CMPAPI PhoneCallStarted(HANDLE hCMP, CMPRESULT rc, CMP_UNIQUE_ID PhoneCallId)
{
    // only proceed if the call is one of ours
    if(PhoneCallId == UNIQUE_CALL_ID)
    {
        printf("PhoneCallStarted hCMP(%p) rc(0x%X) PhoneCallId(%X)\n", hCMP, rc, PhoneCallId);
    }
}
//! [eventhandler]

/// <summary>
/// Check CMP return code for success and report errors if they happen.
/// </summary>
void ReportStatus(LPCSTR text, CMPRESULT rc)
{
    // only print if something went wrong
    if(CMP_FAILURE(rc))
    {
        printf("%s CMPResult(%08X)\n", text, rc);
    }

    return;
}

/// <summary>
/// Register for PhoneCallStarted event
/// </summary>
CMPRESULT RegisterForEvent(HANDLE hCMP)
{
    CMPRESULT rc;

    //! [eventsubscription]
    // Subscribe to PhoneCallStarted event.
    rc = CMPRegisterForEvent(hCMP, CMP_EVENT_PHONE_CALL_STARTED, (CMP_EVENT_CALLBACK)PhoneCallStarted); 
	//! [eventsubscription]

    ReportStatus("CMPRegisterForEvent CMP_EVENT_PHONE_CALL_STARTED", rc);

    return(rc);
}

/// <summary>
/// Start a phone call
/// </summary>
CMPRESULT StartCall(HANDLE hCMP, UTF8_STRING phoneNumber, CMP_UNIQUE_ID phonecallId)
{
    CMPRESULT rc;

	//! [phonecall]
    // Start the phone call process by popping up the dialer with the number already populated
    rc = CMPStartCall(hCMP, PHONE_NUMBER, UNIQUE_CALL_ID);
    //! [phonecall]

    ReportStatus("CMPStartCall", rc);

    return(rc);
}

//
// A "wait" method which allows events to occur
//
void WaitForCMPEvents(int seconds)
{
    for(int i=0; i<seconds; i++)
    {
        Sleep(1000);
    }
}
