// C++ Send SMS example using Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to start a SMS
//
// Copyright (c) 2012 Citrix Systems
//

#include <stdio.h>
#include <windows.h>

#include <cmp.h>

// change the phone number and text to something more appropriate
#define PHONE_NUMBER        "+18005551212"
#define SMS_TEXT            "This is text to be sent with the SMS"

// unique number should not be a constant but it is here for an example
#define UNIQUE_SMS_ID      0x20113112

// Local functions
void      ReportStatus(LPCSTR text, CMPRESULT rc);
void      WaitForCMPEvents(int seconds);
CMPRESULT RegisterForEvent(HANDLE hCMP);
CMPRESULT SendSMS(HANDLE hCMP, UTF8_STRING phonenumber, CMP_UNIQUE_ID SMSId, UTF8_STRING SMSText);

//
// main entry point for simple phone call program
//
int __cdecl main(int argc, char **argv)
{
    CMPRESULT rc;
    HANDLE hCMP = NULL;

    // initialize for STA (Single Thread Apartment) in COM
    rc = CMPInitialize(FALSE);

    ReportStatus("CMPInitialize", rc);

    // Open a handle to the mobile device
    rc = CMPOpen(&hCMP);

    ReportStatus("CMPOpen", rc);

    if(CMP_SUCCESS(rc))
    {
        // open the link between the two sides
        rc = CMPOpenSession(hCMP);

        ReportStatus("CMPOpenSession", rc);

        if(CMP_SUCCESS(rc))
        {
            // register for SMS sent event
            rc = RegisterForEvent(hCMP);

            if(CMP_SUCCESS(rc))
            {
                // send the SMS message
                rc = SendSMS(hCMP, PHONE_NUMBER, UNIQUE_SMS_ID, SMS_TEXT); 

                if(CMP_SUCCESS(rc))
                {
                    // let events come in over the next 30 seconds
                    // if this was a Windows program and we had a message loop, we would not need to do this
                    WaitForCMPEvents(30);
                }
            }

            // close our connection
            CMPCloseSession(hCMP);
        }

        // release our handle
        CMPClose(hCMP);
    }

    // uninitialize COM
    CMPUninitialize();

}

//! [eventhandler]
// <summary>
// SMSStarted event handler.
// </summary>
// <param name="hCMP">CMP handler.</param>
// <param name="rc">Return code.</param>
// <param name="SMSId">SMS identifier.</param>
void CMPAPI SMSStarted(HANDLE hCMP, CMPRESULT rc, CMP_UNIQUE_ID SMSId)
{
    // only proceed if the sms is one of ours
    if(SMSId == UNIQUE_SMS_ID)
    {
        printf("SMSStarted hCMP(%p) rc(0x%X) SMSId(%X)\n", hCMP, rc, SMSId);
    }
}
//! [eventhandler]

/// <summary>
/// Check CMP return code for success and report errors if they happen.
/// </summary>
void ReportStatus(LPCSTR text, CMPRESULT rc)
{
    // only print if something went wrong
    if(CMP_FAILURE(rc))
    {
        printf("%s CMPResult(%08X)\n", text, rc);
    }

    return;
}

/// <summary>
/// Register to SMS Started event
/// </summary>
CMPRESULT RegisterForEvent(HANDLE hCMP)
{
    CMPRESULT rc;

    //! [eventsubscription]
    // Subscribe to SMSStarted event.
    rc = CMPRegisterForEvent(hCMP, CMP_EVENT_SMS_STARTED, (CMP_EVENT_CALLBACK)SMSStarted); 
    //! [eventsubscription]

    ReportStatus("CMPRegisterForEvent CMP_EVENT_SMS_STARTED", rc);

    return(rc);
}

/// <summary>
/// Send a SMS message
/// </summary>
CMPRESULT SendSMS(HANDLE hCMP, UTF8_STRING phoneNumber, CMP_UNIQUE_ID SMSId, UTF8_STRING SMSText)
{
    CMPRESULT rc;

    //! [startsmsapp]
    // Start the SMS process by popping up the SMS screen with the phone number already populated
    rc = CMPSendSMS(hCMP, phoneNumber, SMSId, SMSText);
    //! [startsmsapp]

    ReportStatus("CMPSendSMS", rc);

    return(rc);
}

// <summary>
// A "wait" spin loop to give the events a chance to happen
// </summary>
void WaitForCMPEvents(int seconds)
{
    for(int i=0; i<seconds; i++)
    {
        Sleep(1000);
    }
}
