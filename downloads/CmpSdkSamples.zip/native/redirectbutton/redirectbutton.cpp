// C++ Redirect button example using Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to redirect button presses.
//
// Copyright (c) 2012 Citrix Systems
//

#include <stdio.h>
#include <windows.h>

#include <cmp.h>

// Local functions
void      ReportStatus(LPCSTR text, CMPRESULT rc);
CMPRESULT RegisterForEvents(HANDLE hCMP);
CMPRESULT RegisterForButtonPressedEvent(HANDLE hCMP);
CMPRESULT RegisterForButtonTargetChangedEvent(HANDLE hCMP);
CMPRESULT SetButtonTarget(HANDLE hCMP, CMP_BUTTON_ID buttonId, CMP_BUTTON_TARGET buttonTarget);
void      WaitForCMPEvents(int seconds);

//
// main entry point for simple phone call program
//
int __cdecl main(int argc, char **argv)
{
    CMPRESULT rc;
    HANDLE hCMP = NULL;

    // initialize for STA (Single Thread Apartment) in COM
    rc = CMPInitialize(FALSE);

    ReportStatus("CMPInitialize", rc);

    // Open a handle to the mobile device
    rc = CMPOpen(&hCMP);

    ReportStatus("CMPOpen", rc);

    if(CMP_SUCCESS(rc))
    {
        // open the link between the two sides
        rc = CMPOpenSession(hCMP);

        ReportStatus("CMPOpenSession", rc);

        if(CMP_SUCCESS(rc))
        {
            // register for button pressed and button target changed events
            rc = RegisterForEvents(hCMP);

            if(CMP_SUCCESS(rc))
            {
                printf("Checking if Back button is supported\n");
                bool backButtonSupported = false;
                rc = CMPGetCapabilityBool(hCMP,CAPID_BUTTON_SET_TARGET,CAP_BUTTON_BACK, (PBOOL) &backButtonSupported);

                if(backButtonSupported)
                {
                    // reassign the back button to notify this sample program event handler
                    rc = SetButtonTarget(hCMP, CMP_BUTTON_BACK, CMP_BUTTON_TARGET_HOST);

                    if(CMP_SUCCESS(rc))
                    {
                        // let events come in over the next 30 seconds
                        // if this was a Windows program and we had a message loop, we would not need to do this
                        WaitForCMPEvents(30);

                        // reassign the back button to the client device before exiting
                        rc = SetButtonTarget(hCMP, CMP_BUTTON_BACK, CMP_BUTTON_TARGET_CLIENT);
                    }
                }
                else
                {
                    printf("Back button is not supported\n");
                    printf("Press any key to continue ...\n");
                    getchar();
                }
                
            }

            // close our connection
            CMPCloseSession(hCMP);
        }

        // release our handle
        CMPClose(hCMP);
    }

    // uninitialize COM
    CMPUninitialize();
}

//! [buttonpressed_handler]
// <summary>
// ButtonPressed event handler.
// </summary>
// <param name="hCMP">CMP handle.</param>
// <param name="buttonId">Button ID.</param>
void CMPAPI ButtonPressed(
    HANDLE hCMP, CMP_BUTTON_ID buttonId)
{
    printf("ButtonPressed hCMP(%p) buttonId(%u)\n", hCMP, buttonId);
}

//! [buttonpressed_handler]

//! [targetchanged_handler]
// <summary>
// ButtonTargetChanged event handler.
// </summary>
// <param name="hCMP">CMP handle.</param>
// <param name="rc">Return code.</param>
// <param name="buttonId">Button ID.</param>
// <param name="buttonTarget">Button target.</param>
void CMPAPI ButtonTargetChanged(
	HANDLE hCMP, 
	CMPRESULT rc, 
	CMP_BUTTON_ID buttonId,
    CMP_BUTTON_TARGET buttonTarget)
{
    printf("ButtonTargetChanged hCMP(%p) rc(0x%X) buttonId(%u) buttonTarget(0x%X)\n", 
		hCMP, rc, buttonId, buttonTarget);
}
//! [targetchanged_handler]

/// <summary>
/// Check CMP return code for success and report errors if they happen.
/// </summary>
void ReportStatus(LPCSTR text, CMPRESULT rc)
{
    // only print if something went wrong
    if(CMP_FAILURE(rc))
    {
        printf("%s CMPResult(%08X)\n", text, rc);
    }
}

/// <summary>
/// Register for button events
/// </summary>
CMPRESULT RegisterForEvents(HANDLE hCMP)
{
    CMPRESULT rc;

    rc = RegisterForButtonPressedEvent(hCMP);

    if(CMP_SUCCESS(rc))
    {
        rc = RegisterForButtonTargetChangedEvent(hCMP);
    }

    return(rc);
}


/// <summary>
/// Register for button pressed event
/// </summary>
CMPRESULT RegisterForButtonPressedEvent(HANDLE hCMP)
{
    CMPRESULT rc;

    //! [buttonpressed_subscription]
    // Subscribed ButtonPressed event
    rc = CMPRegisterForEvent(hCMP, CMP_EVENT_BUTTON_PRESSED, (CMP_EVENT_CALLBACK)ButtonPressed); 
    //! [buttonpressed_subscription]

    ReportStatus("CMPRegisterForEvent CMP_EVENT_BUTTON_PRESSED", rc);

    return(rc);
}

/// <summary>
/// Register for button target changed event
/// </summary>
CMPRESULT RegisterForButtonTargetChangedEvent(HANDLE hCMP)
{
    CMPRESULT rc;

    //! [targetchanged_subscription]
    // Subscribed ButtonTargetChanged event
    rc = CMPRegisterForEvent(hCMP, CMP_EVENT_BUTTON_TARGET_CHANGED, (CMP_EVENT_CALLBACK)ButtonTargetChanged); 
    //! [targetchanged_subscription]

    ReportStatus("CMPRegisterForEvent CMP_EVENT_BUTTON_TARGET_CHANGED", rc);

    return(rc);
}


/// <summary>
/// Set the button target (client or server)
/// </summary>
CMPRESULT SetButtonTarget(HANDLE hCMP, CMP_BUTTON_ID buttonId, CMP_BUTTON_TARGET buttonTarget)
{
    CMPRESULT rc;

	//! [redirect_button]
    // Redirect the "Back" button to the host (this application).
    rc = CMPSetButtonTarget(hCMP, buttonId, buttonTarget);
	//! [redirect_button]

    ReportStatus("CMPSetButtonTarget", rc);

    return(rc);
}

// <summary>
// A "wait" spin loop to give the events a chance to happen
// </summary>
void WaitForCMPEvents(int seconds)
{
    for(int i=0; i<seconds; i++)
    {
        Sleep(1000);
    }
}
