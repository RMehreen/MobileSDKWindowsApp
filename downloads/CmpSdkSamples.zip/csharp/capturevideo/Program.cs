﻿// C# Video capture example using Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to capture a video and transfer it to server.
//
// Copyright (c) 2013 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.Linq;
using CitrixMobility;
using System.Collections;
using System.Threading;
using System.IO;

using CMPRESULT = System.Int32;
using CMP_UNIQUE_LONG_ID = System.Int64;

namespace capturevideo
{
    static class Program
    {
        struct VIDEO_DATA
        {
            public CMPRESULT result;
            public CMP_UNIQUE_LONG_ID captureId;
            public string videoMetadata;
            public string filename;
            public int videoSize;
            public CMP_CAPTURE_VIDEO_OPTIONS options;

            public VIDEO_DATA(CMPRESULT result, CMP_UNIQUE_LONG_ID captureId, string filename, string videoMetadata, int videoSize, CMP_CAPTURE_VIDEO_OPTIONS options)
            {
                this.result = result;
                this.captureId = captureId;
                this.videoSize = videoSize;
                this.filename = filename;
                this.videoMetadata = videoMetadata;
                this.options = options;
            }
        };

        static CitrixMobile cmp;
        static CMP_UNIQUE_LONG_ID CaptureId;
        static VIDEO_DATA videoData;
        static AutoResetEvent captureProcessed = new AutoResetEvent(false);


        [MTAThread]
        static void Main()
        {
            // Video capture event data
            videoData = new VIDEO_DATA((CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR, 0, null, null, 0, new CMP_CAPTURE_VIDEO_OPTIONS());

            CMPRESULT rc = (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Console.WriteLine("Creating CitrixMobile object");

                // Creates the CitrixMobile Object which contains all the CMP interfaces. e.g. IButton, ICamera
                cmp = new CitrixMobile();

                Console.WriteLine("Calling OpenSession");

                // Opens a connection to the remote mobile device
                // It is good practice to close the operation when no longer needed 
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    // register for video capture event
                    RegisterForEvent();

                    // set video capture options
                    CMP_CAPTURE_VIDEO_OPTIONS options = new CMP_CAPTURE_VIDEO_OPTIONS();
                    options.CameraSelection = CMP_CAPTURE_CAMERA.CMP_CAPTURE_CAMERA_DEFAULT;    // Can be used to specify a specific camera (front or back).
                    options.Encoding = CMP_VIDEO_ENCODING.CMP_VIDEO_ENCODING_3GPP;              // Will try to use specifed encoding, otherwise client default.
                    options.Quality = CMP_CAPTURE_QUALITY.CMP_CAPTURE_QUALITY_MAXIMUM;
                    options.DurationLimit = 30;     // Limit of time in seconds (0 = no limit)
                    //options.DesiredHeight = 1280; // Desired pixel height (0 = no desired height)
                    //options.DesiredWidth = 720;   // Unset options will use the client default.

                    // capture a video
                    rc = CaptureVideo(ref options);

                    if (CMP_SUCCESS(rc))
                    {
                        // Block and wait for the capture event to arrive and processed.
                        // The wait will timeout in 60 seconds.
                        // The video is processed in the event handler and captureProcessed 
                        // is signalled once complete.
                        captureProcessed.WaitOne(60000);
                    }
                    else
                    {
                        // report an error with capture
                        ReportError(rc);
                    }

                    Thread.Sleep(10000);
                }
                else
                {
                    Console.WriteLine("OpenSession failed rc={0:X}", rc);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }

        /// <summary>
        /// Check CMP return code for success.
        /// </summary>
        static bool CMP_SUCCESS(CMPRESULT rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        //! [eventhandler]
        // <summary>
        // VideoCaptured event handler.
        // </summary>
        // <param name="result">Capture result.</param>
        // <param name="uniqueId">Capture identifier.</param>
        // <param name="videoMetadata">Capture metadata filename.</param>
        // <param name="filename">Capture filename.</param>
        // <param name="videoSize">Capture size.</param>
        // <param name="Quality">Capture quality.</param>
        // <param name="CameraSelection">Camera selected.</param>
        // <param name="Encoding">Capture encoding.</param>
        // <param name="DesiredWidth">Capture width.</param>
        // <param name="DesiredHeight">Capture height.</param>
        // <param name="DurationLimit">Capture duration limit.</param>
        static void cmp_VideoCaptured(
            CMPRESULT result,
            CMP_UNIQUE_LONG_ID uniqueId,
            string videoMetadata,
            string filename,
            int videoSize,
            CMP_CAPTURE_QUALITY Quality,
            CMP_CAPTURE_CAMERA CameraSelection,
            CMP_VIDEO_ENCODING Encoding,
            int DesiredWidth,
            int DesiredHeight,
            int DurationLimit)
        {
            // only process capture if it is one of ours
            if (uniqueId == CaptureId)
            {
                Console.WriteLine("Capture event\n");

                if (CMP_SUCCESS(result))
                {
                    // Copy the relevant data and then signal the event
                    videoData.result = result;
                    videoData.captureId = uniqueId;
                    videoData.videoMetadata = videoMetadata;
                    videoData.filename = filename;
                    videoData.videoSize = videoSize;

                    CMP_CAPTURE_VIDEO_OPTIONS options = new CMP_CAPTURE_VIDEO_OPTIONS();
                    options.Quality = Quality;
                    options.CameraSelection = CameraSelection;
                    options.Encoding = Encoding;
                    options.DesiredWidth = DesiredWidth;
                    options.DesiredHeight = DesiredHeight;
                    options.DurationLimit = DurationLimit;

                    videoData.options = options;

                    Console.WriteLine("Capture result({0:X}) id({1:X}) size({3:X}) filename(4) videoMetadata(5)\n",
                                        result, uniqueId, videoSize, filename, videoMetadata);
                    Console.WriteLine("Capture options Quality(0) CameraSelection(1) Encoding(2) DesiredWidth(3) DesiredHeight(4) DurationLimit(5)\n",
                                        Quality.ToString(), CameraSelection.ToString(), Encoding.ToString(), DesiredWidth, DesiredHeight, DurationLimit);

                    //Save the capture to the local temporary directory (keeping the same file name and extension).
                    string newLocation = System.IO.Path.GetTempPath() + System.IO.Path.GetFileName(filename);

                    Console.WriteLine("CMPGetFilename mobileFilename({0}) newLocation({1})", filename, newLocation);

                    Console.WriteLine("Copying file..\n");

                    File.Copy(filename, newLocation, true);

                    Console.WriteLine("Copy succeeded\n");

                    Console.WriteLine("Opening file in default application...\n");
                    System.Diagnostics.Process.Start(newLocation);
                }
                
                captureProcessed.Set();
            }
        }
        //! [eventhandler]

        // <summary>
        // Register for video capture event
        // </summary>
        static void RegisterForEvent()
        {
            Console.WriteLine("Hooking video capture event");

            //! [eventsubscription]
            // Subscribed VideoCaptured event.
            cmp.VideoCaptured += new ICMPEvents_VideoCapturedEventHandler(cmp_VideoCaptured);
            //! [eventsubscription]
        }

        // <summary>
        // Request a video capture
        // </summary>
        static CMPRESULT CaptureVideo(ref CMP_CAPTURE_VIDEO_OPTIONS options)
        {
            CMPRESULT rc;

            Console.WriteLine("Request a video capture");

            //! [capturevideo]
            // Request a video capture
            rc = cmp.CaptureVideo(ref options, out CaptureId);
            //! [capturevideo]

            Console.WriteLine("Video capture request sent");

            return (rc);
        }

        // <summary>
        // Report an error with relation to VideoCapture
        // </summary>
        static void ReportError(CMPRESULT rc)
        {
            CMP_ERROR_ID err = (CMP_ERROR_ID)rc;

            Console.WriteLine("Error {0:X} with CaptureVideo", rc);

            switch (err)
            {
                case CMP_ERROR_ID.CMP_ERROR_CLIENT_DRIVE_UNAVAILABLE:
                    Console.WriteLine("Client Drive unavailable. Check session options on Receiver.");
                    break;
                case CMP_ERROR_ID.CMP_ERROR_CAPABILITY_NOT_SUPPORTED:
                    Console.WriteLine("This device does not support video capture.");
                    break;
                default:
                    break;
            }
        }

    }
}
