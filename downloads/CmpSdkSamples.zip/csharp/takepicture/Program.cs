﻿// C# Take picture example using Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to take a picture and transfer it to server.
//
// Copyright (c) 2012 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.Linq;
using CitrixMobility;
using System.Collections;
using System.Threading;
using System.IO;

using CMPRESULT     = System.Int32;
using CMP_UNIQUE_ID = System.Int32;

namespace takepicture
{
    static class Program
    {
        struct PICTURE_DATA
        {
            public CMPRESULT pictureResult;
            public CMP_UNIQUE_ID pictureId;
            public CMP_IMAGE_FORMAT pictureFormat;
            public int pictureSize;
            public string filename;

            public PICTURE_DATA(CMPRESULT result, CMP_UNIQUE_ID id, CMP_IMAGE_FORMAT format, int size, string name)
            {
                pictureResult = result;
                pictureId = id;
                pictureFormat = format;
                pictureSize = size;
                filename = name;
            }
        };

        const CMP_UNIQUE_ID PictureId = 0x64019121;
        static CitrixMobile cmp;
        static PICTURE_DATA pictureData;
        static AutoResetEvent pictureProcessed = new AutoResetEvent(false);


        [MTAThread]
        static void Main()
        {
            // Picture event data
            pictureData = new PICTURE_DATA((CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR, 0, (CMP_IMAGE_FORMAT)0, 0, null);

            CMPRESULT rc = (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Console.WriteLine("Creating CitrixMobile object.");

                // Creates the CitrixMobile Object which contains all the CMP interfaces. e.g. IButton, ICamera
                cmp = new CitrixMobile();

                Console.WriteLine("Calling OpenSession.");

                // Opens a connection to the remote mobile device
                // It is good practice to close the operation when no longer needed 
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    // register for picture taken event
                    RegisterForEvent();

                    // take a picture
                    rc = TakePicture();

                    if (CMP_SUCCESS(rc))
                    {
                        bool completed;

                        Console.WriteLine("Starting wait for take picture event.  Could last for 60 seconds.");

                        // Block and wait for the picture taken event to arrive and processed.
                        // The wait will timeout in 60 seconds.
                        // The picture is processed in the event handler and pictureProcessed 
                        // is signalled once complete.
                        completed = pictureProcessed.WaitOne(60000);

                        if (completed)
                        {
                            Console.WriteLine("TakePicture completed. Event received.");
                        }
                        else
                        {
                            Console.WriteLine("Picture was not received in time.");
                        }
                    }
                    else
                    {
                        // report an error with take picture
                        ReportError(rc);
                    }
                }
                else
                {
                    Console.WriteLine("OpenSession failed rc={0:X}.", rc);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }

        /// <summary>
        /// Check CMP return code for success.
        /// </summary>
        static bool CMP_SUCCESS(CMPRESULT rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        //! [eventhandler]
        // <summary>
        // PictureTaken event handler.
        // </summary>
        // <param name="result">Picture result.</param>
        // <param name="pictureId">Picture identifier.</param>
        // <param name="pictureFormat">Picture format.</param>
        // <param name="pictureSize">Picture size.</param>
        // <param name="filename">Picture filename.</param>
        static void cmp_PictureTaken(
            CMPRESULT result,
            CMP_UNIQUE_ID pictureId,
            CMP_IMAGE_FORMAT pictureFormat,
            int pictureSize,
            string filename)
        {
            // only process picture if it is one of ours
            if (pictureId == PictureId)
            {
                Console.WriteLine("PictureTaken event\n");

                // Copy the relevant data and then signal the event
                pictureData.pictureResult   = result;
                pictureData.pictureId       = pictureId;
                pictureData.pictureFormat   = pictureFormat;
                pictureData.pictureSize     = pictureSize;
                pictureData.filename        = filename;

                Console.WriteLine("Picture result({0:X}) id({1:X}) format({2:X}) size({3:X}) filename(4)\n",
                                   result, pictureId, pictureFormat, pictureSize, filename);

                if (CMP_SUCCESS(pictureData.pictureResult))
                {
                    Console.WriteLine("Picture id({0:X}) format({1:X}) size({2:X}) filename({3})\n",
                                      pictureData.pictureId, pictureData.pictureFormat,
                                      pictureData.pictureSize, pictureData.filename);

                    // Saves the image as "img.jpg" in the "C:\photos" directory.
                    // Directory needs to be created beforehand.
                    string newLocation = "C:\\photos\\img.jpg";

                    Console.WriteLine("CMPGetPictureFilename mobileFilename({0}) newLocation({1})", filename, newLocation);

                    Console.WriteLine("Copying file..\n");

                    File.Copy(filename, newLocation, true);

                    Console.WriteLine("Copy succeeded\n");

                    pictureProcessed.Set();
                }
            }
        }
        //! [eventhandler]

        // <summary>
        // Register for picture taken event
        // </summary>
        static void RegisterForEvent()
        {
            Console.WriteLine("Hooking picture taken event");

            //! [eventsubscription]
            // Subscribed PictureTaken event.
            cmp.PictureTaken += new ICMPEvents_PictureTakenEventHandler(cmp_PictureTaken);
            //! [eventsubscription]
        }

        // <summary>
        // Request a picture to be taken
        // </summary>
        static CMPRESULT TakePicture()
        {
            CMPRESULT rc;

            // Request a picture to be taken.
            Console.WriteLine("Request a picture to be taken");

            //! [takepicture]
            // Request a JPEG picture to be taken.
            rc = cmp.TakePicture(CMP_IMAGE_FORMAT.CMP_IMAGE_FORMAT_JPEG, PictureId);
            //! [takepicture]

            Console.WriteLine("Take picture request Sent");

            return (rc);
        }

        // <summary>
        // Report an error with relation to TakePicture
        // </summary>
        static void ReportError(CMPRESULT rc)
        {
            CMP_ERROR_ID err = (CMP_ERROR_ID)rc;

            Console.WriteLine("Error {0:X} {1} with TakePicture", rc, err.ToString());

            switch (err)
            {
                case CMP_ERROR_ID.CMP_ERROR_CLIENT_DRIVE_UNAVAILABLE:
                    Console.WriteLine("Client Drive unavailable. Check session options on Receiver.");
                    break;

                default:
                    break;
            }
        }

    }
}
