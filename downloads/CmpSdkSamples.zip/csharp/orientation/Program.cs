﻿// C# Orientation example using with Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to display and change orientation
//
// Copyright (c) 2012 Citrix Systems
//
using System;
using System.Collections.Generic;
using System.Linq;
using CitrixMobility;
using System.Threading;

using CMPRESULT = System.Int32;

namespace orientation
{
    static class Program
    {
        //
        // A Lookup Table of the device's orientation states
        //
        static Dictionary<CMP_ORIENTATION_POSITION, string> OrientationToName = new Dictionary<CMP_ORIENTATION_POSITION, string>()
        {
            {CMP_ORIENTATION_POSITION.CMP_ORIENTATION_UNKNOWN, "Orientation is UNKNOWN"},
            {CMP_ORIENTATION_POSITION.CMP_ORIENTATION_PORTRAIT, "Orientation is PORTRAIT"},
            {CMP_ORIENTATION_POSITION.CMP_ORIENTATION_PORTRAIT_UPSIDE_DOWN, "Orientation is PORTRAIT UPSIDE DOWN"},
            {CMP_ORIENTATION_POSITION.CMP_ORIENTATION_LANDSCAPE_LEFT, "Orientation is LANDSCAPE LEFT"},
            {CMP_ORIENTATION_POSITION.CMP_ORIENTATION_LANDSCAPE_RIGHT, "Orientation is LANDSCAPE RIGHT"},
        };

        static CitrixMobile cmp;

        [STAThread]
        static void Main()
        {
            //initialise result to "No Error"
            CMPRESULT rc = (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Console.WriteLine("Creating CitrixMobile object");

                // Creates the CitrixMobile Object which contains all the CMP interfaces. e.g. IButton, ICamera
                cmp = new CitrixMobile();

                Console.WriteLine("Calling OpenSession");

                // Opens a connection to the remote mobile device
                // It is good practice to close the operation when no longer needed 
                rc = cmp.OpenSession();

                if(CMP_SUCCESS(rc))
                {
                    CMP_ORIENTATION_DATA orientationData;
                        
                    Console.WriteLine("Hooking orientationData state changed event");

                    // register for orientation changed event
                    RegisterForEvent();

                    Console.WriteLine("CMP Getting orientation");

                    rc = GetOrientation(out orientationData);

                    if(CMP_SUCCESS(rc))
                    {
                        // If successful, prints information of the current orientation of the device
                         ReportOrientation("\nGetOrientation\n", orientationData);
                    }
                    
                    Console.WriteLine("\nRotate the device to test the orientation changed event\n");
                    
                    // Let events come in over the next 15 seconds
                    // If this was a Windows program and we had a message loop, we would not need to do this
                    WaitForCMPEvents(15);
                    
                    // Now lock the orientation to LANDSCAPE LEFT
                    Console.WriteLine("\nOrientation being unlocked to follow the device orientation\n");

                    // Calls the CMP SetOrientation method which receives "CMP Orientation Position" and the "Orientation Flag"
                    // and manually sets it to Orientation Position(Landscape Left) and Orientation Flag(Orientation Locked)
                    rc = cmp.SetOrientation(CMP_ORIENTATION_POSITION.CMP_ORIENTATION_LANDSCAPE_LEFT, 
                                            (short)CMP_ORIENTATION_FLAG.CMP_ORIENTATION_FLAG_LOCK);

                    Console.WriteLine("Locked the orientation to LANDSCAPE_LEFT\n");

                    //Gets the current orientation of the device and stores it in the variable "orientationData"
                    rc = GetOrientation(out orientationData);
                    
                    Console.WriteLine("Verifying orientation changed to LANDSCAPE_LEFT\n");
                    
                    if(CMP_SUCCESS(rc))
                    {
                        // If successful, prints information of the current orientation of the device
                        ReportOrientation("\nGetOrientation\n", orientationData);
                    }

                    Console.WriteLine("\nRotate the device to test that the application orientation locked\n");

                    // Let events come in over the next 15 seconds
                    WaitForCMPEvents(15);

                    // Unlock the orientation
                    Console.WriteLine("\nOrientation being unlocked to follow the device orientation\n");

                    rc = cmp.SetOrientation(CMP_ORIENTATION_POSITION.CMP_ORIENTATION_LANDSCAPE_LEFT, 
                         (short)CMP_ORIENTATION_FLAG.CMP_ORIENTATION_FLAG_FOLLOW_SENSOR);

                    // Long waiting time used only for test purposes (two minutes)
                    WaitForCMPEvents(120);
                }
                else
                {
                    Console.WriteLine("OpenSession failed rc={0:X}", rc);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }
        /// <summary>
        /// Check CMP return code for success.
        /// </summary>
        static bool CMP_SUCCESS(CMPRESULT rc)
        {
            // Need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        //! [eventhandler]
        // <summary>
        // OrientationChanged event handler
        // </summary>
        // <param name="rc">Return code.</param>
        // <param name="DeviceOrientation">Device's orientation.</param>
        // <param name="AppOrientation">Application's orientation.</param>
        // <param name="OrientationFlags">Orientation flags.</param>
        static void cmp_OrientationChanged(
            Int32 rc,
            CMP_ORIENTATION_POSITION DeviceOrientation,
            CMP_ORIENTATION_POSITION AppOrientation,
            short OrientationFlags)
        {
            CMP_ORIENTATION_DATA orientationData;

            // Storing the device's current orientation information into the "Orientation Data" object
            orientationData.DeviceOrientation = (short)DeviceOrientation;
            orientationData.AppOrientation = (short)AppOrientation;
            orientationData.OrientationFlags = OrientationFlags;

            ReportOrientation("\nOrientationChanged event\n", orientationData);
        }
        //! [eventhandler]

        //
        // Prints the orientation data (the status of the device's orientation)
        //
        static void ReportOrientation(string prefix, CMP_ORIENTATION_DATA orientationData)
        {
            UInt16 flags = (ushort)orientationData.OrientationFlags;
            CMP_ORIENTATION_POSITION deviceOrientation = (CMP_ORIENTATION_POSITION)orientationData.DeviceOrientation;
            CMP_ORIENTATION_POSITION appOrientation = (CMP_ORIENTATION_POSITION)orientationData.AppOrientation;

            if (prefix != null)
            {
                Console.WriteLine(prefix);
            }

            // Prints the orientation information 
            Console.WriteLine("DeviceOrientation ({0:X})\n", GetOrientationName(deviceOrientation));
            Console.WriteLine("AppOrientation ({0:X})\n", GetOrientationName(appOrientation));
            Console.WriteLine("Flags ({0:X})\n", flags);

            // Prints if device orientation is locked
            if (flags == (ushort)CMP_ORIENTATION_FLAG.CMP_ORIENTATION_FLAG_LOCK)
            {
                Console.WriteLine("CMP_ORIENTATION_FLAG_LOCK");
                Console.WriteLine("Device is LOCKED");
            }

            // Prints if device orientation is unlocked (following device's orientaion sensor)
            if (flags == (ushort)CMP_ORIENTATION_FLAG.CMP_ORIENTATION_FLAG_FOLLOW_SENSOR)
            {
                Console.WriteLine("CMP_ORIENTATION_FLAG_FOLLOW_SENSOR");
                Console.WriteLine("Device is UNLOCKED");
            }

            Console.WriteLine("\n");
        }

        //
        // Convert orientation to name (string)
        //
        static string GetOrientationName(CMP_ORIENTATION_POSITION orientation)
        {
            string name = null;

            // Checks the orientation lookup table 
            if (OrientationToName.ContainsKey(orientation))
            {
                // Converts orientation data into text
                name = OrientationToName[orientation];
            }

            return name;
        }

        //
        // A "wait" method which allows events to occur
        //
        static void WaitForCMPEvents(int seconds)
        {
            for (int i = 0; i < seconds; i++)
            {
                Thread.Sleep(1000);
            }
        }

        /// <summary>
        /// Register for orientation changed event
        /// </summary>
        static void RegisterForEvent()
        {
            //! [eventsubscription]
            // Subscribe to OrientationChanged event.
            cmp.OrientationChanged += new ICMPEvents_OrientationChangedEventHandler(cmp_OrientationChanged);
            //! [eventsubscription]
        }

        /// <summary>
        /// Get the current orientation
        /// </summary>
        static CMPRESULT GetOrientation(out CMP_ORIENTATION_DATA orientationData)
        {
            CMPRESULT rc;

            //! [getorientation]
            // Gets the current orientation of the device
            // and stores the data into the object "orientationData".
            rc = cmp.GetOrientation(out orientationData);
            //! [getorientation]

            return (rc);
        }
    }
}
