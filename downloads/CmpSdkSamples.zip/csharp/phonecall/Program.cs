﻿// C# Phone Call example using Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to start a phone call
//
// Copyright (c) 2012 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.Linq;
using CitrixMobility;
using System.Threading;

using CMPRESULT     = System.Int32;
using CMP_UNIQUE_ID = System.Int32;

namespace phonecall
{
    class Program
    {
        // Intialise phone number (random)
        const string phoneNumber = "+18005551212";

        // Initialise call id (random)
        const CMP_UNIQUE_ID phoneCallId = 0x22654321;

        static CitrixMobile cmp;

        [STAThread]
        static void Main()
        {
            // Initialise result to "No Error"
            CMPRESULT rc = (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Console.WriteLine("Creating CitrixMobile object");

                // Creates the CitrixMobile Object which contains all the CMP interfaces. e.g. IButton, ICamera
                cmp = new CitrixMobile();

                Console.WriteLine("Calling OpenSession");

                // Opens a connection to the remote mobile device
                // It is good practice to close the operation when no longer needed 
                rc = cmp.OpenSession();

                if(CMP_SUCCESS(rc))
                {
                    // register for the phone call started event
                    RegisterForEvent();

                    // make the phone call
                    StartPhoneCall();

                    // Loop for thirty seconds to allow for events to happen
                    for (int i = 0; i < 30; i++ )
                    {
                        Thread.Sleep(1000);
                    }
                }
                else
                {
                    Console.WriteLine("OpenSession failed rc={0:X}", rc);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }

        //! [eventhandler]
        // <summary>
        // PhoneCallStarted event handler.
        // </summary>
        // <param name="rc">Return code.</param>
        // <param name="PhoneCallId">Phone call identifier.</param>
        static void cmp_PhoneCallStarted(CMPRESULT rc, CMP_UNIQUE_ID PhoneCallId)
        {
            Console.WriteLine("Phone call started rc({0:X}) PhoneCallId({1:X})", rc, PhoneCallId);

            // only proceed if call is one of ours
            if (PhoneCallId == phoneCallId)
            {
                // Do something...
            }
        }
        //! [eventhandler]

        //
        // Checks if there is an error
        //
        static bool CMP_SUCCESS(CMPRESULT rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        /// <summary>
        /// Register for phone call started event
        /// </summary>
        static void RegisterForEvent()
        {
            Console.WriteLine("Hooking phone call started event");

            //! [eventsubscription]
            // Subscribe to PhoneCallStarted event.
            cmp.PhoneCallStarted += new ICMPEvents_PhoneCallStartedEventHandler(cmp_PhoneCallStarted);
            //! [eventsubscription]
        }

        /// <summary>
        /// Start the phone call
        /// </summary>
        static CMPRESULT StartPhoneCall()
        {
            CMPRESULT rc;

            Console.WriteLine("CMP Start Call");

            //! [startphonecall]
            // Start the phone call process by popping up the dialer with the number already populated.
            rc = cmp.StartPhoneCall(phoneNumber, phoneCallId);
            //! [startphonecall]

            return (rc);
        }

    }
}
