﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LocationApiLib;
using System.Threading;
using System.Runtime.InteropServices;

namespace location
{
    class Program
    {
        //! [ilocation]
        // Define ILocation interface
        static private ILocation location;
        //! [ilocation]

        static void Main(string[] args)
        {
            Console.WriteLine("Starting C# Console location sample.");

            location = new Location();

            LocationThreadRunner();
        }

        static private void LocationThreadRunner()
        {
            //There are two kinds of location available Latitude / Longitude
            //information, and Civic address information.
            //You use GUIDS to specify which one you want.
            //These GUIDs are specified in the LocationApi.h
            //files in the Windows SDK.
            Console.WriteLine("Creating GUIDS needed to specify the kind of information we want.");

            //! [guid]
            String IID_LatLongReportString = "7FED806D-0EF8-4f07-80AC-36A0BEAE3134";
            Guid IID_LatLongReport = new Guid(IID_LatLongReportString);

            String IID_CivicAddressReportString = "C0B19F70-4ADF-445d-87F2-CAD8FD711792";
            Guid IID_CivicAddressReport = new Guid(IID_CivicAddressReportString);
            //! [guid]

            Console.WriteLine("Working out the status now of lat long.");
            //! [latlongstatus]
            //Work out what our latlong report status is.
            LOCATION_REPORT_STATUS locStatus = location.GetReportStatus(ref IID_LatLongReport);
            //! [latlongstatus]
            if (locStatus == LOCATION_REPORT_STATUS.REPORT_RUNNING)
            {
                Console.WriteLine("Lat long information is running.");

                //Now go and actually find out our latitude and longitude.
                try
                {
                    //! [getlatlongreport]
                    // Get latlong report
                    ILatLongReport latLongReport = (ILatLongReport)location.GetReport(ref IID_LatLongReport);

                    Console.WriteLine("Retrieved latitude and longitude.");
                    //Once we have a report, we just extract the data from the object.
                    double latitude = latLongReport.GetLatitude();
                    double longitude = latLongReport.GetLongitude();
                    double errorRadius = latLongReport.GetErrorRadius();
                    _SYSTEMTIME timestamp = latLongReport.GetTimestamp();
                    //! [getlatlongreport]

                    StringBuilder buffer = new StringBuilder();
                    buffer.Append("You are at ");
                    buffer.Append(latitude);
                    buffer.Append(", ");
                    buffer.Append(longitude);
                    buffer.Append(" with an error radius of ");
                    buffer.Append(errorRadius);
                    buffer.Append(" metres.");
                    Console.WriteLine(buffer.ToString());

                }
                catch (COMException e)
                {
                    Console.WriteLine("Got exception retrieving lat long information." + e.ToString());
                }
            }
            else
            {
                Console.WriteLine("Lat long report information is not available, as status is " + locStatus);
            }

            //! [civicsstatus]
            //Work out what our civic address report status is.
            locStatus = location.GetReportStatus(ref IID_CivicAddressReport);
            //! [civicsstatus]
            if (locStatus == LOCATION_REPORT_STATUS.REPORT_RUNNING)
            {
                //We do exactly the same thing to retrieve civic address information.
                try
                {
                    //! [getcivicreport]
                    //Get civic address report
                    ICivicAddressReport civicReport = (ICivicAddressReport)location.GetReport(ref IID_CivicAddressReport);
                    Console.WriteLine("Retrieved civic information.");

                    //Once we have a report, we just extract the data from the object.
                    StringBuilder buffer = new StringBuilder();

                    // Extract the civic address information
                    buffer.Append("You are at ");
                    if (civicReport.GetAddressLine1() != null)
                    {
                        buffer.Append(civicReport.GetAddressLine1());
                        buffer.Append(", ");
                    }
                    if (civicReport.GetAddressLine2() != null)
                    {
                        buffer.Append(civicReport.GetAddressLine2());
                        buffer.Append(", ");
                    }
                    if (civicReport.GetCity() != null)
                    {
                        buffer.Append(civicReport.GetCity());
                        buffer.Append(", ");
                    }
                    if (civicReport.GetStateProvince() != null)
                    {
                        buffer.Append(civicReport.GetStateProvince());
                        buffer.Append(", ");
                    }
                    if (civicReport.GetPostalCode() != null)
                    {
                        buffer.Append(civicReport.GetPostalCode());
                        buffer.Append(", ");
                    }
                    if (civicReport.GetCountryRegion() != null)
                    {
                        buffer.Append(civicReport.GetCountryRegion());
                        buffer.Append(".");
                    }
                    //! [getcivicreport]
                    Console.WriteLine(buffer.ToString());

                    for (int i = 0; i < 30; i++)
                    {
                        Thread.Sleep(1000);
                    }

                }
                catch (COMException e)
                {
                    Console.WriteLine("Got exception retrieving civic information." + e.ToString());
                }
            }
            else
            {
                Console.WriteLine("Civic report information is not available, as status is " + locStatus);
            }
        }
    }
}
