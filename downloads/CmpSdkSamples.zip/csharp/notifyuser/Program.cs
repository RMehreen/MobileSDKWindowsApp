﻿// C# Notify User example using Citrix Mobility Pack SDK
//
// Uses Citrix Mobility Pack SDK to send a notification to the user of the mobile device.
//
// Copyright (c) 2012 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CitrixMobility;
using System.Threading;

using CMPRESULT     = System.Int32;
using CMP_UNIQUE_ID = System.Int32;

namespace notifyuser
{
    class Program
    {
        // Flags for notification types (Type library did not pick up the notification flags available in COM).
        const short CMP_NOTIFICATION_FLAG_LIGHT     = 0x0001;
        const short CMP_NOTIFICATION_FLAG_VIBRATE   = 0x0002;
        const short CMP_NOTIFICATION_FLAG_AUDIO     = 0x0004;
        const short CMP_NOTIFICATION_FLAG_TEXT      = 0x0008;

        // Application specific unique notification ID.
        const CMP_UNIQUE_ID NotifyId = 0x12344321;

        static CitrixMobile cmp;

        [STAThread]
        static void Main(string[] args)
        {
            CMPRESULT rc = (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Console.WriteLine("Creating CitrixMobile object");
                cmp = new CitrixMobile();

                Console.WriteLine("Calling OpenSession");
                rc = cmp.OpenSession();

                // need to mask the result since the top half can have the component Id
                if (CMP_SUCCESS(rc))
                {
                    Console.WriteLine("hooking events");

                    // register for the user notified event
                    RegisterForEvent();

                    // notify the user
                    rc = NotifyUser();

                    if (CMP_SUCCESS(rc))
                    {
                        Console.WriteLine("Notification was sent");
                    }
                    else
                    {
                        Console.WriteLine("NotifyUser failed rc={0:X}", rc);
                    }

                    // loop for thirty seconds to allow for events to happen
                    for (int i = 0; i < 30; i++)
                    {
                        Thread.Sleep(1000);
                    }
                }
                else
                {
                    Console.WriteLine("OpenSession failed rc={0:X}", rc);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }

        // <summary>
        // Register for user notified event
        // </summary>
        static void RegisterForEvent()
        {
            //! [eventsubscription]
            // Subscribe to UserNotified event.
            cmp.UserNotified += new ICMPEvents_UserNotifiedEventHandler(cmp_UserNotified);
            //! [eventsubscription]
        }

        //! [eventhandler]
        // <summary>
        // UserNotified event handler.
        // </summary>
        // <param name="rc">Return code.</param>
        // <param name="NotificationId">Notification identifier.</param>
        static void cmp_UserNotified(int rc, int NotificationId)
        {
            Console.WriteLine("UserNotified rc:{0:X} NotifyId:{1:X}", rc, NotificationId);

            // In this example, the value of NotificationId will be 0x12344321.
            if (NotificationId == NotifyId)
            {
                // Do something...
            }
        }
        //! [eventhandler]

        // <summary>
        // Check CMP return code for success.
        // </summary>
        static bool CMP_SUCCESS(CMPRESULT rc)
        {
            // Need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        // <summary>
        // Notify the user
        // </summary>
        static CMPRESULT NotifyUser()
        {
            CMPRESULT rc;

            //! [usernotified]
            // Send a notification with an identifier of NotifyId = 0x12344321.
            //
            // Flags for notification type:
            //
            //  CMP_NOTIFICATION_FLAG_LIGHT     = 0x0001;
            //  CMP_NOTIFICATION_FLAG_VIBRATE   = 0x0002;
            //  CMP_NOTIFICATION_FLAG_AUDIO     = 0x0004;
            //  CMP_NOTIFICATION_FLAG_TEXT      = 0x0008;

            Console.WriteLine("Exercising light notification.");
            rc = cmp.NotifyUser(NotifyId, CMP_NOTIFICATION_FLAG_LIGHT, string.Empty);
            waitForEvents(3);

            Console.WriteLine("Exercising vibrate notification.");
            rc = cmp.NotifyUser(NotifyId, CMP_NOTIFICATION_FLAG_VIBRATE, string.Empty);
            waitForEvents(3);

            Console.WriteLine("Exercising audio notification.");
            rc = cmp.NotifyUser(NotifyId, CMP_NOTIFICATION_FLAG_AUDIO, string.Empty);
            waitForEvents(3);

            Console.WriteLine("Exercising text notification.");
            rc = cmp.NotifyUser(NotifyId, CMP_NOTIFICATION_FLAG_TEXT, "You have been notified via text.");
            waitForEvents(3);

            Console.WriteLine("Exercising vibrate notification with text.");
            rc = cmp.NotifyUser(NotifyId, CMP_NOTIFICATION_FLAG_VIBRATE | CMP_NOTIFICATION_FLAG_TEXT,
                                "You have been notified via vibrate and text.");
            waitForEvents(3);
            //! [usernotified]

            return (rc);
        }

        // <summary>
        // Waits for required number of seconds
        //  </summary>
        // <param name="delay">seconds</param>
        private static void waitForEvents(int delay)
        {
            for (int i = 0; i < delay; i++)
            {
                Thread.Sleep(1000);
            }
        }
    }
}

