﻿// C# Send SMS example using COM Interop with Citrix Mobility SDK
//
// Uses Citrix Mobility SDK to start a SMS
//
// Copyright (c) 2012 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.Linq;
using CitrixMobility;
using System.Threading;

using CMPRESULT     = System.Int32;
using CMP_UNIQUE_ID = System.Int32;

namespace sendsms
{
    static class Program
    {
        // Initialise a phone number (random)
        const string phoneNumber = "+18005551212";

        // Initialise SMS id (random)
        const CMP_UNIQUE_ID SMSId = 0x22654321;

        // Initialise a text for the sms
        const string SMSText = "This is text to be sent with the SMS";

        static CitrixMobile cmp;

        [STAThread]
        static void Main()
        {
            // Initialise result to "No Error"
            CMPRESULT rc = (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Console.WriteLine("Creating CitrixMobile object");

                // Creates the CitrixMobile Object which contains all the CMP interfaces. e.g. IButton, ICamera
                cmp = new CitrixMobile();

                Console.WriteLine("Calling OpenSession");

                // Opens a connection to the remote mobile device
                // It is good practice to close the operation when no longer needed 
                rc = cmp.OpenSession();

                if(CMP_SUCCESS(rc))
                {
                    Console.WriteLine("Hooking SMS changed event");

                    // register for sms started event
                    RegisterForEvent();

                    // send a SMS
                    rc = SendSMS();

                    if (CMP_SUCCESS(rc))
                    {
                        // Loop for thirty seconds to allow for events to happen
                        for (int i = 0; i < 30; i++)
                        {
                            Thread.Sleep(1000);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("OpenSession failed rc={0:X}", rc);
                }
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }

        //! [eventhandler]
        // <summary>
        // SMSStarted event handler.
        // </summary>
        // <param name="rc">Return code.</param>
        // <param name="SMSId">SMS identifier.</param>
        static void cmp_SMSStarted(CMPRESULT rc, CMP_UNIQUE_ID smsId)
        {
            Console.WriteLine("SMS started rc({0:X}) SMSId({1:X})", rc, smsId);

            //only proceed if sms is one of ours
            if (SMSId == smsId)
            {
                // Do something...
            }
        }
        //! [eventhandler]

        /// <summary>
        /// Check CMP return code for success.
        /// </summary>
        static bool CMP_SUCCESS(CMPRESULT rc)
        {
            // Need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (CMPRESULT)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        /// <summary>
        /// Register for SMS started event
        /// </summary>
        static void RegisterForEvent()
        {
            //! [eventsubscription]
            // Subscribed SMSStarted event.
            cmp.SMSStarted += new ICMPEvents_SMSStartedEventHandler(cmp_SMSStarted);
            //! [eventsubscription]
        }

        /// <summary>
        /// Send a SMS
        /// </summary>
        static CMPRESULT SendSMS()
        {
            CMPRESULT rc;

            Console.WriteLine("CMP Send SMS");

            //! [sendsms]
            // Start the SMS process by popping up the SMS screen with the phone number already populated
            rc = cmp.SendSMS(phoneNumber, SMSId, SMSText);
            //! [sendsms]

            return (rc);
        }
    }
}
