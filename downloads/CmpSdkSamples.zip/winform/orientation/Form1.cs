﻿// C# Orientation example using COM Interop with Citrix Mobility SDK
//
// Uses Citrix Mobility SDK to display and change orientation
//
// Copyright (c) 2012 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CitrixMobility;
using System.Threading;

namespace orientation
{
    public partial class Form1 : Form
    {
        // <summary>
        // Instance of CitrixMobile.
        // </summary>
        private CitrixMobile cmp = null;

        // <summary>
        // ICA session connected state.
        // </summary>
        private bool icaSessionConnected = false;

        // <summary>
        // Check CMP return code for success.
        // </summary>
        private bool CMP_SUCCESS(int rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (int)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        // <summary>
        // Dispatch action to UI thread if necessary.
        // </summary>
        // <param name="action">The action.</param>
        private void UiDispatch(Action action)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(action);
            }
            else
            {
                action();
            }
        }

        // <summary>
        // Report CMP status.
        // </summary>
        // <param name="text">Status text.</param>
        // <param name="rc">CMP return code.</param>
        private void ReportStatus(string text, int rc)
        {
            // Only report status if something went wrong.
            if (!CMP_SUCCESS(rc))
            {
                string msg = string.Format("{0}, CMPResult: 0x{1:X}", text, rc);

                // Write to trace output.
                Helpers.Trace(msg);
                // Update status text.
                UiDispatch(() => this.status.Text = msg);
            }
        }

        // <summary>
        // A Lookup Table of the device's orientation states
        // </summary>
        private Dictionary<CMP_ORIENTATION_POSITION, string> OrientationToName = new Dictionary<CMP_ORIENTATION_POSITION, string>()
        {
            {CMP_ORIENTATION_POSITION.CMP_ORIENTATION_UNKNOWN, "UNKNOWN"},
            {CMP_ORIENTATION_POSITION.CMP_ORIENTATION_PORTRAIT, "PORTRAIT"},
            {CMP_ORIENTATION_POSITION.CMP_ORIENTATION_PORTRAIT_UPSIDE_DOWN, "PORTRAIT UPSIDE DOWN"},
            {CMP_ORIENTATION_POSITION.CMP_ORIENTATION_LANDSCAPE_LEFT, "LANDSCAPE LEFT"},
            {CMP_ORIENTATION_POSITION.CMP_ORIENTATION_LANDSCAPE_RIGHT, "LANDSCAPE RIGHT"},
        };

        // <summary>
        // Convert orientation to string.
        // </summary>
        // <param name="orientation">CMP_ORIENTATION_POSITION to retrieve name for.</param>
        // <returns>Orientation name.</returns>
        private string GetOrientationName(CMP_ORIENTATION_POSITION orientation)
        {
            string name = OrientationToName[CMP_ORIENTATION_POSITION.CMP_ORIENTATION_UNKNOWN];

            // Checks the orientation lookup table.
            if (OrientationToName.ContainsKey(orientation))
            {
                // Converts orientation data into text.
                name = OrientationToName[orientation];
            }

            return name;
        }

        //! [lockorientation]
        // <summary>
        // Set the device orientation.
        // </summary>
        // <param name="lockOrientation">Orientation lock state.</param>
        private void LockOrientation(bool lockOrientation)
        {
            // Get the device's current orientation information. 
            CMP_ORIENTATION_DATA orientationData;
            cmp.GetOrientation(out orientationData);

            cmp.SetOrientation((CMP_ORIENTATION_POSITION)orientationData.DeviceOrientation,
                lockOrientation ? (short)CMP_ORIENTATION_FLAG.CMP_ORIENTATION_FLAG_LOCK
                                : (short)CMP_ORIENTATION_FLAG.CMP_ORIENTATION_FLAG_FOLLOW_SENSOR);
        }
        //! [lockorientation]

        // <summary>
        // Update the display with orientation information.
        // </summary>
        // <param name="DeviceOrientation">Device orientation.</param>
        // <param name="AppOrientation">Application orientation.</param>
        // <param name="OrientationFlags">Orientation flags (lock state).</param>
        private void UpdateOrientationInfo(CMP_ORIENTATION_DATA orientationData)
        {
            UiDispatch(() => deviceOrientation.Text = GetOrientationName((CMP_ORIENTATION_POSITION)orientationData.DeviceOrientation));
            UiDispatch(() => appOrientation.Text = GetOrientationName((CMP_ORIENTATION_POSITION)orientationData.AppOrientation));
            UiDispatch(() => lockOrientationCheckBox.Checked = (orientationData.OrientationFlags == (short)CMP_ORIENTATION_FLAG.CMP_ORIENTATION_FLAG_LOCK));
        }

        //! [eventhandler]
        // <summary>
        // OrientationChanged event handler
        // </summary>
        // <param name="rc">Return code.</param>
        // <param name="DeviceOrientation">Device orientation.</param>
        // <param name="AppOrientation">Application orientation.</param>
        // <param name="OrientationFlags">Orientation flags (lock state).</param>
        private void cmp_OrientationChanged(
            Int32 rc,
            CMP_ORIENTATION_POSITION DeviceOrientation,
            CMP_ORIENTATION_POSITION AppOrientation,
            short OrientationFlags)
        {
            CMP_ORIENTATION_DATA orientationData;
            orientationData.DeviceOrientation = (short)DeviceOrientation;
            orientationData.AppOrientation = (short)AppOrientation;
            orientationData.OrientationFlags = OrientationFlags;

            // Update orientation information.
            UpdateOrientationInfo(orientationData);
        }
        //! [eventhandler]

        public Form1()
        {
            InitializeComponent();

            // Initialises CMP framework.
            InitialiseCmp();
        }

        // <summary>
        // Initialise CMP framework.
        // </summary>
        private void InitialiseCmp()
        {
            int rc = (int)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Helpers.Trace("Creating CitrixMobile object");
                // Create an instance of CitrixMobile object.
                cmp = new CitrixMobile();

                Helpers.Trace("Register for ICA session state changed events");
                // Register for ICA session events.
                cmp.SessionStateChanged += new ICMPEvents_SessionStateChangedEventHandler(cmp_SessionStateChanged);

                Helpers.Trace("Calling OpenSession");
                // Open CMP session.
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    icaSessionConnected = true;

                    Helpers.Trace("Register for orientation changed events");
        //! [eventsubscription]
        // Register for orientation changedevents.
        cmp.OrientationChanged += new ICMPEvents_OrientationChangedEventHandler(cmp_OrientationChanged);
        //! [eventsubscription]

                    // Update current orientation information.
                    CMP_ORIENTATION_DATA orientationData;
                    cmp.GetOrientation(out orientationData);

                    UpdateOrientationInfo(orientationData);
                }
                else
                {
                    ReportStatus("OpenSession failed", rc);
                }
            }
            catch (System.Exception ex)
            {
                Helpers.Trace(ex.Message);
                Helpers.Trace(ex.StackTrace);
            }
        }

        // <summary>
        // Tear down CMP connection when closed.
        // </summary>
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if ((null != cmp) && icaSessionConnected)
            {
                // Close CMP session.
                cmp.CloseSession();
                cmp = null;
            }
        }

        // <summary>
        // Session state change handler.
        // </summary>
        // <remarks>Update the ICA session state upon connect/disconnect.</remarks>
        // <param name="SessState">Session state</param>
        private void cmp_SessionStateChanged(CMP_SESSION_STATE SessState)
        {
            switch (SessState)
            {
                case CMP_SESSION_STATE.CMP_SESSION_STATE_CONNECTED:
                    {
                        icaSessionConnected = true;

                        if (null != cmp)
                        {
                            // Update orientation information on reconnect.
                            CMP_ORIENTATION_DATA orientationData;
                            cmp.GetOrientation(out orientationData);

                            UpdateOrientationInfo(orientationData);
                        }
                    }
                    break;
                case CMP_SESSION_STATE.CMP_SESSION_STATE_DISCONNECTED:
                    icaSessionConnected = false;
                    break;
                default:
                    break;
            }
        }

        // <summary>
        // Handler for "Lock Orientation" check events.
        // </summary>
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if ((null != cmp) && icaSessionConnected)
            {
                // Lock the device orientation if checkbox is checked.
                LockOrientation(lockOrientationCheckBox.Checked);
            }
        }
    }
}
