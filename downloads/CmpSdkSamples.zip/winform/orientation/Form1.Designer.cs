﻿// C# Orientation example using COM Interop with Citrix Mobility SDK
//
// Uses Citrix Mobility SDK to display and change orientation
//
// Copyright (c) 2012 Citrix Systems
//

namespace orientation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.deviceLabel = new System.Windows.Forms.Label();
            this.applicationLabel = new System.Windows.Forms.Label();
            this.deviceOrientation = new System.Windows.Forms.TextBox();
            this.appOrientation = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.status = new System.Windows.Forms.Label();
            this.lockOrientationCheckBox = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // deviceLabel
            // 
            this.deviceLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.deviceLabel.AutoSize = true;
            this.deviceLabel.Location = new System.Drawing.Point(34, 84);
            this.deviceLabel.Name = "deviceLabel";
            this.deviceLabel.Size = new System.Drawing.Size(98, 13);
            this.deviceLabel.TabIndex = 1;
            this.deviceLabel.Text = "Device Orientation:";
            this.deviceLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // applicationLabel
            // 
            this.applicationLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.applicationLabel.AutoSize = true;
            this.applicationLabel.Location = new System.Drawing.Point(16, 110);
            this.applicationLabel.Name = "applicationLabel";
            this.applicationLabel.Size = new System.Drawing.Size(116, 13);
            this.applicationLabel.TabIndex = 3;
            this.applicationLabel.Text = "Application Orientation:";
            // 
            // deviceOrientation
            // 
            this.deviceOrientation.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.deviceOrientation.Location = new System.Drawing.Point(138, 81);
            this.deviceOrientation.Name = "deviceOrientation";
            this.deviceOrientation.ReadOnly = true;
            this.deviceOrientation.Size = new System.Drawing.Size(151, 20);
            this.deviceOrientation.TabIndex = 2;
            // 
            // appOrientation
            // 
            this.appOrientation.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.appOrientation.Location = new System.Drawing.Point(138, 107);
            this.appOrientation.Name = "appOrientation";
            this.appOrientation.ReadOnly = true;
            this.appOrientation.Size = new System.Drawing.Size(151, 20);
            this.appOrientation.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(301, 43);
            this.label1.TabIndex = 0;
            this.label1.Text = "Rotate the Device and observe new Orientation information.";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // status
            // 
            this.status.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.status.Location = new System.Drawing.Point(0, 220);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(301, 48);
            this.status.TabIndex = 6;
            this.status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lockOrientationCheckBox
            // 
            this.lockOrientationCheckBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lockOrientationCheckBox.AutoSize = true;
            this.lockOrientationCheckBox.Location = new System.Drawing.Point(138, 145);
            this.lockOrientationCheckBox.Name = "lockOrientationCheckBox";
            this.lockOrientationCheckBox.Size = new System.Drawing.Size(104, 17);
            this.lockOrientationCheckBox.TabIndex = 5;
            this.lockOrientationCheckBox.Text = "Lock Orientation";
            this.lockOrientationCheckBox.UseVisualStyleBackColor = true;
            this.lockOrientationCheckBox.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(301, 268);
            this.Controls.Add(this.status);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.appOrientation);
            this.Controls.Add(this.deviceOrientation);
            this.Controls.Add(this.lockOrientationCheckBox);
            this.Controls.Add(this.applicationLabel);
            this.Controls.Add(this.deviceLabel);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CMP SDK Orientation Example";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label deviceLabel;
        private System.Windows.Forms.Label applicationLabel;
        private System.Windows.Forms.TextBox deviceOrientation;
        private System.Windows.Forms.TextBox appOrientation;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label status;
        private System.Windows.Forms.CheckBox lockOrientationCheckBox;
    }
}

