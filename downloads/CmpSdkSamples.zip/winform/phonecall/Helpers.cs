﻿// C# Phone Call example using COM Interop with Citrix Mobility SDK
//
// Uses Citrix Mobility SDK to start a phone call
//
// Copyright (c) 2012 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Globalization;

using CitrixMobility;

namespace phonecall
{
    internal class Helpers
    {
        /// <summary>
        /// Trace message to output.
        /// </summary>
        /// <remarks>
        /// This implementation writes to the debug output.
        /// </remarks>
        /// <param name="format">Optional format string.</param>
        /// <param name="args">Params that match the format string.</param>
        public static void Trace(string format, params object[] args)
        {
            try
            {
                StringBuilder builder = Builder;

                builder.Remove(0, builder.Length);
                builder.AppendFormat(CultureInfo.InvariantCulture, format, args);

                System.Diagnostics.Trace.WriteLine(builder.ToString(), "Trace");
            }
            catch (ArgumentOutOfRangeException)
            {
                System.Diagnostics.Trace.WriteLine("Trace string too large", "Trace");
            }
            catch (ArgumentNullException)
            {
                System.Diagnostics.Trace.WriteLine("Null arguments supplied for tracing", "Trace");
            }
            catch (FormatException)
            {
                System.Diagnostics.Trace.WriteLine("Unable to format the supplied trace message", "Trace");
            }
            catch
            {
                // Ignore all exceptions to trace. We don't want to propagate exception
                // up the call stack when tracing fails.
            }
        }

        /// <summary>
        /// Per-thread static string builder used internally to build various strings.
        [ThreadStatic]
        private static StringBuilder m_builder;

        /// <summary>
        /// Accessor to the (thread) static JIT created string builder.
        /// </summary>
        private static StringBuilder Builder
        {
            get
            {
                if (m_builder == null)
                {
                    m_builder = new StringBuilder();
                }
                return m_builder;
            }
        }
    }
}
