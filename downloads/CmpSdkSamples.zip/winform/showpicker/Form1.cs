﻿// C# Show Picker example using COM Interop with Citrix Mobility SDK
//
// Uses Citrix Mobility SDK to show a Picker control
//
// Copyright (c) 2012 Citrix Systems
//

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using CitrixMobility;

namespace showpicker
{
    public partial class Form1 : Form
    {
        // <summary>
        // List of names for the Picker.
        // </summary>
        private string[] pickerText = { "Dad", "Mom", "Brother", "Sister", "Cousin" };

        // <summary>
        // Initialise Picker id (unique to this application).
        // </summary>
        private const int pickerId = 0x12344321;

        // <summary>
        // Instance of CitrixMobile.
        // </summary>
        private CitrixMobile cmp = null;

        // <summary>
        // ICA session connected state.
        // </summary>
        private bool icaSessionConnected = false;

        // <summary>
        // Check CMP return code for success.
        // </summary>
        public static bool CMP_SUCCESS(int rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (int)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        // <summary>
        // Dispatch action to UI thread if necessary.
        // </summary>
        // <param name="action">The action.</param>
        private void UiDispatch(Action action)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(action);
            }
            else
            {
                action();
            }
        }

        // <summary>
        // Report CMP status.
        // </summary>
        // <param name="text">Status text.</param>
        // <param name="rc">CMP return code.</param>
        private void ReportStatus(string text, int rc)
        {
            // Only report status if something went wrong.
            if (!CMP_SUCCESS(rc))
            {
                string msg = string.Format("{0}, CMPResult: 0x{1:X}", text, rc);

                // Write to trace output.
                Helpers.Trace(msg);
                // Update status text.
                UiDispatch(() => this.status.Text = msg);
            }
        }

        public Form1()
        {
            InitializeComponent();

            // Add items to comboboxes.
            standardComboBox.Items.AddRange(pickerText);
            pickerComboBox.Items.AddRange(pickerText);

            // Initialises CMP framework.
            InitialiseCmp();
        }

        // <summary>
        // Initialise CMP framework.
        // </summary>
        private void InitialiseCmp()
        {
            int rc = (int)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Helpers.Trace("Creating CitrixMobile object");
                // Create an instance of CitrixMobile object.
                cmp = new CitrixMobile();

                Helpers.Trace("Register for ICA session state changed events");
                // Register for ICA session events.
                cmp.SessionStateChanged += new ICMPEvents_SessionStateChangedEventHandler(cmp_SessionStateChanged);

                Helpers.Trace("Calling OpenSession");
                // Open CMP session.
                rc = cmp.OpenSession();

                if (CMP_SUCCESS(rc))
                {
                    icaSessionConnected = true;

                    Helpers.Trace("Register for Picker state changed events");
        //! [eventsubscription]
        // Register for Picker state changed events.
        cmp.PickerControlStateChanged += new ICMPEvents_PickerControlStateChangedEventHandler(cmp_PickerControlStateChanged);
        //! [eventsubscription]
                }
                else
                {
                    ReportStatus("OpenSession failed", rc);
                }
            }
            catch (System.Exception ex)
            {
                Helpers.Trace(ex.Message);
                Helpers.Trace(ex.StackTrace);
            }
        }

        // <summary>
        // Tear down CMP connection when closed.
        // </summary>
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (null != cmp)
            {
                // Close CMP session.
                cmp.CloseSession();
                cmp = null;
            }
        }

        // <summary>
        // Session state change handler.
        // </summary>
        // <remarks>Update the ICA session state upon connect/disconnect.</remarks>
        // <param name="SessState">Session state</param>
        void cmp_SessionStateChanged(CMP_SESSION_STATE SessState)
        {
            switch (SessState)
            {
                case CMP_SESSION_STATE.CMP_SESSION_STATE_CONNECTED:
                    icaSessionConnected = true;
                    break;
                case CMP_SESSION_STATE.CMP_SESSION_STATE_DISCONNECTED:
                    icaSessionConnected = false;
                    break;
                default:
                    break;
            }
        }
        //! [eventhandler]
        // <summary>
        // Picker control state changed handler.
        // </summary>
        // <param name="pickerId">Picker identifier.</param>
        // <param name="pickerStateFlags">Picker state flags.</param>
        // <param name="rc">Return code.</param>
        // <param name="selectedIndex">Selected index.</param>
        private void cmp_PickerControlStateChanged(int PickerId, short pickerStateFlags, int rc, short selectedIndex)
        {
            // Only if it is one of ours.
            if (pickerId == PickerId)
            {
                // Checks Picker State Flag whether it is visible.
                if ((pickerStateFlags & (short)CMP_PICKER_CONTROL_STATE.CMP_PICKER_CONTROL_STATE_VISIBLE) != 0)
                {
                    Helpers.Trace("Picker is visible");
                }

                // Checks Picker State Flag whether it is selected.
                if ((pickerStateFlags & (short)CMP_PICKER_CONTROL_STATE.CMP_PICKER_CONTROL_STATE_SELECTED) != 0)
                {
                    // Set the combobox's selected item based on the Picker selection.
                    pickerComboBox.SelectedItem = pickerText[selectedIndex];

                    string msg = string.Format("Picker item has been selected: Index: {0}, Item: {1}.",
                        selectedIndex, pickerText[selectedIndex]);

                    Helpers.Trace(msg);
                    UiDispatch(() => this.status.Text = msg);
                }

                // Checks Picker State Flag whether it is aborted.
                if ((pickerStateFlags & (short)CMP_PICKER_CONTROL_STATE.CMP_PICKER_CONTROL_STATE_ABORTED) != 0)
                {
                    Helpers.Trace("Picker control was aborted");
                    UiDispatch(() => this.status.Text = "Picker control was aborted");
                }

                // Collapse the drop-down portion of the combobox after selection.
                pickerComboBox.DroppedDown = false;
            }
        }
        //! [eventhandler]
        
        //! [comboboxeventhandler]
        // <summary>
        // Combobox drop down event handler.
        // </summary>
        private void comboBox1_DropDown(object sender, EventArgs e)
        {
            if ((null != cmp) && icaSessionConnected)
            {
                // Sets the title for the Picker.
                string pickerTitle = "Contacts";

                CMP_DISPLAY_RECT rect = new CMP_DISPLAY_RECT();

                // Show the Picker when the drop-down portion of the combobox is shown.
                int rc = cmp.ShowPicker(pickerId, ref rect, pickerComboBox.SelectedIndex, ref pickerText, pickerTitle);

                if (CMP_SUCCESS(rc))
                {
                    Helpers.Trace("ShowPicker success");
                }
                else
                {
                    ReportStatus("ShowPicker failed", rc);
                }
            }
        }
        //! [comboboxeventhandler]
    }
}
