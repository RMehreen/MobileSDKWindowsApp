﻿// C# Show picker example using COM Interop with Citrix Mobility SDK
//
// Uses Citrix Mobility SDK to show a picker control
//
// Copyright (c) 2012 Citrix Systems
//

namespace showpicker
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pickerComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.standardComboBox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.status = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // pickerComboBox
            // 
            this.pickerComboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pickerComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.pickerComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pickerComboBox.FormattingEnabled = true;
            this.pickerComboBox.Location = new System.Drawing.Point(12, 267);
            this.pickerComboBox.Name = "pickerComboBox";
            this.pickerComboBox.Size = new System.Drawing.Size(238, 32);
            this.pickerComboBox.TabIndex = 3;
            this.pickerComboBox.DropDown += new System.EventHandler(this.comboBox1_DropDown);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 240);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(324, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "ComboBox with CMP Picker support: ";
            // 
            // standardComboBox
            // 
            this.standardComboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.standardComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.standardComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.standardComboBox.FormattingEnabled = true;
            this.standardComboBox.Location = new System.Drawing.Point(12, 36);
            this.standardComboBox.Name = "standardComboBox";
            this.standardComboBox.Size = new System.Drawing.Size(238, 32);
            this.standardComboBox.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(190, 24);
            this.label3.TabIndex = 0;
            this.label3.Text = "Standard ComboBox:";
            // 
            // status
            // 
            this.status.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.status.Location = new System.Drawing.Point(0, 352);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(434, 57);
            this.status.TabIndex = 4;
            this.status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(434, 409);
            this.Controls.Add(this.status);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.standardComboBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pickerComboBox);
            this.Name = "Form1";
            this.Text = "CMP SDK Show Picker Example";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox pickerComboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox standardComboBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label status;
    }
}

