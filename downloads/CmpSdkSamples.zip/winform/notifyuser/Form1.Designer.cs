﻿namespace notifyuser
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lightButton = new System.Windows.Forms.Button();
            this.vibrateButton = new System.Windows.Forms.Button();
            this.audioButton = new System.Windows.Forms.Button();
            this.textButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.audioVibrateButton = new System.Windows.Forms.Button();
            this.status = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lightButton
            // 
            this.lightButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lightButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lightButton.Location = new System.Drawing.Point(12, 57);
            this.lightButton.Name = "lightButton";
            this.lightButton.Size = new System.Drawing.Size(170, 80);
            this.lightButton.TabIndex = 1;
            this.lightButton.Text = "Light";
            this.lightButton.UseVisualStyleBackColor = true;
            this.lightButton.Click += new System.EventHandler(this.lightButton_Click);
            // 
            // vibrateButton
            // 
            this.vibrateButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.vibrateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vibrateButton.Location = new System.Drawing.Point(187, 57);
            this.vibrateButton.Name = "vibrateButton";
            this.vibrateButton.Size = new System.Drawing.Size(170, 80);
            this.vibrateButton.TabIndex = 2;
            this.vibrateButton.Text = "Vibrate";
            this.vibrateButton.UseVisualStyleBackColor = true;
            this.vibrateButton.Click += new System.EventHandler(this.vibrateButton_Click);
            // 
            // audioButton
            // 
            this.audioButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.audioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.audioButton.Location = new System.Drawing.Point(12, 152);
            this.audioButton.Name = "audioButton";
            this.audioButton.Size = new System.Drawing.Size(170, 80);
            this.audioButton.TabIndex = 3;
            this.audioButton.Text = "Audio";
            this.audioButton.UseVisualStyleBackColor = true;
            this.audioButton.Click += new System.EventHandler(this.audioButton_Click);
            // 
            // textButton
            // 
            this.textButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textButton.Location = new System.Drawing.Point(188, 152);
            this.textButton.Name = "textButton";
            this.textButton.Size = new System.Drawing.Size(170, 80);
            this.textButton.TabIndex = 4;
            this.textButton.Text = "Text";
            this.textButton.UseVisualStyleBackColor = true;
            this.textButton.Click += new System.EventHandler(this.textButton_Click);
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(369, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tap on button for each Notification Type ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // audioVibrateButton
            // 
            this.audioVibrateButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.audioVibrateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.audioVibrateButton.Location = new System.Drawing.Point(99, 250);
            this.audioVibrateButton.Name = "audioVibrateButton";
            this.audioVibrateButton.Size = new System.Drawing.Size(170, 80);
            this.audioVibrateButton.TabIndex = 5;
            this.audioVibrateButton.Text = "Audio + Vibrate";
            this.audioVibrateButton.UseVisualStyleBackColor = true;
            this.audioVibrateButton.Click += new System.EventHandler(this.audioVibrateButton_Click);
            // 
            // status
            // 
            this.status.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.status.Location = new System.Drawing.Point(0, 355);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(369, 56);
            this.status.TabIndex = 6;
            this.status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(369, 411);
            this.Controls.Add(this.status);
            this.Controls.Add(this.audioVibrateButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textButton);
            this.Controls.Add(this.audioButton);
            this.Controls.Add(this.vibrateButton);
            this.Controls.Add(this.lightButton);
            this.Name = "Form1";
            this.Text = "Notify User Sample";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button lightButton;
        private System.Windows.Forms.Button vibrateButton;
        private System.Windows.Forms.Button audioButton;
        private System.Windows.Forms.Button textButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button audioVibrateButton;
        private System.Windows.Forms.Label status;
    }
}

