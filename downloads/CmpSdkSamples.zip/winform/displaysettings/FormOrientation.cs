﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CitrixMobility;

namespace displaysettings
{
    public partial class FormOrientation : ScaleForm
    {
        private int orientEvents = 0;

        public FormOrientation(CMPApp cmpapp, ScaleForm parent) : base(cmpapp, parent)
        {
            InitializeComponent();

            // capture data about the current layout
            CaptureInitialLayout();

            ScaleLayout();

            RefreshData();

            ScaleMode = parent.ScaleMode;

            cmp.OrientationChanged += new CMPApp.OrientationChangedEventHandler(OrientationChanged);

        }


        private void BackButton_Click(object sender, EventArgs e)
        {
            parentForm.Show();
            Hide();
        }

        // <summary>
        // Refresh the CMP related data on the form
        // </summary>
        void RefreshData()
        {
            Int32 rc = (Int32)CMP_ERROR_ID.CMP_NO_ERROR;

            {
                CMP_ORIENTATION_DATA orientData = new CMP_ORIENTATION_DATA();

                rc = cmp.GetOrientation(ref orientData);

                if (CMPApp.CMP_SUCCESS(rc))
                {
                    FormUpdateOrientationData(ref orientData);
                }
                else
                {
                    FormErrorOrientationData();
                    ReportStatus("GetOrientation", rc);
                }
            }
        }

        // <summary>
        // Mark as error for the orientation data on the form
        // </summary>
        void FormErrorOrientationData()
        {
            UiDispatch(() =>
            {
                this.deviceOrientation.Text = errorStr;
                this.appOrientation.Text = errorStr;
                this.orientationFlags.Text = errorStr;
            });
        }

        // <summary>
        // Update the orientation data on the form
        // </summary>
        // <param name="orientData">Update application and device orientation, and orientation flags</param>
        void FormUpdateOrientationData(ref CMP_ORIENTATION_DATA orientData)
        {
            CMP_ORIENTATION_POSITION devori = (CMP_ORIENTATION_POSITION)orientData.DeviceOrientation;
            CMP_ORIENTATION_POSITION appori = (CMP_ORIENTATION_POSITION)orientData.AppOrientation;
            Int16 oriflags = orientData.OrientationFlags;

            UiDispatch(() =>
            {
                this.deviceOrientation.Text = devori.ToString();
                this.appOrientation.Text = appori.ToString();
                this.orientationFlags.Text = oriflags.ToString("X");
            });
        }

        // <summary>
        // Orientation Changed event handler
        // </summary>
        // <remarks>Process incoming orientation changes</remarks>
        // <param name="rc">CMP result.</param>
        // <param name="devOrient">Device orientation.</param>
        // <param name="appOrient">Application orientation.</param>
        // <param name="flags">Orientation flags.</param>
        public void OrientationChanged(Int32 rc, CMP_ORIENTATION_POSITION devOrient,
                                CMP_ORIENTATION_POSITION appOrient, short flags)
        {
            orientEvents++;

            RefreshData();

            if (CMPApp.CMP_SUCCESS(rc))
            {
                UiDispatch(() =>
                {
                    deviceOrientation.Text = devOrient.ToString();
                    appOrientation.Text = appOrient.ToString();
                    orientationFlags.Text = flags.ToString("X");
                    orientationEvents.Text = orientEvents.ToString();

                    // if the orientation changes, we have to refit the controls
                    Scale();

                }
                );
            }

        }

        private void FormOrientation_Shown(object sender, EventArgs e)
        {
            Maximize();
        }

    }
}
