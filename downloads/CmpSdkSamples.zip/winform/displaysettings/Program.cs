﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using CitrixMobility;

namespace displaysettings
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Int32 rc;
            CMPApp cmpapp = new CMPApp();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            CMPApp cmpapp = new CMPApp();

            // Initialize CMP framework.
            rc = cmpapp.Initialize();

            Application.Run(new FormMain(cmpapp));
        }
    }

}
