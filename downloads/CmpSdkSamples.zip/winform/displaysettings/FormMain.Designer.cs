﻿//
// C# Display Settings example using COM Interop with Citrix Mobility SDK
//
// Uses Citrix Mobility SDK to reveal display settings
// Retrieves information on the device's display settings after a change 
// in the settings is detected (through a change orientation) and prints them out on the console window.
//
// Copyright (c) 2012 Citrix Systems
//
namespace displaysettings
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.QuitButton = new System.Windows.Forms.Button();
            this.OneX = new System.Windows.Forms.Button();
            this.TwoX = new System.Windows.Forms.Button();
            this.DPIFactor = new System.Windows.Forms.Button();
            this.FitButton = new System.Windows.Forms.Button();
            this.MaxButton = new System.Windows.Forms.Button();
            this.ViewportButton = new System.Windows.Forms.Button();
            this.OrientationButton = new System.Windows.Forms.Button();
            this.SettingsButton = new System.Windows.Forms.Button();
            this.ScrollModeButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // QuitButton
            // 
            this.QuitButton.BackColor = System.Drawing.Color.LightGray;
            this.QuitButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.QuitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuitButton.Location = new System.Drawing.Point(5, 3);
            this.QuitButton.Name = "QuitButton";
            this.QuitButton.Size = new System.Drawing.Size(47, 32);
            this.QuitButton.TabIndex = 50;
            this.QuitButton.Text = "Quit";
            this.QuitButton.UseVisualStyleBackColor = false;
            this.QuitButton.Click += new System.EventHandler(this.Quit_Click);
            // 
            // OneX
            // 
            this.OneX.BackColor = System.Drawing.Color.LightGray;
            this.OneX.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.OneX.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OneX.Location = new System.Drawing.Point(62, 3);
            this.OneX.Name = "OneX";
            this.OneX.Size = new System.Drawing.Size(41, 32);
            this.OneX.TabIndex = 51;
            this.OneX.Text = "1X";
            this.OneX.UseVisualStyleBackColor = false;
            this.OneX.Click += new System.EventHandler(this.OneX_Click);
            // 
            // TwoX
            // 
            this.TwoX.BackColor = System.Drawing.Color.LightGray;
            this.TwoX.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.TwoX.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TwoX.Location = new System.Drawing.Point(103, 3);
            this.TwoX.Name = "TwoX";
            this.TwoX.Size = new System.Drawing.Size(41, 32);
            this.TwoX.TabIndex = 52;
            this.TwoX.Text = "2X";
            this.TwoX.UseVisualStyleBackColor = false;
            this.TwoX.Click += new System.EventHandler(this.TwoX_Click);
            // 
            // DPIFactor
            // 
            this.DPIFactor.BackColor = System.Drawing.Color.LightGray;
            this.DPIFactor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.DPIFactor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DPIFactor.Location = new System.Drawing.Point(62, 37);
            this.DPIFactor.Name = "DPIFactor";
            this.DPIFactor.Size = new System.Drawing.Size(41, 32);
            this.DPIFactor.TabIndex = 53;
            this.DPIFactor.Text = "DPI";
            this.DPIFactor.UseVisualStyleBackColor = false;
            this.DPIFactor.Click += new System.EventHandler(this.DPIFactor_Click);
            // 
            // FitButton
            // 
            this.FitButton.BackColor = System.Drawing.Color.LightGray;
            this.FitButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.FitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FitButton.Location = new System.Drawing.Point(103, 37);
            this.FitButton.Name = "FitButton";
            this.FitButton.Size = new System.Drawing.Size(41, 32);
            this.FitButton.TabIndex = 54;
            this.FitButton.Text = "Fit";
            this.FitButton.UseVisualStyleBackColor = false;
            this.FitButton.Click += new System.EventHandler(this.FitButton_Click);
            // 
            // MaxButton
            // 
            this.MaxButton.BackColor = System.Drawing.Color.LightGray;
            this.MaxButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.MaxButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaxButton.Location = new System.Drawing.Point(159, 3);
            this.MaxButton.Name = "MaxButton";
            this.MaxButton.Size = new System.Drawing.Size(41, 32);
            this.MaxButton.TabIndex = 55;
            this.MaxButton.Text = "Max";
            this.MaxButton.UseVisualStyleBackColor = false;
            this.MaxButton.Click += new System.EventHandler(this.MaxButton_Click);
            // 
            // ViewportButton
            // 
            this.ViewportButton.BackColor = System.Drawing.Color.LightGray;
            this.ViewportButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.ViewportButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewportButton.Location = new System.Drawing.Point(62, 136);
            this.ViewportButton.Name = "ViewportButton";
            this.ViewportButton.Size = new System.Drawing.Size(82, 26);
            this.ViewportButton.TabIndex = 56;
            this.ViewportButton.Text = "Viewport";
            this.ViewportButton.UseVisualStyleBackColor = false;
            this.ViewportButton.Click += new System.EventHandler(this.ViewportButton_Click);
            // 
            // OrientationButton
            // 
            this.OrientationButton.BackColor = System.Drawing.Color.LightGray;
            this.OrientationButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.OrientationButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrientationButton.Location = new System.Drawing.Point(62, 110);
            this.OrientationButton.Name = "OrientationButton";
            this.OrientationButton.Size = new System.Drawing.Size(82, 26);
            this.OrientationButton.TabIndex = 57;
            this.OrientationButton.Text = "Orientation";
            this.OrientationButton.UseVisualStyleBackColor = false;
            this.OrientationButton.Click += new System.EventHandler(this.OrientationButton_Click);
            // 
            // SettingsButton
            // 
            this.SettingsButton.BackColor = System.Drawing.Color.LightGray;
            this.SettingsButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.SettingsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SettingsButton.Location = new System.Drawing.Point(62, 84);
            this.SettingsButton.Name = "SettingsButton";
            this.SettingsButton.Size = new System.Drawing.Size(82, 26);
            this.SettingsButton.TabIndex = 58;
            this.SettingsButton.Text = "Settings";
            this.SettingsButton.UseVisualStyleBackColor = false;
            this.SettingsButton.Click += new System.EventHandler(this.SettingsButton_Click);
            // 
            // ScrollModeButton
            // 
            this.ScrollModeButton.BackColor = System.Drawing.Color.LightGray;
            this.ScrollModeButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.ScrollModeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScrollModeButton.Location = new System.Drawing.Point(62, 162);
            this.ScrollModeButton.Name = "ScrollModeButton";
            this.ScrollModeButton.Size = new System.Drawing.Size(82, 26);
            this.ScrollModeButton.TabIndex = 59;
            this.ScrollModeButton.Text = "ScrollMode";
            this.ScrollModeButton.UseVisualStyleBackColor = false;
            this.ScrollModeButton.Click += new System.EventHandler(this.ScrollModeButton_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(213, 205);
            this.Controls.Add(this.ScrollModeButton);
            this.Controls.Add(this.SettingsButton);
            this.Controls.Add(this.OrientationButton);
            this.Controls.Add(this.ViewportButton);
            this.Controls.Add(this.MaxButton);
            this.Controls.Add(this.FitButton);
            this.Controls.Add(this.DPIFactor);
            this.Controls.Add(this.TwoX);
            this.Controls.Add(this.OneX);
            this.Controls.Add(this.QuitButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormMain";
            this.Text = "CMP Display Settings Sample";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Shown += new System.EventHandler(this.FormMain_Shown);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button QuitButton;
        private System.Windows.Forms.Button OneX;
        private System.Windows.Forms.Button TwoX;
        private System.Windows.Forms.Button DPIFactor;
        private System.Windows.Forms.Button FitButton;
        private System.Windows.Forms.Button MaxButton;
        private System.Windows.Forms.Button ViewportButton;
        private System.Windows.Forms.Button OrientationButton;
        private System.Windows.Forms.Button SettingsButton;
        private System.Windows.Forms.Button ScrollModeButton;

    }
}

