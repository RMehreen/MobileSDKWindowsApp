﻿namespace displaysettings
{
    partial class FormDisplaySettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BackButton = new System.Windows.Forms.Button();
            this.displayEventsCount = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.dpi = new System.Windows.Forms.Label();
            this.physical = new System.Windows.Forms.Label();
            this.orientation = new System.Windows.Forms.Label();
            this.ppi = new System.Windows.Forms.Label();
            this.colorDepth = new System.Windows.Forms.Label();
            this.pixel = new System.Windows.Forms.Label();
            this.metricsFlags = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.Color.LightGray;
            this.BackButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.Location = new System.Drawing.Point(12, 12);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(47, 32);
            this.BackButton.TabIndex = 61;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // displayEventsCount
            // 
            this.displayEventsCount.AutoSize = true;
            this.displayEventsCount.Location = new System.Drawing.Point(116, 66);
            this.displayEventsCount.Name = "displayEventsCount";
            this.displayEventsCount.Size = new System.Drawing.Size(13, 13);
            this.displayEventsCount.TabIndex = 77;
            this.displayEventsCount.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 66);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 13);
            this.label9.TabIndex = 76;
            this.label9.Text = "Settings Events";
            // 
            // dpi
            // 
            this.dpi.AutoSize = true;
            this.dpi.Location = new System.Drawing.Point(115, 174);
            this.dpi.Name = "dpi";
            this.dpi.Size = new System.Drawing.Size(53, 13);
            this.dpi.TabIndex = 75;
            this.dpi.Text = "Unknown";
            // 
            // physical
            // 
            this.physical.AutoSize = true;
            this.physical.Location = new System.Drawing.Point(115, 161);
            this.physical.Name = "physical";
            this.physical.Size = new System.Drawing.Size(53, 13);
            this.physical.TabIndex = 74;
            this.physical.Text = "Unknown";
            // 
            // orientation
            // 
            this.orientation.AutoSize = true;
            this.orientation.Location = new System.Drawing.Point(115, 148);
            this.orientation.Name = "orientation";
            this.orientation.Size = new System.Drawing.Size(53, 13);
            this.orientation.TabIndex = 73;
            this.orientation.Text = "Unknown";
            // 
            // ppi
            // 
            this.ppi.AutoSize = true;
            this.ppi.Location = new System.Drawing.Point(115, 135);
            this.ppi.Name = "ppi";
            this.ppi.Size = new System.Drawing.Size(53, 13);
            this.ppi.TabIndex = 72;
            this.ppi.Text = "Unknown";
            // 
            // colorDepth
            // 
            this.colorDepth.AutoSize = true;
            this.colorDepth.Location = new System.Drawing.Point(115, 122);
            this.colorDepth.Name = "colorDepth";
            this.colorDepth.Size = new System.Drawing.Size(53, 13);
            this.colorDepth.TabIndex = 71;
            this.colorDepth.Text = "Unknown";
            // 
            // pixel
            // 
            this.pixel.AutoSize = true;
            this.pixel.Location = new System.Drawing.Point(115, 109);
            this.pixel.Name = "pixel";
            this.pixel.Size = new System.Drawing.Size(53, 13);
            this.pixel.TabIndex = 70;
            this.pixel.Text = "Unknown";
            // 
            // metricsFlags
            // 
            this.metricsFlags.AutoSize = true;
            this.metricsFlags.Location = new System.Drawing.Point(115, 96);
            this.metricsFlags.Name = "metricsFlags";
            this.metricsFlags.Size = new System.Drawing.Size(53, 13);
            this.metricsFlags.TabIndex = 69;
            this.metricsFlags.Text = "Unknown";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(9, 174);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 13);
            this.label7.TabIndex = 68;
            this.label7.Text = "Normalised DPI:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(9, 161);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 13);
            this.label6.TabIndex = 67;
            this.label6.Text = "Size (1/1000inch):";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(9, 148);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 13);
            this.label5.TabIndex = 66;
            this.label5.Text = "Orientation:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(9, 135);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 13);
            this.label4.TabIndex = 65;
            this.label4.Text = "PPI X and Y:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(9, 122);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 13);
            this.label3.TabIndex = 64;
            this.label3.Text = "Color Depth:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(9, 109);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 13);
            this.label2.TabIndex = 63;
            this.label2.Text = "Pixel Width/Height:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(9, 92);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 17);
            this.label1.TabIndex = 62;
            this.label1.Text = "Metrics Flags:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FormDisplaySettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(223, 207);
            this.Controls.Add(this.displayEventsCount);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.dpi);
            this.Controls.Add(this.physical);
            this.Controls.Add(this.orientation);
            this.Controls.Add(this.ppi);
            this.Controls.Add(this.colorDepth);
            this.Controls.Add(this.pixel);
            this.Controls.Add(this.metricsFlags);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BackButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormDisplaySettings";
            this.Text = "FormDisplaySettings";
            this.Shown += new System.EventHandler(this.FormDisplaySettings_Shown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Label displayEventsCount;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label dpi;
        private System.Windows.Forms.Label physical;
        private System.Windows.Forms.Label orientation;
        private System.Windows.Forms.Label ppi;
        private System.Windows.Forms.Label colorDepth;
        private System.Windows.Forms.Label pixel;
        private System.Windows.Forms.Label metricsFlags;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}