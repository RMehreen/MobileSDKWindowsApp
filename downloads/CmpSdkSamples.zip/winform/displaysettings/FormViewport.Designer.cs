﻿namespace displaysettings
{
    partial class FormViewport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.clientViewport = new System.Windows.Forms.Label();
            this.serverViewport = new System.Windows.Forms.Label();
            this.zoomFactor = new System.Windows.Forms.Label();
            this.viewportFlags = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.viewportOrigin = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.BackButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // clientViewport
            // 
            this.clientViewport.AutoSize = true;
            this.clientViewport.Location = new System.Drawing.Point(118, 110);
            this.clientViewport.Name = "clientViewport";
            this.clientViewport.Size = new System.Drawing.Size(53, 13);
            this.clientViewport.TabIndex = 58;
            this.clientViewport.Text = "Unknown";
            // 
            // serverViewport
            // 
            this.serverViewport.AutoSize = true;
            this.serverViewport.Location = new System.Drawing.Point(118, 96);
            this.serverViewport.Name = "serverViewport";
            this.serverViewport.Size = new System.Drawing.Size(53, 13);
            this.serverViewport.TabIndex = 57;
            this.serverViewport.Text = "Unknown";
            // 
            // zoomFactor
            // 
            this.zoomFactor.AutoSize = true;
            this.zoomFactor.Location = new System.Drawing.Point(118, 83);
            this.zoomFactor.Name = "zoomFactor";
            this.zoomFactor.Size = new System.Drawing.Size(53, 13);
            this.zoomFactor.TabIndex = 56;
            this.zoomFactor.Text = "Unknown";
            // 
            // viewportFlags
            // 
            this.viewportFlags.AutoSize = true;
            this.viewportFlags.Location = new System.Drawing.Point(118, 70);
            this.viewportFlags.Name = "viewportFlags";
            this.viewportFlags.Size = new System.Drawing.Size(53, 13);
            this.viewportFlags.TabIndex = 55;
            this.viewportFlags.Text = "Unknown";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(12, 109);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(77, 13);
            this.label19.TabIndex = 54;
            this.label19.Text = "Client Viewport";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 96);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(82, 13);
            this.label18.TabIndex = 53;
            this.label18.Text = "Server Viewport";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(12, 83);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(67, 13);
            this.label17.TabIndex = 52;
            this.label17.Text = "Zoom Factor";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(12, 70);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(76, 13);
            this.label16.TabIndex = 51;
            this.label16.Text = "Viewport Flags";
            // 
            // viewportOrigin
            // 
            this.viewportOrigin.AutoSize = true;
            this.viewportOrigin.Location = new System.Drawing.Point(118, 57);
            this.viewportOrigin.Name = "viewportOrigin";
            this.viewportOrigin.Size = new System.Drawing.Size(53, 13);
            this.viewportOrigin.TabIndex = 50;
            this.viewportOrigin.Text = "Unknown";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 57);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(78, 13);
            this.label15.TabIndex = 49;
            this.label15.Text = "Viewport Origin";
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.Color.LightGray;
            this.BackButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.Location = new System.Drawing.Point(12, 12);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(47, 32);
            this.BackButton.TabIndex = 59;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // FormViewport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(193, 144);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.clientViewport);
            this.Controls.Add(this.serverViewport);
            this.Controls.Add(this.zoomFactor);
            this.Controls.Add(this.viewportFlags);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.viewportOrigin);
            this.Controls.Add(this.label15);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormViewport";
            this.Text = "Form2";
            this.Shown += new System.EventHandler(this.Form2_Shown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label clientViewport;
        private System.Windows.Forms.Label serverViewport;
        private System.Windows.Forms.Label zoomFactor;
        private System.Windows.Forms.Label viewportFlags;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label viewportOrigin;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button BackButton;
    }
}