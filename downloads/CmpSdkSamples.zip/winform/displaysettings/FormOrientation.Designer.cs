﻿namespace displaysettings
{
    partial class FormOrientation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BackButton = new System.Windows.Forms.Button();
            this.orientationFlags = new System.Windows.Forms.Label();
            this.appOrientation = new System.Windows.Forms.Label();
            this.deviceOrientation = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.orientationEvents = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.Color.LightGray;
            this.BackButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.Location = new System.Drawing.Point(12, 12);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(47, 32);
            this.BackButton.TabIndex = 60;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // orientationFlags
            // 
            this.orientationFlags.AutoSize = true;
            this.orientationFlags.Location = new System.Drawing.Point(118, 96);
            this.orientationFlags.Name = "orientationFlags";
            this.orientationFlags.Size = new System.Drawing.Size(53, 13);
            this.orientationFlags.TabIndex = 66;
            this.orientationFlags.Text = "Unknown";
            // 
            // appOrientation
            // 
            this.appOrientation.AutoSize = true;
            this.appOrientation.Location = new System.Drawing.Point(118, 83);
            this.appOrientation.Name = "appOrientation";
            this.appOrientation.Size = new System.Drawing.Size(53, 13);
            this.appOrientation.TabIndex = 65;
            this.appOrientation.Text = "Unknown";
            // 
            // deviceOrientation
            // 
            this.deviceOrientation.AutoSize = true;
            this.deviceOrientation.Location = new System.Drawing.Point(118, 70);
            this.deviceOrientation.Name = "deviceOrientation";
            this.deviceOrientation.Size = new System.Drawing.Size(53, 13);
            this.deviceOrientation.TabIndex = 64;
            this.deviceOrientation.Text = "Unknown";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 96);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(86, 13);
            this.label13.TabIndex = 63;
            this.label13.Text = "Orientation Flags";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 83);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(80, 13);
            this.label12.TabIndex = 62;
            this.label12.Text = "App Orientation";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 70);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(95, 13);
            this.label11.TabIndex = 61;
            this.label11.Text = "Device Orientation";
            // 
            // orientationEvents
            // 
            this.orientationEvents.AutoSize = true;
            this.orientationEvents.Location = new System.Drawing.Point(120, 57);
            this.orientationEvents.Name = "orientationEvents";
            this.orientationEvents.Size = new System.Drawing.Size(13, 13);
            this.orientationEvents.TabIndex = 68;
            this.orientationEvents.Text = "0";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(13, 57);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(94, 13);
            this.label99.TabIndex = 67;
            this.label99.Text = "Orientation Events";
            // 
            // FormOrientation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(192, 129);
            this.Controls.Add(this.orientationEvents);
            this.Controls.Add(this.label99);
            this.Controls.Add(this.orientationFlags);
            this.Controls.Add(this.appOrientation);
            this.Controls.Add(this.deviceOrientation);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.BackButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormOrientation";
            this.Text = "FormOrientation";
            this.Shown += new System.EventHandler(this.FormOrientation_Shown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Label orientationFlags;
        private System.Windows.Forms.Label appOrientation;
        private System.Windows.Forms.Label deviceOrientation;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label orientationEvents;
        private System.Windows.Forms.Label label99;
    }
}