﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CitrixMobility;
using System.Runtime.InteropServices;

namespace displaysettings
{
    public class CMPApp
    {
        //! [cmp]
        CitrixMobile cmp;
        //! [cmp]

        // <summary>
        // ICA session connected state.
        // </summary>
        private bool cmpInitialized = false;

        public bool IsChannelOpen()
        {
            return (cmp.IsChannelOpen());
        }

        public bool IsInitialized()
        {
            return (cmpInitialized);
        }

        public delegate void DisplaySettingsChangedEventHandler(CMP_DISPLAY_SETTINGS settings);
        public delegate void OrientationChangedEventHandler(Int32 rc, CMP_ORIENTATION_POSITION devOrient,
                                                        CMP_ORIENTATION_POSITION appOrient, short flags);
        public delegate void ReportStatusEventHandler(string Status, Int32 rc);
        public delegate void SessionStateChangedEventHandler(CMP_SESSION_STATE sessionState);

        public event DisplaySettingsChangedEventHandler  DisplaySettingsChanged;
        public event OrientationChangedEventHandler      OrientationChanged;
        public event ReportStatusEventHandler            ReportStatus;
        public event SessionStateChangedEventHandler     SessionStateChanged;

        // <summary>
        // Check CMP return code for success.
        // </summary>f
        public static bool CMP_SUCCESS(Int32 rc)
        {
            // need to mask the result since the top half can have the component Id
            return ((rc & 0xffff) == (Int32)CMP_ERROR_ID.CMP_NO_ERROR);
        }

        // <summary>
        // Callback registered handlers for status changes (errors)
        // </summary>
        private void StatusCallback(string Status, Int32 rc)
        {
            if (ReportStatus != null)
            {
                ReportStatus(Status, rc);
            }
        }

        // <summary>
        // Event notification for display settings changes
        // </summary>
        private void DisplaySettingsChangedEvent(CMP_DISPLAY_SETTINGS settings)
        {
            if (DisplaySettingsChanged != null)
            {
                DisplaySettingsChanged(settings);
            }
        }

        // <summary>
        // Event notification for orientation changes
        // </summary>
        private void OrientationChangedEvent(Int32 rc, CMP_ORIENTATION_POSITION devOrient, CMP_ORIENTATION_POSITION appOrient, short flags)
        {
            if(OrientationChanged != null)
            {
                OrientationChanged(rc, devOrient, appOrient, flags);
            }
        }

        // <summary>
        // Initialize CMP framework.
        // </summary>
        public Int32 Initialize()
        {
            Int32 rc = (Int32)CMP_ERROR_ID.CMP_NO_ERROR;

            try
            {
                Helpers.Trace("Creating CitrixMobile object");

                // Create an instance of CitrixMobile object.
                cmp = new CitrixMobile();

                Helpers.Trace("Register for ICA session state changed events");

                // Register for ICA session events.
                cmp.SessionStateChanged += new ICMPEvents_SessionStateChangedEventHandler(cmp_SessionStateChanged);
                cmp.OrientationChanged += new ICMPEvents_OrientationChangedEventHandler(cmp_OrientationChanged);
                cmp.ChannelStateChanged += new ICMPEvents_ChannelStateChangedEventHandler(cmp_ChannelStateChanged);

                RegisterForDisplaySettingsEvent();

                Helpers.Trace("Calling OpenSession");

                // start a virtual channel session
                rc = OpenSession();

            }
            catch (System.Exception ex)
            {
                Helpers.Trace(ex.Message);
                Helpers.Trace(ex.StackTrace);
                rc = (Int32)CMP_ERROR_ID.CMP_ERROR_NOT_CONNECTED;
            }

            if (CMP_SUCCESS(rc))
            {
                cmpInitialized = true;
            }

            return (rc);
        }

        // <summary>
        // Event notification for channel state changes
        // </summary>
        private void cmp_ChannelStateChanged(CMP_CHANNEL_STATE channelState)
        {

        }

        // <summary>
        // Session state change handler.
        // </summary>
        // <remarks>Update the ICA session state upon connect/disconnect.</remarks>
        // <param name="SessState">Session state</param>
        private void cmp_SessionStateChanged(CMP_SESSION_STATE sessState)
        {
            switch (sessState)
            {
                case CMP_SESSION_STATE.CMP_SESSION_STATE_CONNECTED:
                    break;

                case CMP_SESSION_STATE.CMP_SESSION_STATE_DISCONNECTED:
                    CloseSession();
                    break;

                default:
                    break;
            }

            if (SessionStateChanged != null)
            {
                SessionStateChanged(sessState);
            }
        }


        // <summary>
        // Orientation Changed event handler
        // </summary>
        // <remarks>Process incoming orientation changes</remarks>
        // <param name="rc">CMP result.</param>
        // <param name="devOrient">Device orientation.</param>
        // <param name="appOrient">Application orientation.</param>
        // <param name="flags">Orientation flags.</param>
        private void cmp_OrientationChanged(Int32 rc, CMP_ORIENTATION_POSITION devOrient,
                                    CMP_ORIENTATION_POSITION appOrient, short flags)
        {
            // call the delegates
            OrientationChangedEvent(rc, devOrient, appOrient, flags);
        }

        //! [eventhandler]
        // <summary>
        // Display Settings event handler.
        // </summary>
        // <param name="metricsFlags">Metrix flags.</param>
        // <param name="pixelWidth">Pixel width.</param>
        // <param name="pixelHeight">Pixel height.</param>
        // <param name="colorDepth">Colour depth.</param>
        // <param name="XPixelsPerInch">X-axis pixels per inch.</param>
        // <param name="YPixelsPerInch">Y-axis pixels per inch.</param>
        // <param name="DeviceOrientation">Device Orientation</param>
        // <param name="WidthMilliInches">Width milli-inches</param>
        // <param name="HeightMilliInches">Heigth milli-inches</param>
        // <param name="normalizedDPI">Normalised dots per inch</param>
        private void cmp_DisplaySettingsChanged(
            Int16 metricsFlags,
            Int32 pixelWidth,
            Int32 pixelHeight,
            Int16 colorDepth,
            Int32 XPixelsPerInch,
            Int32 YPixelsPerInch,
            CMP_ORIENTATION_POSITION DeviceOrientation,
            Int32 WidthMilliInches,
            Int32 HeightMilliInches,
            Int32 normalizedDPI)
        {
            CMP_DISPLAY_SETTINGS settings = new CMP_DISPLAY_SETTINGS();

            settings.Length = (short)Marshal.SizeOf(settings);
            settings.PixelHeight = pixelHeight;
            settings.PixelWidth = pixelWidth;
            settings.MetricsFlags = metricsFlags;
            settings.ColorDepth = colorDepth;
            settings.HorizontalPixelsPerInch = XPixelsPerInch;
            settings.VerticalPixelsPerInch = YPixelsPerInch;
            settings.DeviceOrientation = (short)DeviceOrientation;
            settings.WidthMilliInches = WidthMilliInches;
            settings.HeightMilliInches = HeightMilliInches;
            settings.PixelsPerInch = normalizedDPI;

            // call the registered delegates
            DisplaySettingsChangedEvent(settings);
        }

        //! [eventhandler]

        // <summary>
        // Register for the display settings changed event
        // </summary>
        private void RegisterForDisplaySettingsEvent()
        {
            //! [eventsubscription]
            // Register for display settings changed events.
            cmp.DisplaySettingsChanged += new ICMPEvents_DisplaySettingsChangedEventHandler(cmp_DisplaySettingsChanged);
            //! [eventsubscription]
        }

        // <summary>
        // Wrapper function for OpenSession
        // </summary>
        public Int32 OpenSession()
        {
            Int32 rc;

            // Open CMP session.
            rc = cmp.OpenSession();

            if (CMP_SUCCESS(rc))
            {
                Helpers.Trace("Register for display settings changed events");
            }
            else
            {
                StatusCallback("OpenSession failed", rc);
            }

            return (rc);
        }

        // <summary>
        // Wrapper function for CloseSession
        // </summary>
        public Int32 CloseSession()
        {
            Int32 rc = (Int32)CMP_ERROR_ID.CMP_NO_ERROR;

            if (cmp != null)
            {
                rc = cmp.CloseSession();
            }
            else
            {
                rc = (Int32)CMP_ERROR_ID.CMP_ERROR_NOT_CONNECTED;
            }

            return (rc);
        }

        // <summary>
        // Wrapper function for GetDisplaySettings
        // </summary>
        public Int32 GetDisplaySettings(ref CMP_DISPLAY_SETTINGS settings)
        {
            Int32 rc = (Int32)CMP_ERROR_ID.CMP_NO_ERROR;

            if (cmp != null)
            {
                rc = ConfirmConnection();

                if (CMPApp.CMP_SUCCESS(rc))
                {
                    settings.Length = (short)Marshal.SizeOf(settings);

                    rc = cmp.GetDisplaySettings(out settings);
                }
            }
            else
            {
                rc = (Int32)CMP_ERROR_ID.CMP_ERROR_NOT_CONNECTED;
            }

            return (rc);
        }

        // <summary>
        // Wrapper function for GetViewportOrigin
        // </summary>
        public Int32 GetViewportOrigin(ref CMP_DISPLAY_POINT origin)
        {
            Int32 rc = (Int32)CMP_ERROR_ID.CMP_NO_ERROR;

            if (cmp != null)
            {
                rc = ConfirmConnection();

                if (CMPApp.CMP_SUCCESS(rc))
                {
                    rc = cmp.GetViewportOrigin(ref origin);
                }
            }
            else
            {
                rc = (Int32)CMP_ERROR_ID.CMP_ERROR_NOT_CONNECTED;
            }

            return (rc);
        }

        // <summary>
        // Wrapper function for GetViewport
        // </summary>
        public Int32 GetViewport(ref short viewportFlags, ref short zoomFactor, ref CMP_DISPLAY_RECT serverViewport, ref CMP_DISPLAY_RECT clientViewport)
        {
            Int32 rc = (Int32)CMP_ERROR_ID.CMP_NO_ERROR;

            if (cmp != null)
            {
                rc = ConfirmConnection();

                if (CMPApp.CMP_SUCCESS(rc))
                {
                    rc = cmp.GetViewport(out viewportFlags, out zoomFactor, out serverViewport, out clientViewport);
                }
            }
            else
            {
                rc = (Int32)CMP_ERROR_ID.CMP_ERROR_NOT_CONNECTED;
            }

            return (rc);
        }


        // <summary>
        // Wrapper function for GetScrollMode
        // </summary>
        public Int32 GetScrollMode(ref CMP_SCROLL_MODE scrollMode)
        {
            Int32 rc = (Int32)CMP_ERROR_ID.CMP_NO_ERROR;

            if (cmp != null)
            {
                rc = ConfirmConnection();

                if (CMPApp.CMP_SUCCESS(rc))
                {
                    rc = cmp.GetScrollMode(out scrollMode);
                }
            }
            else
            {
                rc = (Int32)CMP_ERROR_ID.CMP_ERROR_NOT_CONNECTED;
            }

            return (rc);
        }

        //! [GetOrientation]
        // <summary>
        // Wrapper function for GetOrientation
        // </summary>
        public Int32 GetOrientation(ref CMP_ORIENTATION_DATA orientData)
        {
            Int32 rc = (Int32)CMP_ERROR_ID.CMP_NO_ERROR;

            if (cmp != null)
            {
                rc = ConfirmConnection();

                if (CMPApp.CMP_SUCCESS(rc))
                {
                    rc = cmp.GetOrientation(out orientData);
                }
            }
            else
            {
                rc = (Int32)CMP_ERROR_ID.CMP_ERROR_NOT_CONNECTED;
            }

            return (rc);
        }
        //! [GetOrientation]

        //! [ConfirmConnection]
        // <summary>
        // Restart the virtual channel session if it is currently closed
        // </summary>
        public Int32 ConfirmConnection()
        {
            Int32 rc = (Int32)CMP_ERROR_ID.CMP_NO_ERROR;

            if (!cmp.IsChannelOpen())
            {
                // this is probably a disconnect so we need to reset our link
                CloseSession();
                rc = OpenSession();
            }

            return (rc);
        }
        //! [ConfirmConnection]

    }

}
